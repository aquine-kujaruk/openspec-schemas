import { type AuthorizationProps, type Refusal } from "../schemas/authorization.schema.js";
import type { ProtectedArea } from "./protected-area.value-object.js";
export declare class Authorization {
    readonly blockedBy?: ProtectedArea;
    readonly refusals: Refusal[];
    constructor(props: AuthorizationProps);
    get allowed(): boolean;
}

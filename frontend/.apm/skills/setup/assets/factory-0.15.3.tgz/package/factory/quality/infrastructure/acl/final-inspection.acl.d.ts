import { z } from "zod";
export declare const FinalInspectionRecordSchema: any;
export type FinalInspectionRecord = z.infer<typeof FinalInspectionRecordSchema>;
export type InspectionRun = {
    status: number | null;
    output: string;
};
declare const FileGaugeRecordSchema: any;
export declare const FileGaugeReportSchema: any;
export type FileGaugeRecord = z.infer<typeof FileGaugeRecordSchema>;
export type EndToEndRecord = {
    test: string;
    result: "passed" | "failed";
    output?: string;
};
export type InspectionFinding = {
    source: string;
    names: string;
    findings: string[];
};
export interface FinalInspectionAcl {
    load(name: string): Promise<FinalInspectionRecord>;
    gauges(files: string[]): Promise<FileGaugeRecord[]>;
    run(args: string[]): Promise<InspectionRun>;
    endToEnd(): Promise<EndToEndRecord[]>;
    findWorkstream(file: string): Promise<string | undefined>;
    audit(): Promise<string[]>;
    digest(name: string): Promise<string>;
    save(record: InspectionCertificateRecord): Promise<void>;
    feedback(name: string, finding: InspectionFinding): Promise<void>;
}
export declare const InspectionAuditState: {
    readonly Run: "run";
    readonly Skipped: "skipped";
    readonly Incomplete: "incomplete";
};
export type InspectionCertificateRecord = {
    change: string;
    verdict: "verified" | "not verified";
    digest: string;
    scenarios: {
        spec: string;
        requirement: string;
        scenario: string;
        result: string;
        by?: string;
    }[];
    failing: {
        workstream: string;
        output: string;
    }[];
    review: {
        state: (typeof InspectionAuditState)[keyof typeof InspectionAuditState];
        warnings: string[];
        note?: string;
    };
    procedures: {
        slug: string;
        env: string;
        treatment: string;
        outcome?: string;
    }[];
    e2e?: EndToEndRecord[];
};
export {};

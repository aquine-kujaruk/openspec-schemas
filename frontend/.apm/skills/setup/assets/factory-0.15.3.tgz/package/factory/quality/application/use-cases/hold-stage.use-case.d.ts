import { StageHold } from "../../domain/value-objects/stage-hold.value-object.js";
import type { StageHoldRepositoryInterface } from "../repository-interfaces/stage-hold.repository-interface.js";
export declare class HoldStageUseCase {
    private readonly records;
    constructor(records: StageHoldRepositoryInterface);
    execute(helper?: boolean): Promise<StageHold>;
    private inspectStage;
}

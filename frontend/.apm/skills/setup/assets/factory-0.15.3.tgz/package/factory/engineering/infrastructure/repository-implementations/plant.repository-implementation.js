import { Line } from "../../../shared/domain/entities/line.entity.js";
import { Plant } from "../../../shared/domain/entities/plant.entity.js";
import { LineName } from "../../../shared/domain/value-objects/line-name.value-object.js";
import { LineRoots } from "../../../shared/domain/value-objects/line-roots.value-object.js";
import { ProcessName } from "../../../shared/domain/value-objects/process-name.value-object.js";
import { EngineeringException } from "../../domain/exceptions/engineering.exceptions.js";
import { PlantRecordSchema } from "../acl/plant.acl.js";
export class PlantRepositoryImplementation {
    records;
    constructor(records) {
        this.records = records;
    }
    async getPlant() {
        try {
            const record = PlantRecordSchema.parse(await this.records.readPlant());
            return new Plant({
                root: record.root,
                lines: record.lines.map((line) => new Line({
                    name: new LineName({ value: line.name }),
                    folder: line.folder,
                    process: new ProcessName({ value: line.process }),
                    roots: new LineRoots(line.roots),
                })),
            });
        }
        catch (cause) {
            throw new EngineeringException("The plant configuration could not be loaded", { cause });
        }
    }
    async prepareRoots(plant, line) {
        try {
            return await this.records.prepareRoots(plant.root, line.roots);
        }
        catch (cause) {
            throw new EngineeringException("The line could not be prepared", { cause });
        }
    }
}

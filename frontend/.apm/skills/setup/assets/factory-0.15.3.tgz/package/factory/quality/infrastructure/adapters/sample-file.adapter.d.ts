import type { ExampleFilePorts } from "./sample-file-contract.adapter.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createExampleFile: ({ readFileSync, findingLines, parseFindingLines, }: ExampleFilePorts) => typeof import("./sample-file-contract.adapter.js");

import { SuspectProcedureService } from "../../domain/services/suspect-procedure.service.js";
export class FindSuspectProceduresUseCase {
    equipment;
    inspection = new SuspectProcedureService();
    constructor(equipment) {
        this.equipment = equipment;
    }
    async execute(root) {
        const holdings = await this.equipment.readHoldings(root);
        return this.inspection.suspectsOf(this.equipment.listProcedures(root), holdings);
    }
}

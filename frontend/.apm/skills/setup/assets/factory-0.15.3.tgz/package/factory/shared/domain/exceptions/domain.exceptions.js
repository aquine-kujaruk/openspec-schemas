export class DomainException extends Error {
    constructor(message, options = {}) {
        super(message, { cause: options.cause });
        this.name = new.target.name;
    }
}

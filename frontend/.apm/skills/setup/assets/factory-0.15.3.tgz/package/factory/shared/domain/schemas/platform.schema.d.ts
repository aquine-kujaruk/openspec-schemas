import type { Platform } from "./line-types.schema.js";
/**
 * The platforms a schema or a project can pick. The only place that knows which globals reach the
 * environment: the layers receive these lists from the platform the configuration names.
 */
/** Node platform (a server process). */
export declare const node: Platform;
/**
 * Web platform (a browser). Persisted state and the network belong to adapters; navigating
 * (`location`, `history`, `window.open`) belongs to whoever the schema lets navigate.
 */
export declare const web: Platform;
/** Every platform, by the name a configuration gives it. */
export declare const PLATFORMS: Record<string, Platform>;

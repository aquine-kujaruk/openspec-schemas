import { z } from "zod";
export declare const PlanSchema: any;
export type PlanProps = z.input<typeof PlanSchema>;

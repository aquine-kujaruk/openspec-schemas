import { type StandardIdProps } from "../schemas/standard-id.schema.js";
export declare class StandardId {
    readonly value: string;
    constructor(props: StandardIdProps);
}

import type { BuildingRecord, GateRecord, StageHoldAcl, WorkstreamRecord } from "../acl/stage-hold.acl.js";
export type StageHoldResources = {
    active(): Promise<BuildingRecord[]>;
    workstreams(stage: BuildingRecord): Promise<WorkstreamRecord[]>;
    hasCurrentVerification?(name: string): Promise<boolean>;
    installed(): {
        schemas: string[];
        guards: string[];
        agents: string[];
    } | undefined;
    linked(schema: string): boolean;
    hooks(agent: string): string[];
    places: Record<string, {
        skills: string;
        hooks?: string;
    } | undefined>;
};
export declare class StageHoldAdapter implements StageHoldAcl {
    private readonly root;
    private readonly orders;
    private readonly gateFile;
    private readonly resources;
    constructor(root: string, orders: string, gateFile: string, resources: StageHoldResources);
    buildingRecords(): Promise<BuildingRecord[]>;
    workstreams(stage: BuildingRecord): Promise<WorkstreamRecord[]>;
    hasCurrentVerification(name: string): Promise<boolean>;
    harnessFindings(): Promise<string[]>;
    private path;
    readRecord(name: string): Promise<unknown>;
    writeRecord(name: string, record: GateRecord): Promise<void>;
    removeRecord(name: string): Promise<void>;
    run(stage: BuildingRecord, args: string[]): unknown;
}

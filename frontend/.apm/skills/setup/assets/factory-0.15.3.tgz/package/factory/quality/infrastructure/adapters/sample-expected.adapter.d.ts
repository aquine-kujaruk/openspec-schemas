/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createExpectFile: () => typeof import("./sample-expected-contract.adapter.js");

import type { AuditRepositoryInterface } from "../../application/repository-interfaces/audit.repository-interface.js";
import type { AuditPass, AuditQuestion, AuditSource } from "../../domain/schemas/audit-material.schema.js";
import type { AuditAcl } from "../acl/audit.acl.js";
export declare class AuditRepositoryImplementation implements AuditRepositoryInterface {
    private readonly resources;
    constructor(resources: AuditAcl);
    listRubrics(root: string, paths: string[]): any;
    listPackageNames(root: string): any;
    listCoreFiles(root: string, modules: string, folders: string[]): any;
    readPass(root: string): any;
    savePass(root: string, pass: AuditPass): void;
    findCommit(root: string): any;
    hashContent(content: string): any;
    askQuestions(state: string, questions: AuditQuestion[]): unknown;
    outlineSource(source: AuditSource): any;
    private read;
}

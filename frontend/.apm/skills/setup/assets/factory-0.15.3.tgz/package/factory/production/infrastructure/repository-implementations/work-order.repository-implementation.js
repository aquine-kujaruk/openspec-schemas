import { LineName } from "../../../shared/domain/value-objects/line-name.value-object.js";
import { ProcessName } from "../../../shared/domain/value-objects/process-name.value-object.js";
import { WorkOrder } from "../../domain/aggregates/work-order.aggregate.js";
import { Plan } from "../../domain/entities/plan.entity.js";
import { Stage } from "../../domain/entities/stage.entity.js";
import { WorkOrderException } from "../../domain/exceptions/work-order.exceptions.js";
import { parsePlan, deltaRequirementsOf } from "../../domain/schemas/plan-document.schema.js";
import { AndonPull } from "../../domain/value-objects/andon-pull.value-object.js";
import { Decision } from "../../domain/value-objects/decision.value-object.js";
import { DrawingRevision } from "../../domain/value-objects/drawing-revision.value-object.js";
import { Operation } from "../../domain/value-objects/operation.value-object.js";
import { WorkOrderName } from "../../domain/value-objects/work-order-name.value-object.js";
import { WorkOrderRecordSchema } from "../acl/work-order.acl.js";
export class WorkOrderRepositoryImplementation {
    files;
    constructor(files) {
        this.files = files;
    }
    async findWorkOrder(name) {
        try {
            const source = await this.files.readOrder(name.value);
            if (!source)
                return null;
            const { plan, process, line, revisions, andon } = WorkOrderRecordSchema.parse(source);
            const document = parsePlan(plan);
            return new WorkOrder({
                name,
                process: new ProcessName({ value: process }),
                line: line === undefined ? undefined : new LineName({ value: line }),
                plan: new Plan({
                    stages: document.phases.map(({ title, tasks }) => new Stage({
                        title,
                        operations: tasks.map(({ text, done, workstream }) => new Operation({
                            text, done, workCenter: workstream,
                        })),
                    })),
                    decisions: document.changeDecisions.flatMap(({ text, tags }) => {
                        const by = tags.find(({ name }) => name === "by")?.value;
                        return by === "person" || by === "agent" ? [new Decision({ text, by })] : [];
                    }),
                    openQuestions: document.openQuestions,
                    releasedOn: /^\d{4}-\d{2}-\d{2}$/.test(document.approvedAt ?? "") ? document.approvedAt : undefined,
                }),
                revisions: revisions.map(({ drawing, document }) => new DrawingRevision({
                    drawing,
                    requirements: deltaRequirementsOf(document).map(({ name }) => ({ name })),
                })),
                andonPulls: andon.map((signal) => new AndonPull(signal)),
            });
        }
        catch (cause) {
            throw new WorkOrderException(`Could not read work order ${name.value}`, { cause });
        }
    }
    async listWorkOrders() {
        const names = await this.files.listOrders();
        const orders = await Promise.all(names.map((value) => this.findWorkOrder(new WorkOrderName({ value }))));
        return orders.filter((order) => order !== null);
    }
    async saveWorkOrder(order) {
        await this.files.writeRelease(order.name.value, order.plan.releasedOn);
    }
}

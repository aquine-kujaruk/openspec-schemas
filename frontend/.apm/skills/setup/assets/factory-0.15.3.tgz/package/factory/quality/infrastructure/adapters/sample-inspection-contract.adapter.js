import {} from "./sample-file-contract.adapter.js";
export {};

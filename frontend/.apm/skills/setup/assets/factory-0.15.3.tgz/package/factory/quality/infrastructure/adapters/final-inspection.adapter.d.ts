import type { EndToEndRecord, FileGaugeRecord, FinalInspectionAcl, FinalInspectionRecord, InspectionCertificateRecord, InspectionFinding } from "../acl/final-inspection.acl.js";
import type { QualityCertificateFileAcl } from "../acl/quality-certificate-file.acl.js";
export declare function scenariosOfDelta(file: string): any;
export type InspectionResources = {
    snapshot: FinalInspectionRecord;
    line?: string;
    auditEnvironment: NodeJS.ProcessEnv;
    findWorkstream(file: string): string | undefined;
    feedback(name: string, finding: InspectionFinding): void;
};
export declare class FinalInspectionAdapter implements FinalInspectionAcl {
    private readonly root;
    private readonly resources;
    private readonly certificates;
    constructor(root: string, resources: InspectionResources, certificates: QualityCertificateFileAcl);
    load(): Promise<FinalInspectionRecord>;
    private get selection();
    gauges(files: string[]): Promise<FileGaugeRecord[]>;
    run(args: string[]): unknown;
    endToEnd(): Promise<EndToEndRecord[]>;
    findWorkstream(file: string): Promise<string | undefined>;
    audit(): Promise<string[]>;
    digest(name: string): Promise<string>;
    save(record: InspectionCertificateRecord): Promise<void>;
    feedback(name: string, finding: InspectionFinding): Promise<void>;
}

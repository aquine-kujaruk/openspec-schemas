import type { AuditPass, AuditRow, AuditSource } from "../schemas/audit-material.schema.js";
export declare class AuditRecordService {
    private readonly hash;
    constructor(hash: (content: string) => string);
    rubricHash(rows: AuditRow[]): string;
    touched<F extends AuditSource>(files: F[], record: AuditPass, rubric: string): F[];
    recordPass(record: AuditPass, judged: AuditSource[], commit: string | null, rubric: string): AuditPass;
}

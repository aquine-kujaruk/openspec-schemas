export class WorkOrderValidationAdapter {
    read;
    findings;
    constructor(read, findings) {
        this.read = read;
        this.findings = findings;
    }
    readPlan(name) { return this.read(name); }
    listFindings(name) { return this.findings(name); }
}

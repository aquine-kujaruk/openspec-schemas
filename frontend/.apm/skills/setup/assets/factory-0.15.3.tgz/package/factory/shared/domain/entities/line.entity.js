import { validateSchema } from "../schemas/validation.schema.js";
import { LineSchema } from "../schemas/line.schema.js";
export class Line {
    name;
    folder;
    process;
    roots;
    constructor(props) {
        validateSchema(this, LineSchema, props);
    }
}

import type { LineName } from "../../../shared/domain/value-objects/line-name.value-object.js";
import type { QualityControlRun } from "../../domain/aggregates/quality-control-run.aggregate.js";
import type { InspectionRepositoryInterface } from "../repository-interfaces/inspection.repository-interface.js";
export declare class RunQualityControlUseCase {
    private readonly repository;
    constructor(repository: InspectionRepositoryInterface);
    execute(line: LineName, scope: readonly string[]): Promise<QualityControlRun>;
}

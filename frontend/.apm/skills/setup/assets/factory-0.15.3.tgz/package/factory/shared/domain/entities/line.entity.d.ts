import { type LineProps } from "../schemas/line.schema.js";
import type { LineName } from "../value-objects/line-name.value-object.js";
import type { ProcessName } from "../value-objects/process-name.value-object.js";
import type { LineRoots } from "../value-objects/line-roots.value-object.js";
export declare class Line {
    readonly name: LineName;
    readonly folder: string;
    readonly process: ProcessName;
    readonly roots: LineRoots;
    constructor(props: LineProps);
}

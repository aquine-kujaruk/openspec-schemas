import type { Equipment } from "../aggregates/equipment.aggregate.js";
import { type EquipmentFinding, type EquipmentNotes, type EquipmentReading } from "../schemas/equipment-reading.schema.js";
export declare class EquipmentInspectionService {
    findings(equipment: Equipment, reading: EquipmentReading): EquipmentFinding[];
    notes(equipment: Equipment, reading: EquipmentNotes): string[];
}

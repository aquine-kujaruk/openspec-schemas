import { z } from "zod";
export declare const ProcessSchema: any;
export type ProcessProps = z.infer<typeof ProcessSchema>;

import { z } from "zod";
declare const RefusalSchema: any;
export declare const AuthorizationSchema: any;
export type Refusal = z.infer<typeof RefusalSchema>;
export type AuthorizationProps = z.input<typeof AuthorizationSchema>;
export {};

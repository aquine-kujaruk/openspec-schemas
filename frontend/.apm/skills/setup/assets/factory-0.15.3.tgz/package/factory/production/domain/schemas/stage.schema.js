import { z } from "zod";
import { Operation } from "../value-objects/operation.value-object.js";
export const StageSchema = z.object({
    title: z.string().min(1),
    operations: z.array(z.instanceof(Operation)),
});

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { AndonPullSchema } from "../schemas/andon-pull.schema.js";
export class AndonPull {
    from;
    names;
    says;
    constructor(props) {
        validateSchema(this, AndonPullSchema, props);
    }
}

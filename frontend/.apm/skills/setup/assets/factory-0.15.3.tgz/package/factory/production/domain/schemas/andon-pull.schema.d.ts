import { z } from "zod";
export declare const AndonPullSchema: any;
export type AndonPullProps = z.input<typeof AndonPullSchema>;

import type { ClosingRepositoryInterface } from "../repository-interfaces/closing.repository-interface.js";
type Closed = {
    change: string;
    place: "archived" | "still active";
    as?: string;
    reason?: string;
};
export declare class CloseWorkOrderUseCase {
    private readonly orders;
    private readonly standing;
    constructor(orders: ClosingRepositoryInterface);
    execute(name?: string, { date }?: {
        date?: string;
    }): Promise<Closed[]>;
    private closeOne;
}
export {};

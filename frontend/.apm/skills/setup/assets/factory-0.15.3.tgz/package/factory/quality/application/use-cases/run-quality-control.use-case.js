export class RunQualityControlUseCase {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    execute(line, scope) {
        return this.repository.inspectLine(line, scope);
    }
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { WorkOrderNameSchema } from "../schemas/work-order-name.schema.js";
export class WorkOrderName {
    value;
    constructor(props) {
        validateSchema(this, WorkOrderNameSchema, props);
    }
    equals(other) {
        return this.value === other.value;
    }
}

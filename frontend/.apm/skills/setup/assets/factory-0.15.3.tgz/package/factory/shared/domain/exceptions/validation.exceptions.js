import { DomainException } from "./domain.exceptions.js";
export class ValidationException extends DomainException {
    source;
    constructor(source, cause) {
        super(`${source} rejected its props`, { cause });
        this.source = source;
    }
}

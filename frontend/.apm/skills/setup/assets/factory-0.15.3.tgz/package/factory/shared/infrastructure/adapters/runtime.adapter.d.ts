export declare const runtime: {
    environment: () => NodeJS.ProcessEnv;
    workingDirectory: () => string;
    changeDirectory: (directory: string) => void;
    nodeExecutable: any;
    nodeVersion: any;
    interactive: () => boolean;
    fetch: any;
    setTimeout: any;
    loadModule: (specifier: string) => Promise<unknown>;
};

import { z } from "zod";
export type DrawingPath = string;
declare const RequirementChangeSchema: any;
export type RequirementChange = z.infer<typeof RequirementChangeSchema>;
export declare const DrawingRevisionSchema: any;
export type DrawingRevisionProps = z.input<typeof DrawingRevisionSchema>;
export {};

import type { ProcessName } from "../../../shared/domain/value-objects/process-name.value-object.js";
import type { Process } from "../../domain/aggregates/process.aggregate.js";
export interface ProcessRepositoryInterface {
    findProcess(name: ProcessName): Promise<Process | null>;
    listProcesses(): Promise<Process[]>;
}

import { z } from "zod";
export const ProcessRecordSchema = z.object({
    name: z.string(),
    base: z.string().optional(),
    description: z.string(),
    pilot: z.string().optional(),
    workCenters: z.array(z.object({
        id: z.string(),
        waitsFor: z.array(z.string()),
        parts: z.array(z.object({
            name: z.string(),
            standards: z.array(z.object({ id: z.string(), title: z.string() })),
        })),
    })),
});

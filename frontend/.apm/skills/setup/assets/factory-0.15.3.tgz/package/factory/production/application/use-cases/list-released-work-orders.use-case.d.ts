import type { WorkOrder } from "../../domain/aggregates/work-order.aggregate.js";
import type { WorkOrderRepositoryInterface } from "../repository-interfaces/work-order.repository-interface.js";
export declare class ListReleasedWorkOrdersUseCase {
    private readonly orders;
    constructor(orders: WorkOrderRepositoryInterface);
    execute(): Promise<WorkOrder[]>;
}

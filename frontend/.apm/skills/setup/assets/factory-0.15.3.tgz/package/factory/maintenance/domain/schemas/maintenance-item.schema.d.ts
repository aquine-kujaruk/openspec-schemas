import { z } from "zod";
export declare const MaintenanceKind: {
    readonly Missing: "missing";
    readonly Drift: "drift";
    readonly Note: "note";
    readonly Suspect: "suspect";
};
export declare const MaintenanceItemSchema: any;
export type MaintenanceItemProps = z.input<typeof MaintenanceItemSchema>;

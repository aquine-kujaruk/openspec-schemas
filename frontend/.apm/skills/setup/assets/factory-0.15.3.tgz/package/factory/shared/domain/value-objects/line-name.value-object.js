import { validateSchema } from "../schemas/validation.schema.js";
import { LineNameSchema } from "../schemas/line-name.schema.js";
export class LineName {
    value;
    constructor(props) {
        validateSchema(this, LineNameSchema, props);
    }
    equals(other) {
        return this.value === other.value;
    }
}

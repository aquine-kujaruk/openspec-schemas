export class WorkOrderAssessmentAdapter {
    catalog;
    constructor(catalog) {
        this.catalog = catalog;
    }
    listProcesses() { return this.catalog.schemaNames(); }
    async loadProcess(name) {
        const { definition, validator } = await this.catalog.loadSchema(name);
        return { validator, workstreams: definition.workstreams, spike: definition.spike?.workstream };
    }
    async listProducts(root) {
        return (await this.catalog.readProjectConfig(root))?.products ?? {};
    }
}

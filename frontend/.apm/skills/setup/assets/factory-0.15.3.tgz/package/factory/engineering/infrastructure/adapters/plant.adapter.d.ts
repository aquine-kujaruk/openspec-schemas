import type { PlantAcl, PlantRecord, Product, RootRecord } from "../acl/plant.acl.js";
export declare class PlantAdapter implements PlantAcl {
    private readonly root;
    private readonly readProducts;
    constructor(root: string, readProducts: (root: string) => Promise<Product[]>);
    readPlant(): Promise<PlantRecord>;
    prepareRoots(root: string, inputs: RootRecord): Promise<string[]>;
}
type Roots = Pick<RootRecord, "modules" | "acceptance" | "integration" | "unit" | "base">;
/**
 * `factory prepare`: the minimum the implementer needs before any workstream. Every configured
 * root that does not exist is created; a new module root also gets the configured `base` (or
 * `DEFAULT_BASE`). An existing directory is never touched, so running it twice changes nothing.
 * Returns the directories it created, relative to `cwd`.
 */
export declare const prepareRoots: (cwd: string, o: Roots) => string[];
export {};

import type { Review } from "../../../shared/domain/schemas/line-types.schema.js";
import type { AuditFinding } from "../../domain/value-objects/audit-finding.value-object.js";
import type { AuditRepositoryInterface } from "../repository-interfaces/audit.repository-interface.js";
export type AuditInput = {
    root: string;
    modules: string;
    config: Review;
    rubrics: string[];
    key?: string;
};
export type AuditReport = {
    code: 0;
    findings: AuditFinding[];
    lines: string[];
} | {
    code: 2 | 3;
    issue: string;
} | {
    code: 4;
    incomplete: string[];
    findings: AuditFinding[];
    lines: string[];
};
export declare class AuditUseCase {
    private readonly repository;
    private readonly funnel;
    private readonly rubric;
    private readonly records;
    constructor(repository: AuditRepositoryInterface);
    execute({ root, modules, config, rubrics, key }: AuditInput): Promise<AuditReport>;
}

export class WorkOrderValidationRepositoryImplementation {
    documents;
    constructor(documents) {
        this.documents = documents;
    }
    readPlan(name) { return this.documents.readPlan(name); }
    listFindings(name) { return this.documents.listFindings(name); }
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { OperationSchema } from "../schemas/operation.schema.js";
export class Operation {
    workCenter;
    text;
    done;
    constructor(props) {
        validateSchema(this, OperationSchema, props);
    }
}

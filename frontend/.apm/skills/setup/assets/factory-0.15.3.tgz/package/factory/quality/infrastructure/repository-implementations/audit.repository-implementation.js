import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
export class AuditRepositoryImplementation {
    resources;
    constructor(resources) {
        this.resources = resources;
    }
    listRubrics(root, paths) {
        return this.read(() => this.resources.listRubrics(root, paths));
    }
    listPackageNames(root) {
        return this.read(() => this.resources.listPackageNames(root));
    }
    listCoreFiles(root, modules, folders) {
        return this.read(() => this.resources.listCoreFiles(root, modules, folders));
    }
    readPass(root) {
        return this.read(() => this.resources.readPass(root));
    }
    savePass(root, pass) {
        this.read(() => this.resources.savePass(root, pass));
    }
    findCommit(root) {
        return this.read(() => this.resources.findCommit(root));
    }
    hashContent(content) {
        return this.resources.hashContent(content);
    }
    async askQuestions(state, questions) {
        try {
            return await this.resources.askQuestions(state, questions);
        }
        catch (cause) {
            throw new QualityException(cause instanceof Error ? cause.message : String(cause), { cause });
        }
    }
    outlineSource(source) {
        return this.read(() => this.resources.outlineSource(source));
    }
    read(request) {
        try {
            return request();
        }
        catch (cause) {
            throw new QualityException(cause instanceof Error ? cause.message : String(cause), { cause });
        }
    }
}

import type { GeneratedPorts } from "./gauge-layout-contract.adapter.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createGenerated: ({ globSync, basename, dirname, join, relative, ARCHITECTURE_SPECS, PACKAGE_ROOT, SOURCE_EXT, productOf, holderNames, loadHolder, }: GeneratedPorts) => typeof import("./gauge-layout-contract.adapter.js");

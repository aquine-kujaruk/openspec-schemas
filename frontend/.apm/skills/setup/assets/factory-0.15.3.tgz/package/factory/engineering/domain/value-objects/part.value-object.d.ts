import { type PartProps } from "../schemas/part.schema.js";
import type { Standard } from "../value-objects/standard.value-object.js";
export declare class Part {
    readonly name: string;
    readonly standards: Standard[];
    constructor(props: PartProps);
}

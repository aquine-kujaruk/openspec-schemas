import type { DrawingProjectionRepositoryInterface } from "../../application/repository-interfaces/drawing-projection.repository-interface.js";
import type { DrawingProjectionAcl } from "../acl/drawing-projection.acl.js";
import type { WorkOrderRecordAcl } from "../acl/work-order-record.acl.js";
export declare class DrawingProjectionRepositoryImplementation implements DrawingProjectionRepositoryInterface {
    private readonly orders;
    private readonly drawings;
    constructor(orders: WorkOrderRecordAcl, drawings: DrawingProjectionAcl);
    listWorkOrders(root: string): any;
    mergeDrawings(root: string, changes: string[]): any;
}

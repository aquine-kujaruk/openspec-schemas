export const DECISIONS = "openspec/adr";
export const PROCEDURES = "openspec/runbooks";

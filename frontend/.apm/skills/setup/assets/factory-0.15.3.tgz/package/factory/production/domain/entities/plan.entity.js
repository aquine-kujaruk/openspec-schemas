import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { PlanSchema } from "../schemas/plan.schema.js";
export class Plan {
    stages;
    decisions;
    openQuestions;
    releasedOn;
    constructor(props) {
        validateSchema(this, PlanSchema, props);
    }
}

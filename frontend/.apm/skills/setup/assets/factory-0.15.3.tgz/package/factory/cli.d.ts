import type { Commands, CliHost } from "./shared/infrastructure/adapters/cli-contract.adapter.js";
/** Parses the person's invocation and dispatches the module's command. */
export declare const runCli: (given: string[], own: Commands, host: CliHost) => Promise<number>;

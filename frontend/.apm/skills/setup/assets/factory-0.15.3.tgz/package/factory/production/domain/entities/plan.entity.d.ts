import { type PlanProps } from "../schemas/plan.schema.js";
import type { Day } from "../schemas/day.schema.js";
import type { Decision } from "../value-objects/decision.value-object.js";
import type { Stage } from "./stage.entity.js";
export declare class Plan {
    readonly stages: Stage[];
    readonly decisions: Decision[];
    readonly openQuestions: string[];
    readonly releasedOn?: Day;
    constructor(props: PlanProps);
}

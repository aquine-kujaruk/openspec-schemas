import { ProcessName } from "../../../shared/domain/value-objects/process-name.value-object.js";
import type { ProcessRepositoryInterface } from "../../application/repository-interfaces/process.repository-interface.js";
import { Process } from "../../domain/aggregates/process.aggregate.js";
import { type ProcessAcl } from "../acl/process.acl.js";
export declare class ProcessRepositoryImplementation implements ProcessRepositoryInterface {
    private readonly records;
    constructor(records: ProcessAcl);
    listProcesses(): Promise<Process[]>;
    findProcess(name: ProcessName): Promise<Process | null>;
}

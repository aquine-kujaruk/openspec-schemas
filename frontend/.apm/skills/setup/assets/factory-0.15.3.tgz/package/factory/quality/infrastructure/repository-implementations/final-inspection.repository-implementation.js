import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
import { FinalInspectionRecordSchema } from "../acl/final-inspection.acl.js";
export class FinalInspectionRepositoryImplementation {
    records;
    constructor(records) {
        this.records = records;
    }
    async loadInspection(name) {
        try {
            return FinalInspectionRecordSchema.parse(await this.records.load(name));
        }
        catch (cause) {
            if (cause instanceof QualityException)
                throw cause;
            throw new QualityException(`Unable to load work order ${name}`, { cause });
        }
    }
    async runGauges(files) {
        return (await this.records.gauges(files)).map(({ name, assertionResults, status }) => {
            const assertions = assertionResults.map(({ ancestorTitles, title, status }) => ({
                requirement: (ancestorTitles.at(-1) ?? "").replace(/^Rule: /, ""),
                scenario: title,
                passed: status === "passed",
            }));
            if (status === "failed" && assertions.every(test => test.passed))
                assertions.push({ requirement: "", scenario: "Vitest suite execution", passed: false });
            return { name, assertions };
        });
    }
    runCheck(workstream) {
        return this.records.run(["check", "--workstream", workstream]);
    }
    runTests(kind) {
        return this.records.run(["test", kind]);
    }
    checkFreshness() {
        return this.records.run(["generate", "--check"]);
    }
    runWholeCheck() {
        return this.records.run(["check", "--whole"]);
    }
    runEndToEnd() {
        return this.records.endToEnd();
    }
    findWorkstream(file) {
        return this.records.findWorkstream(file);
    }
    runAudit() {
        return this.records.audit();
    }
    readDigest(name) {
        return this.records.digest(name);
    }
    saveCertificate(certificate) {
        const { change, verdict, digest, scenarios, failing, review, procedures, e2e } = certificate;
        return this.records.save({ change, verdict, digest, scenarios, failing, review, procedures, e2e });
    }
    pullAndon(name, finding) {
        return this.records.feedback(name, finding);
    }
}

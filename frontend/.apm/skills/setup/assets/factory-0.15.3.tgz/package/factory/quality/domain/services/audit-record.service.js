export class AuditRecordService {
    hash;
    constructor(hash) {
        this.hash = hash;
    }
    rubricHash(rows) {
        return this.hash(JSON.stringify({
            scope: "named-file-and-line-range",
            rows: rows
                .map((row) => [row.id, row.question, row.folders, row.crossFile])
                .sort((a, b) => (a[0] < b[0] ? -1 : 1)),
        }));
    }
    touched(files, record, rubric) {
        return record.rubric !== rubric
            ? files
            : files.filter((file) => record.files[file.path]?.hash !== this.hash(file.content));
    }
    recordPass(record, judged, commit, rubric) {
        const files = { ...record.files };
        for (const file of judged) {
            files[file.path] = { hash: this.hash(file.content), commit };
        }
        return {
            rubric,
            files: Object.fromEntries(Object.entries(files).sort(([a], [b]) => a.localeCompare(b))),
        };
    }
}

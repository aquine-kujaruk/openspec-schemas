import type { Line } from "../../../shared/domain/entities/line.entity.js";
import type { Plant } from "../../../shared/domain/entities/plant.entity.js";
export interface PlantRepositoryInterface {
    getPlant(): Promise<Plant>;
    prepareRoots(plant: Plant, line: Line): Promise<string[]>;
}

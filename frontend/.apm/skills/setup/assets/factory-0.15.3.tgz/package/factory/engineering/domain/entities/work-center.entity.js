import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { WorkCenterSchema } from "../schemas/work-center.schema.js";
export class WorkCenter {
    id;
    parts;
    waitsFor;
    constructor(props) {
        validateSchema(this, WorkCenterSchema, props);
    }
}

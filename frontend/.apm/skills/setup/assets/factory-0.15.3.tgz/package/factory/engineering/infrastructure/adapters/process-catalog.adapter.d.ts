import type { CatalogResourceKind as Kind, CatalogSchema, CoreDefinition, MisplacedResource as Misplaced, SchemaDefinition } from "../acl/process.acl.js";
export declare function createProcessCatalog<V>(PACKAGE_ROOT: string, SOURCE_EXT: string, loadModule: (specifier: string) => Promise<unknown>): {
    SCHEMAS: string;
    SHARED: string;
    CORES: string;
    coreFolder: (id: string) => string;
    coreNames: (root?: string) => string[];
    schemaNames: (root?: string) => string[];
    chain: (name: string, root?: string, seen?: string[]) => Promise<string[]>;
    definitionFiles: (name: string, root?: string) => Promise<string[]>;
    writtenDefinition: (name: string, root?: string) => Promise<SchemaDefinition>;
    loadCore: (id: string, by: string, root?: string) => Promise<CoreDefinition>;
    loadDefinition: (name: string, root?: string) => Promise<SchemaDefinition>;
    KINDS: {
        readonly core: (id: string) => any;
        readonly workstream: (id: string) => any;
        readonly validator: (id: string) => any;
        readonly "question policy": (id: string) => any;
        readonly template: (id: string) => any;
    };
    named: (d: SchemaDefinition) => Array<{
        kind: Kind;
        id: string;
    }>;
    loadSchema: (name: string, root?: string) => Promise<CatalogSchema<V>>;
    holderNames: (root?: string) => Promise<string[]>;
    loadHolder: (name: string, root?: string) => Promise<CatalogSchema<V>>;
    misplaced: (root?: string) => Promise<Misplaced[]>;
    projectSchemaName: (project: string, root?: string) => Promise<string>;
};

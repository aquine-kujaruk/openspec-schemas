import { z } from "zod";
export declare const DaySchema: any;
export type Day = z.infer<typeof DaySchema>;

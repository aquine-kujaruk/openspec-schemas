import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export const createExampleFile = ({ readFileSync, findingLines, parseFindingLines, }) => {
    /** The sections of an example file that are not rules. */
    const PLACES = new Set(["reference", "scaffolds"]);
    const FENCE = /^(`{3,})\S*\s+(\S+)\s*$/;
    const EXPECT = /^(`{3,})expect\s*$/;
    /**
     * Reads an example file. Headings outside fences give the place (`##` rule, `reference` or
     * `scaffolds`, `###` case); every file is a fence with `<lang> <path>` in its info string that
     * holds that file verbatim, and a case ends with at most one fence whose info string is `expect`,
     * holding its recorded findings or declared rubric verdict. A fence closes on a line of at
     * least as many backticks, so a block can contain a shorter fence.
     */
    const scan = (lines, name) => {
        const file = {
            reference: new Map(),
            scaffolds: new Map(),
            rules: new Map(),
            rubric: new Map(),
        };
        const spans = [];
        let section = "";
        let target;
        let current;
        let open;
        for (const [i, line] of lines.entries()) {
            const fail = (why) => {
                throw new QualityException(`${name}:${i + 1}: ${why}`, { cause: line });
            };
            if (open) {
                if (line.startsWith(open.ticks) && /^`+\s*$/.test(line)) {
                    if (open.path)
                        target.set(open.path, open.lines.join("\n") + "\n");
                    else {
                        if (file.rubric.has(section)) {
                            const verdict = open.lines[0]?.trim();
                            if (open.lines.length !== 1 || (verdict !== "yes" && verdict !== "no"))
                                throw new QualityException(`${name}:${open.at + 2}: a rubric expectation must declare yes or no`, { cause: open.lines });
                            current.case.expectedVerdict = verdict;
                        }
                        else
                            current.case.expected = parseFindingLines(open.lines, name, open.at + 2);
                        current.span.block = { open: open.at, close: i };
                    }
                    if (current)
                        current.span.end = i;
                    open = undefined;
                }
                else
                    open.lines.push(line);
                continue;
            }
            const semantic = /^## (S\d{2}) · ([a-z0-9-]+)\s*$/.exec(line);
            const heading = semantic ? ["", "##", semantic[1]] : /^(#{2,3}) (\S+)\s*$/.exec(line);
            const expect = EXPECT.exec(line);
            if (heading?.[1] === "##") {
                section = heading[2];
                target =
                    section === "reference"
                        ? file.reference
                        : section === "scaffolds"
                            ? file.scaffolds
                            : undefined;
                current = undefined;
                if (semantic) {
                    if (file.rubric.has(section))
                        fail(`repeated rubric row ${section}`);
                    file.rubric.set(section, new Map());
                }
                else if (!PLACES.has(section))
                    file.rules.set(section, new Map());
            }
            else if (heading?.[1] === "###") {
                const c = { files: new Map(), expected: undefined };
                const rule = file.rubric.get(section) ?? file.rules.get(section);
                target = c.files;
                current = rule && {
                    case: c,
                    span: { rule: section, name: heading[2], end: i },
                };
                if (current) {
                    if (rule.has(heading[2]))
                        fail(`repeated case ${section}/${heading[2]}`);
                    rule.set(heading[2], c);
                    spans.push(current.span);
                }
            }
            else if (expect) {
                if (!current)
                    fail(`an expect block belongs to a case; ${section ? `## ${section}` : "this place"} has none`);
                if (current.span.block)
                    fail(`case ${current.span.name} already has an expect block`);
                current.span.block = { open: i, close: -1 };
                open = { ticks: expect[1], at: i, lines: [] };
            }
            else if (line.startsWith("```")) {
                const fence = FENCE.exec(line);
                if (!fence || !target)
                    fail("a block needs `<lang> <path>` inside a case, the reference or the scaffolds");
                if (current?.span.block)
                    fail(`the expect block must be the last block of case ${current.span.name}`);
                open = { ticks: fence[1], path: fence[2], at: i, lines: [] };
            }
            else if (current && line.trim())
                current.span.end = i;
        }
        if (open)
            throw new QualityException(`${name}:${open.at + 1}: block ${open.path ?? "expect"} is not closed`, { cause: lines[open.at] });
        for (const { rule, name: sample, block, end } of spans) {
            if (!block && file.rubric.has(rule))
                throw new QualityException(`${name}:${end + 1}: rubric case ${rule}/${sample} must declare yes or no in an expect block`, { cause: sample });
        }
        return { file, spans };
    };
    /** Reads an example file from its text; `name` only labels errors. */
    const parseExampleText = (text, name) => scan(text.split("\n"), name).file;
    const parseExampleFile = (path) => parseExampleText(readFileSync(path, "utf8"), path);
    const recordFindings = (text, name, recorded) => {
        const lines = text.split("\n");
        const { file, spans } = scan(lines, name);
        for (const span of spans.reverse()) {
            if (file.rubric.has(span.rule))
                continue;
            const findings = recorded.get(span.rule)?.get(span.name);
            if (!findings)
                continue;
            const body = findingLines(findings);
            if (span.block)
                lines.splice(span.block.open + 1, span.block.close - span.block.open - 1, ...body);
            else
                lines.splice(span.end + 1, 0, "", "```expect", ...body, "```");
        }
        return lines.join("\n");
    };
    return { parseExampleText, parseExampleFile, recordFindings };
};

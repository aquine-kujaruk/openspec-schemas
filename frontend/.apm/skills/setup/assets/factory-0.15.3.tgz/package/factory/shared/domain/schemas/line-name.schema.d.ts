import { z } from "zod";
export declare const LineNameSchema: any;
export type LineNameProps = z.infer<typeof LineNameSchema>;

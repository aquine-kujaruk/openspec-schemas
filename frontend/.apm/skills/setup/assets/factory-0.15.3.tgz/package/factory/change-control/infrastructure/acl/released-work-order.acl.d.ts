import { z } from "zod";
export declare const ReleasedWorkOrderRecordSchema: any;
export type ReleasedWorkOrderRecord = z.infer<typeof ReleasedWorkOrderRecordSchema>;
export interface ReleasedWorkOrderAcl {
    readStarted(): Promise<ReleasedWorkOrderRecord[]>;
}

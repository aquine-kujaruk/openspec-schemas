export class ListReleasedWorkOrdersUseCase {
    orders;
    constructor(orders) {
        this.orders = orders;
    }
    async execute() {
        return (await this.orders.listWorkOrders()).filter(({ plan }) => plan.releasedOn && !plan.openQuestions.length);
    }
}

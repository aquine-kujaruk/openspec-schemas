import { z } from "zod";
export const FinalInspectionRecordSchema = z.object({
    name: z.string(),
    repository: z.boolean(),
    drawings: z.array(z.object({ spec: z.string(), text: z.string(), gauge: z.string().optional(), expected: z.array(z.object({ requirement: z.string(), scenario: z.string() })).optional() })),
    workstreams: z.array(z.object({
        id: z.string(),
        upstream: z.array(z.string()),
        tests: z.array(z.enum(["unit", "integration", "acceptance"])),
    })),
    procedures: z.array(z.object({ slug: z.string(), environments: z.array(z.string()), declined: z.boolean() })),
    platform: z.string(),
    review: z.object({ hasRubric: z.boolean(), keyVariable: z.string(), configured: z.boolean() }),
});
const FileGaugeRecordSchema = z.object({
    name: z.string(),
    status: z.string().optional(),
    assertionResults: z.array(z.object({ ancestorTitles: z.array(z.string()), title: z.string(), status: z.string() })),
});
export const FileGaugeReportSchema = z.object({ testResults: z.array(FileGaugeRecordSchema) });
export const InspectionAuditState = { Run: "run", Skipped: "skipped", Incomplete: "incomplete" };

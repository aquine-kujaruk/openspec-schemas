export { RepairKind } from "../../domain/schemas/equipment-reading.schema.js";
export { SECTION } from "../../domain/services/equipment-installation.service.js";
export const PLACES = {
    claude: {
        skills: ".claude/skills",
        instruction: { rules: ".claude/rules" },
        hooks: ".claude/settings.json",
    },
    codex: {
        skills: ".agents/skills",
        instruction: { file: "AGENTS.md" },
        hooks: ".codex/hooks.json",
    },
};

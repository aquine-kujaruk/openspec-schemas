import type { Judge } from "../../application/repository-interfaces/work-order-assessment.repository-interface.js";
import type { JudgementRequest } from "../../domain/services/work-order-assessment.service.js";
import type { DecisionJudgeAcl } from "../acl/decision-judge.acl.js";
/** The file of a change that records the decision model's answers. */
export declare const JUDGEMENTS = "judgements.json";
type Settings = {
    /** The decision model the product configures: the `.env` variable of its key and the model. */
    reviewOf(root: string, product?: string): Promise<{
        keyVariable: string;
        model: string;
    }>;
    /** The project's `.env` under the process environment. */
    environment(root: string): Record<string, string | undefined>;
};
export declare class DecisionJudgeAdapter implements DecisionJudgeAcl {
    private readonly settings;
    constructor(settings: Settings);
    judgeOf(root: string, product?: string): Promise<Judge | null>;
    recorded(root: string, name: string, model: string, request: JudgementRequest): any;
    record(root: string, name: string, model: string, request: JudgementRequest, probability: number): void;
    private file;
    private read;
    private fingerprint;
}
export {};

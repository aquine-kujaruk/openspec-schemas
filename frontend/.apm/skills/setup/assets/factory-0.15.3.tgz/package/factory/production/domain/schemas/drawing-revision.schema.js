import { z } from "zod";
import { DecidedBySchema } from "./decision.schema.js";
const RequirementChangeSchema = z.object({
    name: z.string().min(1),
    operation: z.enum(["adds", "modifies", "removes", "renames"]).optional(),
    by: DecidedBySchema.optional(),
});
export const DrawingRevisionSchema = z.object({
    drawing: z.string().min(1),
    requirements: z.array(RequirementChangeSchema),
});

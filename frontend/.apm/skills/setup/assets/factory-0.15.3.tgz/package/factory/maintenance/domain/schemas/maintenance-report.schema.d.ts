import { z } from "zod";
export declare const MaintenanceReportSchema: any;
export type MaintenanceReportProps = z.input<typeof MaintenanceReportSchema>;

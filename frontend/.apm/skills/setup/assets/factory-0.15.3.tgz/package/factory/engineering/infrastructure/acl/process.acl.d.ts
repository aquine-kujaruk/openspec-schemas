import { z } from "zod";
import type { CoreDefinition, SchemaDefinition, SchemaVariant, Topology, WorkstreamDeclaration } from "../../../shared/domain/schemas/line-types.schema.js";
import type { ProjectConfig } from "../../../shared/domain/schemas/configuration.schema.js";
export type { CoreDefinition, ProjectConfig, SchemaDefinition, SchemaVariant, Topology, WorkstreamDeclaration };
export type CatalogResourceKind = "core" | "workstream" | "validator" | "question policy" | "template";
/** The process definition and the resources it names, read from the package. */
export type CatalogSchema<V = unknown> = {
    definition: SchemaDefinition;
    workstreams: Record<string, WorkstreamDeclaration>;
    validator: V;
    questions: string;
    templates: Record<string, string>;
    workstreamDirs: Record<string, string>;
    rubrics: string[];
    resources: Array<{
        kind: CatalogResourceKind;
        id: string;
        file: string;
    }>;
};
export type MisplacedResource = {
    kind: CatalogResourceKind;
    id: string;
    held: string[];
    belongs: string;
};
export declare const ProcessRecordSchema: any;
export type ProcessRecord = z.infer<typeof ProcessRecordSchema>;
export interface ProcessAcl {
    listProcesses(): Promise<ProcessRecord[]>;
}

import { z } from "zod";
export declare const GaugeSchema: any;
export type GaugeProps = z.input<typeof GaugeSchema>;

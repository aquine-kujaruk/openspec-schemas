import { existsSync, readFileSync } from "node:fs";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { runtime } from "../../../shared/infrastructure/adapters/runtime.adapter.js";
export class WriteBoundaryAdapter {
    root;
    cwd;
    configuration;
    constructor(root, cwd, configuration) {
        this.root = root;
        this.cwd = cwd;
        this.configuration = configuration;
    }
    readConfiguration() {
        return this.configuration();
    }
    projectPath(file) {
        const path = relative(this.root, resolve(this.cwd, file)).split("\\").join("/");
        return path.startsWith("..") || isAbsolute(path) ? null : path;
    }
    static projectOf(cwd) {
        for (let dir = resolve(cwd);; dir = dirname(dir)) {
            if (existsSync(join(dir, "openspec")))
                return dir;
            if (dirname(dir) === dir)
                return resolve(cwd);
        }
    }
    static hookInput() {
        if (runtime.interactive())
            return {};
        const text = readFileSync(0, "utf8").trim();
        return text ? JSON.parse(text) : {};
    }
}

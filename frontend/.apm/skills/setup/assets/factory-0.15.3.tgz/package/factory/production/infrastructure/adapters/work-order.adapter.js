import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
export class WorkOrderAdapter {
    directory;
    inventory;
    read;
    constructor(directory, inventory, read) {
        this.directory = directory;
        this.inventory = inventory;
        this.read = read;
    }
    listOrders() { return this.inventory(); }
    readOrder(name) { return this.read(name); }
    async writeRelease(name, day) {
        const file = join(this.directory, name, "plan.md");
        const text = readFileSync(file, "utf8");
        const updated = text.replace(/^---\r?\n([\s\S]*?)^---\s*$/m, (_, front) => {
            const body = front.replace(/^approved_at:[^\r\n]*(?:\r?\n)?/m, "");
            return `---\n${body}${day ? `approved_at: ${day}\n` : ""}---`;
        });
        if (text !== updated)
            writeFileSync(file, updated, "utf8");
    }
}

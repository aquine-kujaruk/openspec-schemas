import { validateSchema } from "../schemas/validation.schema.js";
import { ProcessNameSchema } from "../schemas/process-name.schema.js";
export class ProcessName {
    value;
    constructor(props) {
        validateSchema(this, ProcessNameSchema, props);
    }
    equals(other) {
        return this.value === other.value;
    }
}

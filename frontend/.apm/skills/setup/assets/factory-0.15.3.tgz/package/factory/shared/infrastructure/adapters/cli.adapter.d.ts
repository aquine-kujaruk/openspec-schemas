import type { CliHost } from "./cli-contract.adapter.js";
export declare const cleanTestEnvironment: () => void;
export declare const argumentsOf: () => string[];
export declare const exit: (status: number) => never;
export declare const createHost: (root: string, project: string, extension: string, products: CliHost["products"], capture: (command: string, args: string[], options: {
    cwd: string;
    env: NodeJS.ProcessEnv;
    show: boolean;
}) => {
    status: number;
}) => CliHost;

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { Plan } from "../entities/plan.entity.js";
import { WorkOrderException } from "../exceptions/work-order.exceptions.js";
import { WorkOrderSchema } from "../schemas/work-order.schema.js";
export class WorkOrder {
    name;
    process;
    line;
    revisions;
    andonPulls;
    currentPlan;
    constructor(props) {
        validateSchema(this, WorkOrderSchema, props);
    }
    get plan() {
        return this.currentPlan;
    }
    release(on) {
        if (this.plan.openQuestions.length)
            throw new WorkOrderException("the plan has open questions");
        this.currentPlan = new Plan({ ...this.plan, releasedOn: on });
    }
    startNextStage() {
        this.requireRelease();
        const next = this.plan.stages.find((stage) => !stage.complete);
        if (!next)
            throw new WorkOrderException("nothing to build");
        return next;
    }
    close(on) {
        this.requireRelease();
        return {
            name: this.name,
            process: this.process,
            line: this.line,
            plan: this.plan,
            revisions: [...this.revisions],
            andonPulls: [...this.andonPulls],
            closedOn: on,
        };
    }
    requireRelease() {
        if (!this.plan.releasedOn)
            throw new WorkOrderException("the plan has not been released");
        if (this.plan.openQuestions.length)
            throw new WorkOrderException("the plan has open questions");
    }
}

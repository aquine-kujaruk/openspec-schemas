import { readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
export class AndonAdapter {
    directory;
    gate;
    signals;
    constructor(directory, gate, signals) {
        this.directory = directory;
        this.gate = gate;
        this.signals = signals;
    }
    async readPlan(name) {
        return readFileSync(join(this.directory, name, "plan.md"), "utf8");
    }
    async savePlan(name, text) {
        writeFileSync(join(this.directory, name, "plan.md"), text, "utf8");
    }
    async closeSignal(name, source) {
        const left = this.signals(name).filter((report) => report.source !== source);
        const file = join(this.directory, name, "feedback.json");
        if (left.length)
            writeFileSync(file, `${JSON.stringify(left, null, 2)}\n`);
        else
            rmSync(file, { force: true });
        rmSync(join(this.directory, name, this.gate), { force: true });
    }
}

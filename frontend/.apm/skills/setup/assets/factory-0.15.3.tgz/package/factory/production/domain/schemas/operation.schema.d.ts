import { z } from "zod";
export type WorkCenterId = string;
export declare const OperationSchema: any;
export type OperationProps = z.input<typeof OperationSchema>;

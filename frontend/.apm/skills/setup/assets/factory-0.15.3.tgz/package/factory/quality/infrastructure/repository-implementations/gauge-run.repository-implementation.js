export class GaugeRunRepositoryImplementation {
    tool;
    constructor(tool) {
        this.tool = tool;
    }
    runGauges(args) {
        return this.tool.runGauges(args);
    }
}

import { z } from "zod";
import type { Architecture, FactoryConfig, SchemaDefinition } from "../../../shared/domain/schemas/line-types.schema.js";
import type { ProductEntry, ProjectConfig, resolveConfig } from "../../../shared/domain/schemas/configuration.schema.js";
import type { CatalogSchema } from "./process.acl.js";
export type { ProductEntry, ProjectConfig };
/** A named product and its resolved configuration, or the implicit product at the project root. */
export type Product = {
    name: string;
    root: string;
    schema: string;
    config: FactoryConfig;
    elsewhere: string[];
};
export type ProductDefinitions = {
    loadDefinition(name: string, root?: string): Promise<SchemaDefinition>;
    loadHolder(name: string, root?: string): Promise<Pick<CatalogSchema, "definition">>;
    projectSchemaName(project: string, root?: string): Promise<string>;
};
export type ProductConfiguration = typeof resolveConfig;
export type { Architecture, FactoryConfig };
export type { Folders as WorkCenterFolders, } from "../../domain/services/work-center-topology.service.js";
export type BuildWorkstreams = typeof import("../../domain/services/work-center-topology.service.js").WorkCenterTopologyService.loadWorkstreams;
export type ActiveProjectDefinitions<V> = {
    loadHolder(name: string): Promise<CatalogSchema<V>>;
    currentProduct(root: string): Promise<Product>;
};
declare const roots: any;
export declare const PlantRecordSchema: any;
export type PlantRecord = z.infer<typeof PlantRecordSchema>;
export type RootRecord = z.infer<typeof roots>;
export interface PlantAcl {
    readPlant(): Promise<PlantRecord>;
    prepareRoots(root: string, inputs: RootRecord): Promise<string[]>;
}

import { DomainException } from "./domain.exceptions.js";
/** The decision model could not be asked: the service failed or refused the request. */
export declare class DecisionModelUnavailable extends DomainException {
}

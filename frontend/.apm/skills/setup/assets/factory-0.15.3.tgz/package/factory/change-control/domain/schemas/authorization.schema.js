import { z } from "zod";
import { ProtectedArea } from "../value-objects/protected-area.value-object.js";
const RefusalSchema = z.object({
    path: z.string(), part: z.string().optional(), reason: z.string(),
});
export const AuthorizationSchema = z.object({
    blockedBy: z.instanceof(ProtectedArea).optional(),
    refusals: z.array(RefusalSchema),
});

import { type MaintenanceItemProps } from "../schemas/maintenance-item.schema.js";
export declare class MaintenanceItem {
    readonly kind: MaintenanceItemProps["kind"];
    readonly requirement: string;
    readonly detail: string;
    readonly agent?: string;
    readonly repaired: boolean;
    constructor(props: MaintenanceItemProps);
    get isLack(): boolean;
    get report(): MaintenanceItemProps["kind"] | "repaired";
}

import * as config from "./shared/domain/schemas/configuration.schema.js";
import * as env from "./shared/infrastructure/adapters/env.adapter.js";
import * as paths from "./shared/infrastructure/adapters/paths.adapter.js";
import * as platform from "./shared/domain/schemas/platform.schema.js";
import * as testing from "./shared/infrastructure/adapters/testing.adapter.js";
import * as types from "./shared/domain/schemas/line-types.schema.js";
export { config, env, paths, platform, testing, types };
export { runtime } from "./shared/infrastructure/adapters/runtime.adapter.js";

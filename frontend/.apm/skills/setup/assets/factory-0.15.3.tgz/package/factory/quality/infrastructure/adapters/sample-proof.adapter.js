import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export const createExpectations = ({ parseExampleFile, findingLines, }) => {
    const expectations = (path) => {
        let file;
        const load = () => (file ??= parseExampleFile(path));
        return {
            check: (name, rule, reported) => {
                const recorded = load().rules.get(rule)?.get(name)?.expected;
                if (!recorded)
                    throw new QualityException(`${path} has no expectation for ${name} under ${rule}: run factory expect`, { cause: { path, name, rule } });
                if (JSON.stringify(findingLines(reported)) !==
                    JSON.stringify(findingLines(recorded)))
                    throw new QualityException(`${name} under ${rule} differs from ${path}`, { cause: { reported: findingLines(reported), recorded: findingLines(recorded) } });
                if (!recorded.size && !name.startsWith("todo."))
                    throw new QualityException(`${name} breaks ${rule} in no file; a counterexample must break its rule (or be prefixed todo.)`, { cause: { name, rule } });
            },
        };
    };
    return { expectations };
};

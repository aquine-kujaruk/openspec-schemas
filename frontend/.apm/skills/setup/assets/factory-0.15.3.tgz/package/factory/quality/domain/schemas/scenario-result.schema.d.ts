import { z } from "zod";
export declare const ScenarioResultSchema: any;
export type ScenarioResultProps = z.input<typeof ScenarioResultSchema>;

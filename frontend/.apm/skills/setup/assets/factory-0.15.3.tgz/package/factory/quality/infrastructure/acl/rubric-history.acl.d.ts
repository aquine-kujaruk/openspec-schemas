import { z } from "zod";
declare const RubricObservationSchema: any;
export declare const RubricHistorySchema: any;
export type RubricObservation = z.infer<typeof RubricObservationSchema>;
export interface RubricHistoryAcl {
    read(id: string): RubricObservation[];
    append(id: string, observation: RubricObservation): Promise<RubricObservation[]>;
}
export {};

import { type InspectionCertificateRecord } from "../acl/final-inspection.acl.js";
import type { QualityCertificateFileAcl } from "../acl/quality-certificate-file.acl.js";
export declare class QualityCertificateFileAdapter implements QualityCertificateFileAcl {
    private readonly root;
    private readonly orders;
    private readonly productRoots;
    constructor(root: string, orders: string, productRoots: (name: string) => Promise<string[]>);
    digestOf(name: string): Promise<string>;
    private path;
    readEvidence(name: string): Pick<InspectionCertificateRecord, "verdict" | "digest"> | undefined;
    writeEvidence(record: InspectionCertificateRecord): void;
}

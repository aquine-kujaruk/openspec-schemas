export class StageStartRepositoryImplementation {
    control;
    constructor(control) {
        this.control = control;
    }
    validateWorkOrder(name) { return this.control.validateWorkOrder(name); }
    prepareStage(name, title) { return this.control.prepareStage(name, title); }
}

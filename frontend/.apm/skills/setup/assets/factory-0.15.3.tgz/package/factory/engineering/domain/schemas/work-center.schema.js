import { z } from "zod";
import { WorkCenterId } from "../value-objects/work-center-id.value-object.js";
import { Part } from "../value-objects/part.value-object.js";
export const WorkCenterSchema = z.object({
    id: z.instanceof(WorkCenterId),
    parts: z.array(z.instanceof(Part)),
    waitsFor: z.array(z.instanceof(WorkCenterId)),
});

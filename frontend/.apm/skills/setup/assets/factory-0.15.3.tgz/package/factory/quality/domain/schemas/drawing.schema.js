import { z } from "zod";
const ScenarioSchema = z.object({ title: z.string().min(1), requirement: z.string().min(1) });
export const DrawingSchema = z.object({
    path: z.string().min(1),
    scenarios: z.array(ScenarioSchema),
});

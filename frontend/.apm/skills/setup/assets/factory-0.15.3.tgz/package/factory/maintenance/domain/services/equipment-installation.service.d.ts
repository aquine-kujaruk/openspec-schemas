export declare const SECTION: {
    start: string;
    end: string;
};
type PinLock = {
    importers?: Record<string, {
        devDependencies?: Record<string, {
            version: string;
        }>;
    }>;
    packages?: Record<string, {
        version?: string;
    }>;
};
export declare class EquipmentInstallationService {
    pinnedVersion(command: string, manifest: {
        devDependencies?: Record<string, string>;
    }, lock: PinLock): string | undefined;
    withSection(own: string | undefined, instructions: string[]): string;
}
export {};

import { type DrawingRevisionProps } from "../schemas/drawing-revision.schema.js";
import type { DrawingPath, RequirementChange } from "../schemas/drawing-revision.schema.js";
export declare class DrawingRevision {
    readonly drawing: DrawingPath;
    readonly requirements: RequirementChange[];
    constructor(props: DrawingRevisionProps);
}

import { z } from "zod";
export const GateRecordSchema = z.object({
    phase: z.string().optional(),
    failures: z.number(),
    waitingFor: z.enum(["the agent", "the person"]),
    findings: z.array(z.string()),
});

import { type AuditFindingProps } from "../schemas/audit-finding.schema.js";
export declare class AuditFinding {
    readonly file: string;
    readonly row: string;
    readonly verdict: "accepted" | "rejected";
    readonly p: number;
    readonly from: number;
    readonly to: number;
    readonly title: string;
    constructor(props: AuditFindingProps);
    format(): string;
}

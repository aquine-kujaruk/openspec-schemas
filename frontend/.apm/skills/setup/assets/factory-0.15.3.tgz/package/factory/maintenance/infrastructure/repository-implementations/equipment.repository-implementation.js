import { ProcessName } from "../../../shared/domain/value-objects/process-name.value-object.js";
import { Equipment } from "../../domain/aggregates/equipment.aggregate.js";
import { MaintenanceException } from "../../domain/exceptions/maintenance.exceptions.js";
export class EquipmentRepositoryImplementation {
    resources;
    constructor(resources) {
        this.resources = resources;
    }
    findEquipment(root) {
        return this.read(() => {
            const found = this.resources.readInstalled(root);
            if (!found)
                return null;
            const { installed, assets } = found;
            return new Equipment({
                name: installed.package,
                version: installed.version,
                processes: installed.schemas.map((value) => new ProcessName({ value })),
                workInstructions: installed.phases,
                controls: installed.guards,
                command: installed.command,
                assets,
                agents: installed.agents,
                instructions: installed.instructions,
                packageManager: installed.packageManager,
                project: installed.project,
            });
        });
    }
    async inspectEquipment(root, equipment, node) {
        return await this.resources.inspectEquipment(root, equipment, node);
    }
    repairEquipment(root, equipment, repair) {
        this.read(() => this.resources.repairEquipment(root, equipment, repair));
    }
    readNotes(root, equipment, env) {
        return this.read(() => this.resources.readNotes(root, equipment, env));
    }
    listProcedures(root) {
        return this.read(() => this.resources.listProcedures(root));
    }
    readHoldings(root) {
        return this.resources.readHoldings(root);
    }
    read(action) {
        try {
            return action();
        }
        catch (cause) {
            throw new MaintenanceException(cause instanceof Error ? cause.message : String(cause), { cause });
        }
    }
}

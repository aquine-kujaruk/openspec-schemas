import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { StandardIdSchema } from "../schemas/standard-id.schema.js";
export class StandardId {
    value;
    constructor(props) {
        validateSchema(this, StandardIdSchema, props);
    }
}

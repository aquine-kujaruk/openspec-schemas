import type { RulesPorts } from "./standard-check-contract.adapter.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createRules: ({ workingDirectory, existsSync, writeFileSync, join, projectFiles, COVERAGE_RULE, layersOf, oxlintOverrides, withUpstream, cacheDir, product, }: RulesPorts) => typeof import("./standard-check-contract.adapter.js");

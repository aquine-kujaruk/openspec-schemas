import { type InspectionVerdict, type QualityCertificateProps } from "../schemas/quality-certificate.schema.js";
import type { ScenarioResult } from "../value-objects/scenario-result.value-object.js";
export declare class QualityCertificate {
    readonly workOrder: string;
    readonly digest: string;
    readonly scenarios: ScenarioResult[];
    readonly failing: QualityCertificateProps["failing"];
    readonly review: QualityCertificateProps["review"];
    readonly procedures: QualityCertificateProps["procedures"];
    readonly e2e?: QualityCertificateProps["e2e"];
    constructor(props: QualityCertificateProps);
    get change(): string;
    get unproved(): ScenarioResult[];
    get unexercised(): QualityCertificateProps["procedures"];
    get verdict(): InspectionVerdict;
}

import { type StageHoldProps } from "../schemas/stage-hold.schema.js";
export declare class StageHold {
    readonly held: boolean;
    readonly reasons: string[];
    constructor(props: StageHoldProps);
    get allowed(): boolean;
}

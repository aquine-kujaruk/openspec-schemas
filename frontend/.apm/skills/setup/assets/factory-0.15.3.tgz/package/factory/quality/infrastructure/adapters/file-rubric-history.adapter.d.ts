import { type RubricHistoryAcl, type RubricObservation } from "../acl/rubric-history.acl.js";
export declare class FileRubricHistoryAdapter implements RubricHistoryAcl {
    private readonly path;
    constructor(path: string);
    private load;
    read(id: string): RubricObservation[];
    append(id: string, observation: RubricObservation): Promise<RubricObservation[]>;
}

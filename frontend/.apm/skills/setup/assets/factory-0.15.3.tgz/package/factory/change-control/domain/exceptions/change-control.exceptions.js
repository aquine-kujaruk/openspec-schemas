import { DomainException } from "../../../shared/domain/exceptions/domain.exceptions.js";
export class ChangeControlException extends DomainException {
}

import { z } from "zod";
export declare const PartSchema: any;
export type PartProps = z.infer<typeof PartSchema>;

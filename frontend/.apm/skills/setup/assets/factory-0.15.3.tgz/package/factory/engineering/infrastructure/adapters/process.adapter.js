export class ProcessAdapter {
    load;
    constructor(load) {
        this.load = load;
    }
    listProcesses() {
        return this.load();
    }
}

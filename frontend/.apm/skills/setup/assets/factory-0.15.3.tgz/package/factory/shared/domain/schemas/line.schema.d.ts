import { z } from "zod";
export declare const LineSchema: any;
export type LineProps = z.infer<typeof LineSchema>;

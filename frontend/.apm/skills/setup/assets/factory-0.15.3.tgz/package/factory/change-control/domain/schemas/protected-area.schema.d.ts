import { z } from "zod";
export declare const ProtectedAreaSchema: any;
export type ProtectedAreaProps = z.input<typeof ProtectedAreaSchema>;

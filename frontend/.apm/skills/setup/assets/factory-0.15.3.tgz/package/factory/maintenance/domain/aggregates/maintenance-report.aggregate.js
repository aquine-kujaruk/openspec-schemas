import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { MaintenanceReportSchema } from "../schemas/maintenance-report.schema.js";
export class MaintenanceReport {
    items;
    constructor(props) {
        validateSchema(this, MaintenanceReportSchema, props);
    }
    get status() {
        return this.items.some((item) => item.isLack && !item.repaired) ? 1 : 0;
    }
}

import { type ProtectedAreaProps } from "../schemas/protected-area.schema.js";
export declare class ProtectedArea {
    readonly name: string;
    readonly patterns: string[];
    readonly guidance: string;
    readonly suffix?: string;
    readonly regularExpression?: boolean;
    constructor(props: ProtectedAreaProps);
    covers(path: string): boolean;
}

import type { AndonSignalAcl, Raised } from "../acl/andon-signal.acl.js";
/** Who raises feedback about a change. */
export declare const SOURCES: readonly ["the person", "the completion gate", "the verify phase", "the archive", "the implement phase"];
export declare class AndonSignalAdapter implements AndonSignalAcl {
    raised(root: string, change: string): Raised[];
    /** Records feedback about `change` for the feedback phase to take in. */
    raise(root: string, change: string, feedback: Raised): void;
}

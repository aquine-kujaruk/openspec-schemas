import { z } from "zod";
export const DecidedBySchema = z.enum(["person", "agent"]);
export const DecisionSchema = z.object({
    text: z.string().min(1),
    by: DecidedBySchema,
});

import type { ClosingAcl } from "../acl/closing.acl.js";
export declare class ClosingAdapter implements ClosingAcl {
    private readonly root;
    private readonly directory;
    private readonly openSpec;
    private readonly projections;
    constructor(root: string, directory: string, openSpec: (name: string) => {
        status: number;
        output: string;
    }, projections: Omit<ClosingAcl, "today" | "readPlan" | "readStandingFile" | "closeArchive">);
    today(): any;
    listOrders(): any;
    findCertificate(name: string): any;
    currentDigest(name: string): any;
    validateWorkOrder(name: string): any;
    listStanding(): any;
    recordFinding(name: string, block: string, message: string): any;
    makeGauges(): any;
    readPlan(name: string): unknown;
    readStandingFile(path: string): unknown;
    closeArchive(name: string, origin: string, documents: {
        path: string;
        before: string | null;
        after: string | null;
    }[]): unknown;
}

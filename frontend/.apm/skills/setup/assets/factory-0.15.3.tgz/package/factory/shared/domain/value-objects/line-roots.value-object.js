import { validateSchema } from "../schemas/validation.schema.js";
import { LineRootsSchema } from "../schemas/line-roots.schema.js";
export class LineRoots {
    modules;
    productSpecs;
    entry;
    acceptance;
    unit;
    integration;
    e2e;
    ignore;
    base;
    allowUnmatched;
    constructor(props) {
        validateSchema(this, LineRootsSchema, props);
    }
}

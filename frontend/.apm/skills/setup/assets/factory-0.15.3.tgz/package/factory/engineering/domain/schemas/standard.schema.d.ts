import { z } from "zod";
export declare const StandardSchema: any;
export type StandardProps = z.infer<typeof StandardSchema>;

import type { StageStartAcl } from "../acl/stage-start.acl.js";
export declare class StageStartAdapter implements StageStartAcl {
    private readonly directory;
    private readonly gate;
    private readonly assess;
    private readonly builds;
    private readonly run;
    constructor(directory: string, gate: string, assess: StageStartAcl["validateWorkOrder"], builds: (name: string) => Promise<{
        code: boolean;
        line?: string;
    }>, run: (args: string[]) => {
        status: number;
        output: string;
    });
    validateWorkOrder(name: string): any;
    prepareStage(name: string, phase: string): Promise<{
        success: boolean;
        output: string;
    }>;
}

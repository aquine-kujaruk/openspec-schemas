import type { EquipmentRepositoryInterface } from "../repository-interfaces/equipment.repository-interface.js";
export declare class FindSuspectProceduresUseCase {
    private readonly equipment;
    private readonly inspection;
    constructor(equipment: EquipmentRepositoryInterface);
    execute(root: string): Promise<string[]>;
}

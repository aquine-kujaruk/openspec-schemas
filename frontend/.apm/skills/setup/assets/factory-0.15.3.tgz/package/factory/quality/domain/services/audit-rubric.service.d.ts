import type { AuditRubric, AuditRow as Row, LoadedAuditRow as LoadedRow } from "../schemas/audit-material.schema.js";
export declare class AuditRubricService {
    /** The rows of the rubric table and the product vocabulary its header lists. */
    parseRubric(markdown: string): {
        rows: Row[];
        product: string[];
    };
    /**
     * A question is generic when it names no package of the harness and no word of the product
     * vocabulary; it then reads the same in every application built with the package.
     */
    checkGeneric(question: string, vocabulary: {
        packages: string[];
        product: string[];
    }): string | undefined;
    /** Every row with its verdict: a row that is not generic, or has no question, is rejected and never asked. */
    loadRubric(markdown: string, packages: string[]): LoadedRow[];
    loadDocuments(documents: AuditRubric[], packages: string[]): LoadedRow[];
}

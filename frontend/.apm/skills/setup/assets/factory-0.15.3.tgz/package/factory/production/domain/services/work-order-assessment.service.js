export class WorkOrderAssessmentService {
    /**
     * In a project that declares products: the change names one of them (`x-product`), made with the
     * schema that product is declared with.
     */
    productFindings(change, products) {
        const names = Object.keys(products);
        if (!names.length)
            return [];
        const rule = "names-a-product";
        if (!change.product)
            return [
                {
                    rule,
                    message: `the project declares the products ${names.join(", ")}: write the one this change builds as \`x-product\` in its .openspec.yaml`,
                },
            ];
        const product = products[change.product];
        if (!product)
            return [
                {
                    rule,
                    message: `the change names the product ${change.product}, which the project does not declare; products: ${names.join(", ")}`,
                },
            ];
        if (product.schema !== change.schema)
            return [
                {
                    rule,
                    message: `the product ${change.product} is built with the schema ${product.schema}, and this change was made with ${change.schema}: open the change with the product's schema, or name a product of ${change.schema}`,
                },
            ];
        return [];
    }
    /** Every change this one links (`x-linked`) exists, active or archived, and links it back. */
    linkFindings(change, lookup) {
        return change.linked.flatMap((name) => {
            const other = lookup(name);
            if (!other)
                return [
                    {
                        rule: "links-hold",
                        message: `the change links ${name}, which is no change of this project, active or archived`,
                    },
                ];
            if (!other.linked.includes(change.name))
                return [
                    {
                        rule: "links-hold",
                        message: `the change links ${name}, which does not link it back: add ${change.name} to \`x-linked\` in ${name}'s .openspec.yaml`,
                    },
                ];
            return [];
        });
    }
}

import { z } from "zod";
import { LineName } from "../value-objects/line-name.value-object.js";
import { ProcessName } from "../value-objects/process-name.value-object.js";
import { LineRoots } from "../value-objects/line-roots.value-object.js";
export const LineSchema = z.object({
    name: z.instanceof(LineName),
    folder: z.string().min(1),
    process: z.instanceof(ProcessName),
    roots: z.instanceof(LineRoots),
});

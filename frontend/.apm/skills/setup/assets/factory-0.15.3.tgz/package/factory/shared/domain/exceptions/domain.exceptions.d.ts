export declare class DomainException extends Error {
    constructor(message: string, options?: {
        cause?: unknown;
    });
}

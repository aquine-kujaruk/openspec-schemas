import { NotValidatable } from "../../domain/exceptions/work-order.exceptions.js";
export class ProjectDrawingsUseCase {
    drawings;
    assess;
    constructor(drawings, assess) {
        this.drawings = drawings;
        this.assess = assess;
    }
    async execute(root) {
        const found = [];
        for (const change of this.drawings.listWorkOrders(root)) {
            if (!change.deltaSpecs.length)
                continue;
            const { name } = change;
            try {
                if ((await this.assess.execute(root, name)).ready)
                    found.push({ name, created: change.created ?? "" });
            }
            catch (e) {
                if (!(e instanceof NotValidatable))
                    throw e;
            }
        }
        const ready = found
            .sort((a, b) => a.created.localeCompare(b.created) || a.name.localeCompare(b.name))
            .map((c) => c.name);
        return ready.length ? this.drawings.mergeDrawings(root, ready) : undefined;
    }
}

import { type PlantProps } from "../schemas/plant.schema.js";
import type { Line } from "../entities/line.entity.js";
import type { LineName } from "../value-objects/line-name.value-object.js";
export declare class Plant {
    readonly root: string;
    readonly lines: Line[];
    constructor(props: PlantProps);
    findLine(name: LineName): Line | undefined;
}

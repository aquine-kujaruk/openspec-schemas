import type { StageStartRepositoryInterface } from "../../application/repository-interfaces/stage-start.repository-interface.js";
import type { StageStartAcl } from "../acl/stage-start.acl.js";
export declare class StageStartRepositoryImplementation implements StageStartRepositoryInterface {
    private readonly control;
    constructor(control: StageStartAcl);
    validateWorkOrder(name: string): any;
    prepareStage(name: string, title: string): any;
}

import { type StageProps } from "../schemas/stage.schema.js";
import type { Operation } from "../value-objects/operation.value-object.js";
export declare class Stage {
    readonly title: string;
    readonly operations: Operation[];
    constructor(props: StageProps);
    get complete(): boolean;
}

import type { DrawingProjectionAcl } from "../acl/drawing-projection.acl.js";
export declare class DrawingProjectionAdapter implements DrawingProjectionAcl {
    /** Runs the specification tool in the project at `root`. */
    openspec(root: string, args: string[]): {
        status: any;
        output: any;
    };
    mergeDrawings(root: string, changes: string[]): {
        root: any;
        changes: string[];
        dispose: () => any;
    };
}

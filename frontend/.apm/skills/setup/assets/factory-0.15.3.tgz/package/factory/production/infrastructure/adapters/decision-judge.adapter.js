import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { z } from "zod";
import { DECISIONS_ENDPOINT, decisionModelClient } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
import { CHANGES } from "./work-order-record.adapter.js";
import { JudgementUnanswered } from "../../domain/exceptions/work-order.exceptions.js";
/** The file of a change that records the decision model's answers. */
export const JUDGEMENTS = "judgements.json";
const QUESTION = "basis-holds";
const RecordSchema = z.array(z.object({ block: z.string(), model: z.string(), fingerprint: z.string(), probability: z.number() }));
export class DecisionJudgeAdapter {
    settings;
    constructor(settings) {
        this.settings = settings;
    }
    async judgeOf(root, product) {
        let review;
        try {
            review = await this.settings.reviewOf(root, product);
        }
        catch {
            return null;
        }
        const env = this.settings.environment(root);
        const key = env[review.keyVariable];
        if (!key)
            return null;
        const client = decisionModelClient({
            key,
            model: review.model,
            endpoint: env.FACTORY_DECISIONS_ENDPOINT || DECISIONS_ENDPOINT,
            timeoutMs: 30_000,
        });
        return {
            model: review.model,
            async ask(request) {
                const answers = await client.ask(request.state, [{ name: QUESTION, instructions: request.instructions }]);
                const probability = answers.get(QUESTION);
                if (probability === undefined)
                    throw new JudgementUnanswered("decision model: no answer to the basis question", { cause: answers });
                return probability;
            },
        };
    }
    recorded(root, name, model, request) {
        const fingerprint = this.fingerprint(request);
        return this.read(root, name).find((r) => r.block === request.block && r.model === model && r.fingerprint === fingerprint)
            ?.probability;
    }
    record(root, name, model, request, probability) {
        const fingerprint = this.fingerprint(request);
        const kept = this.read(root, name).filter((r) => !(r.block === request.block && r.model === model));
        kept.push({ block: request.block, model, fingerprint, probability });
        writeFileSync(this.file(root, name), `${JSON.stringify(kept, null, 2)}\n`);
    }
    file(root, name) {
        return join(root, CHANGES, name, JUDGEMENTS);
    }
    read(root, name) {
        const file = this.file(root, name);
        if (!existsSync(file))
            return [];
        const parsed = RecordSchema.safeParse(JSON.parse(readFileSync(file, "utf8")));
        return parsed.success ? parsed.data : [];
    }
    fingerprint(request) {
        return createHash("sha256").update(`${request.instructions}\n${request.state}`).digest("hex");
    }
}

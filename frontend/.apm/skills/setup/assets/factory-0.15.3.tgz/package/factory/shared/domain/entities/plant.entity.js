import { validateSchema } from "../schemas/validation.schema.js";
import { PlantSchema } from "../schemas/plant.schema.js";
export class Plant {
    root;
    lines;
    constructor(props) {
        validateSchema(this, PlantSchema, props);
    }
    findLine(name) {
        return this.lines.find((line) => line.name.equals(name));
    }
}

type FileInfo = {
    path: string;
    name: string;
    content: string;
};
import type { Rule, RuleContext } from "../../../shared/domain/schemas/line-types.schema.js";
export declare const has: (re: RegExp) => (file: FileInfo) => any;
export declare const not: (re: RegExp) => (file: FileInfo) => boolean;
/** `invoice-book` → `InvoiceBook`. */
export declare const pascal: (kebab: string) => string;
/** A constructor parameter: its name and declared type (`undefined` when it declares none). */
export type Param = {
    name: string;
    type?: string;
};
/** The parameters of every `constructor(` in `content`, in order, modifiers and defaults dropped. */
export declare const constructorParams: (content: string) => Param[][];
/** The body of the first `constructor` in `content` (without its braces), or `undefined`. */
export declare const constructorBody: (content: string) => string | undefined;
/** Every `throw new X(` in `content`: the class and the text of its arguments. */
export declare const throws: (content: string) => Array<{
    name: string;
    args: string;
}>;
/** A named import: the names it binds and where it resolves to (relative specifiers resolved from `path`, bare ones kept). */
export type Import = {
    names: string[];
    specifier: string;
    resolved: string;
};
/** The `import { … } from "…"` statements of a file, each with its specifier resolved from the file's folder. */
export declare const importsOf: (file: Pick<FileInfo, "path" | "content">) => Import[];
/** `content` without its comments and string literals, so a word search finds code only. */
export declare const codeOnly: (content: string) => string;
/** A class declaration read from its header: `[export] [abstract] class Name [extends Base] [implements I, J] {`. */
export type ClassDecl = {
    name: string;
    exported: boolean;
    abstract: boolean;
    extends?: string;
    implements: string[];
};
/** Class declarations of a file. Generic arguments are dropped; a header the regex cannot read reaches nothing. */
export declare const classesOf: (content: string) => ClassDecl[];
export declare class ArchitectureStandardsService {
    readonly vocabularyRules: (id: string, layer: string, modules: string, vocabulary: Record<string, string>) => (ctx: RuleContext) => Rule[];
    readonly namesTheRoleRule: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule;
    readonly throwsDomainExceptionsRule: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule;
}
declare const vocabulary: (id: string, layer: string, modules: string, vocabulary: Record<string, string>) => (ctx: RuleContext) => Rule[], role: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule, exceptions: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule;
export { vocabulary as vocabularyRules, role as namesTheRoleRule, exceptions as throwsDomainExceptionsRule };

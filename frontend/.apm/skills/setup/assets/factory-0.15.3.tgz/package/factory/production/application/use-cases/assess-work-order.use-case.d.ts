import { type Building, type Verdict } from "../../domain/services/work-order-assessment.service.js";
import type { WorkOrderAssessmentRepositoryInterface } from "../repository-interfaces/work-order-assessment.repository-interface.js";
export declare class AssessWorkOrderUseCase {
    private readonly policy;
    private readonly records;
    constructor(records: WorkOrderAssessmentRepositoryInterface);
    /**
     * Whether the change `name` of the project at `root` is ready, by the validator of the schema it
     * was made with. A change with no plan is not ready and nothing else is said about it.
     */
    execute(root: string, name: string): Promise<Verdict>;
    private judgeAndValidate;
    private judge;
    /** The changes in implementation: those the implement phase started and whose plan is still ready. */
    changesInImplementation(root: string): Promise<Building[]>;
}

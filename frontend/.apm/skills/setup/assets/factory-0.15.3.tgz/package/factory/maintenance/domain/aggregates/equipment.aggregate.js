import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { EquipmentSchema } from "../schemas/equipment.schema.js";
export class Equipment {
    name;
    version;
    processes;
    workInstructions;
    controls;
    command;
    assets;
    agents;
    instructions;
    packageManager;
    project;
    constructor(props) {
        validateSchema(this, EquipmentSchema, props);
    }
}

import { z } from "zod";
const roots = z.object({
    modules: z.string(),
    productSpecs: z.string(),
    entry: z.array(z.string()),
    acceptance: z.string(),
    integration: z.string(),
    unit: z.string(),
    e2e: z.string(),
    ignore: z.array(z.string()),
    base: z.array(z.string()).optional(),
    allowUnmatched: z.array(z.string()).optional(),
});
export const PlantRecordSchema = z.object({
    root: z.string(),
    lines: z.array(z.object({
        name: z.string(),
        folder: z.string(),
        process: z.string(),
        roots,
    })),
});

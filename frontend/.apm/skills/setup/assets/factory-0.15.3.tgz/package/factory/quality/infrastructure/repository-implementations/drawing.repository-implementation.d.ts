import type { DrawingAcl } from "../acl/drawing.acl.js";
import type { DrawingRepositoryInterface } from "../../application/repository-interfaces/drawing.repository-interface.js";
export declare class DrawingRepositoryImplementation implements DrawingRepositoryInterface {
    private readonly tool;
    constructor(tool: DrawingAcl);
    makeGauges(args: readonly string[]): unknown;
    private scenarios;
}

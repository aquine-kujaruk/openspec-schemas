import type { ReadingArtifactAcl } from "../acl/reading-artifact.acl.js";
export declare class ReadingArtifactAdapter implements ReadingArtifactAcl {
    private readonly root;
    private readonly language;
    constructor(root: string, language: () => Promise<string | undefined>);
    getLanguage(): unknown;
    readArtifact(path: string): unknown;
    readingPath(language: string, source: string): any;
    readCopy(path: string): unknown;
    recordFingerprint(path: string, hash: string): any;
}

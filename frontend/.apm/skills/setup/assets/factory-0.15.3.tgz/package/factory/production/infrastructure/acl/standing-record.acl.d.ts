export declare const DECISIONS = "openspec/adr";
export declare const PROCEDURES = "openspec/runbooks";
export interface StandingRecordAcl {
    readDocuments(root: string, directory: string): {
        file: string;
        document: string;
    }[];
}

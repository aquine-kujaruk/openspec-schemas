import { type EquipmentAcl, type EquipmentAuthority, type EquipmentInstallation } from "../acl/equipment.acl.js";
export declare class EquipmentAdapter implements EquipmentAcl {
    private readonly authority;
    constructor(authority: EquipmentAuthority);
    readInstalled(root: string): EquipmentInstallation | undefined;
    pinnedVersion(root: string): string | undefined;
    schemaLinkHolds(root: string, schema: string): boolean;
    unwiredGuards(root: string, agent: string): string[];
    inspectEquipment(root: string, equipment: Parameters<EquipmentAcl["inspectEquipment"]>[1], node?: any): ReturnType<EquipmentAcl["inspectEquipment"]>;
    repairEquipment(root: string, equipment: Parameters<EquipmentAcl["repairEquipment"]>[1], repair: Parameters<EquipmentAcl["repairEquipment"]>[2]): void;
    readNotes(root: string, equipment: Parameters<EquipmentAcl["readNotes"]>[1], env?: any): ReturnType<EquipmentAcl["readNotes"]>;
    listProcedures(root: string): any;
    readHoldings(root: string): ReturnType<EquipmentAcl["readHoldings"]>;
    holdingsOf(root: string, roots: string[]): Awaited<ReturnType<EquipmentAcl["readHoldings"]>>;
}

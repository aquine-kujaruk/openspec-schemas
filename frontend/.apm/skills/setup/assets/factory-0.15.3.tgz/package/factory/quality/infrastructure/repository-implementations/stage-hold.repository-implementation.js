import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
import { GateRecordSchema } from "../acl/stage-hold.acl.js";
export class StageHoldRepositoryImplementation {
    records;
    constructor(records) {
        this.records = records;
    }
    listBuilding() {
        return this.records.buildingRecords();
    }
    hasCurrentVerification(name) {
        return this.records.hasCurrentVerification(name);
    }
    listHarnessFindings() {
        return this.records.harnessFindings();
    }
    listWorkstreams(stage) {
        return this.records.workstreams(stage);
    }
    async readRecord(name) {
        try {
            return GateRecordSchema.parse(await this.records.readRecord(name) ?? {
                failures: 0, waitingFor: "the agent", findings: [],
            });
        }
        catch (cause) {
            throw new QualityException(`Unable to read the stage hold for ${name}`, { cause });
        }
    }
    saveRecord(name, record) {
        return this.records.writeRecord(name, record);
    }
    resetRecord(name) {
        return this.records.removeRecord(name);
    }
    runCheck(stage, workstream) {
        return this.records.run(stage, ["check", "--workstream", workstream]);
    }
    runTests(stage, kind) {
        return this.records.run(stage, ["test", kind]);
    }
}

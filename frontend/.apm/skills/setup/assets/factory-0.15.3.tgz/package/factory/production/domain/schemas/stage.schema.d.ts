import { z } from "zod";
export declare const StageSchema: any;
export type StageProps = z.input<typeof StageSchema>;

export class ListProcessesUseCase {
    processes;
    constructor(processes) {
        this.processes = processes;
    }
    execute() {
        return this.processes.listProcesses();
    }
}

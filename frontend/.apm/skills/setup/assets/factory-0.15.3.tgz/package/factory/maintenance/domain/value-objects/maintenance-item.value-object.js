import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { MaintenanceItemSchema, MaintenanceKind, } from "../schemas/maintenance-item.schema.js";
export class MaintenanceItem {
    kind;
    requirement;
    detail;
    agent;
    repaired;
    constructor(props) {
        validateSchema(this, MaintenanceItemSchema, props);
    }
    get isLack() {
        return this.kind === MaintenanceKind.Missing || this.kind === MaintenanceKind.Drift;
    }
    get report() {
        return this.repaired ? "repaired" : this.kind;
    }
}

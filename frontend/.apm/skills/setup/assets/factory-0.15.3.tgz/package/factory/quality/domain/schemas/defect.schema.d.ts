import { z } from "zod";
export declare const DefectSchema: any;
export type DefectProps = z.input<typeof DefectSchema>;

import { randomUUID } from "node:crypto";
import { AstBuilder, compile, GherkinClassicTokenMatcher, Parser } from "@cucumber/gherkin";
import { existsSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { cacheDir, capture, runTool, self } from "../../../shared/infrastructure/adapters/paths.adapter.js";
import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
import { FileGaugeReportSchema } from "../acl/final-inspection.acl.js";
export function scenariosOfDelta(file) {
    const feature = runTool("opsx-gherkin", [file], { bin: "opsx-to-feature" });
    if (feature.status !== 0)
        throw new QualityException(`Invalid scenario specification ${file}: ${feature.stderr.trim()}`, { cause: feature });
    const document = new Parser(new AstBuilder(randomUUID), new GherkinClassicTokenMatcher()).parse(feature.stdout);
    const requirements = new Map();
    for (const { rule } of document.feature?.children ?? []) {
        if (!rule || rule.tags.some(tag => ["@openspec-removed", "@openspec-renamed"].includes(tag.name)))
            continue;
        for (const { scenario } of rule.children)
            if (scenario)
                requirements.set(scenario.id, rule.name);
    }
    return compile(document, file, randomUUID).flatMap(scenario => {
        const requirement = requirements.get(scenario.astNodeIds[0]);
        return requirement ? [{ requirement, scenario: scenario.name }] : [];
    });
}
export class FinalInspectionAdapter {
    root;
    resources;
    certificates;
    constructor(root, resources, certificates) {
        this.root = root;
        this.resources = resources;
        this.certificates = certificates;
    }
    load() {
        return Promise.resolve(this.resources.snapshot);
    }
    get selection() {
        return this.resources.line ? ["--product", this.resources.line] : [];
    }
    async gauges(files) {
        const report = join(cacheDir(this.root), "evidence.json");
        rmSync(report, { force: true });
        if (this.resources.snapshot.repository)
            capture("pnpm", ["exec", "vitest", "run", ...files, "--reporter=json", `--outputFile=${report}`], { cwd: this.root });
        else
            await this.run(["test", "acceptance", "--report", report]);
        if (!existsSync(report))
            return [];
        try {
            const raw = JSON.parse(readFileSync(report, "utf8"));
            return FileGaugeReportSchema.parse(raw).testResults;
        }
        catch (cause) {
            throw new QualityException(`Invalid Vitest assertion report in ${report}`, { cause });
        }
    }
    async run(args) {
        return self(this.root, [...args, ...this.selection]);
    }
    async endToEnd() {
        const report = join(cacheDir(this.root), "e2e.json");
        rmSync(report, { force: true });
        const result = await this.run(["test", "e2e", "--report", report]);
        if (result.status !== 0 && result.status !== 1)
            return [{ test: "the end-to-end run", result: "failed", output: result.output }];
        return existsSync(report)
            ? JSON.parse(readFileSync(report, "utf8")).tests
            : [];
    }
    async findWorkstream(file) {
        return this.resources.findWorkstream(file);
    }
    async audit() {
        const result = self(this.root, ["review", ...this.selection], this.resources.auditEnvironment);
        if (result.status !== 0)
            throw new QualityException(result.output, { cause: result });
        return result.output.split("\n").filter((line) => /^S\d{2} p=/.test(line));
    }
    digest(name) {
        return this.certificates.digestOf(name);
    }
    async save(record) {
        this.certificates.writeEvidence(record);
    }
    async feedback(name, finding) {
        this.resources.feedback(name, finding);
    }
}

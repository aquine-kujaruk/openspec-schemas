import { DomainException } from "../../../shared/domain/exceptions/domain.exceptions.js";
export class QualityException extends DomainException {
}

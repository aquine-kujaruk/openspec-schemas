import type { MaintenanceItemProps } from "./maintenance-item.schema.js";
export declare const RepairKind: {
    readonly Pin: "pin";
    readonly Link: "link";
    readonly Default: "default";
    readonly Roots: "roots";
    readonly Instruction: "instruction";
};
export type EquipmentRepair = {
    kind: typeof RepairKind.Pin;
    hadPin: boolean;
} | {
    kind: typeof RepairKind.Link;
    schema: string;
} | {
    kind: typeof RepairKind.Default;
} | {
    kind: typeof RepairKind.Roots;
    paths: string[];
} | {
    kind: typeof RepairKind.Instruction;
    file: string;
    before?: string;
};
export type EquipmentFinding = MaintenanceItemProps & {
    repair?: EquipmentRepair;
};
export type AgentReading = {
    name: string;
    skills?: string;
    missingSkills?: string[];
    rules?: string;
    missingRules?: string[];
    instructionFile?: string;
    instructionText?: string;
    unwiredGuards?: string[];
    hooks?: string;
};
export type EquipmentReading = {
    pinned?: string;
    links: Array<{
        schema: string;
        path: string;
        holds: boolean;
        ownFolder: boolean;
    }>;
    hasDefault: boolean;
    missingRoots: string[];
    declared: Record<string, string>;
    web: boolean;
    node: string;
    agents: AgentReading[];
};
export type EquipmentNotes = {
    missingKeys: Array<{
        name: string;
        slug: string;
        file: string;
    }>;
    packageManagerVersion?: string;
    pendingApprovals: boolean;
    typeCheckerVersion?: string;
};
export type EquipmentPlace = {
    skills: string;
    instruction: {
        rules: string;
    } | {
        file: string;
    };
    hooks: string;
};

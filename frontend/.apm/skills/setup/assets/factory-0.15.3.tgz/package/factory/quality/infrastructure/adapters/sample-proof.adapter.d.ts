import type { ExpectationsPorts } from "./sample-proof-contract.adapter.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createExpectations: ({ parseExampleFile, findingLines, }: ExpectationsPorts) => typeof import("./sample-proof-contract.adapter.js");

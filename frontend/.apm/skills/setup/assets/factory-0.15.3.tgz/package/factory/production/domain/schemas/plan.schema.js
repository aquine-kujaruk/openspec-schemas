import { z } from "zod";
import { Stage } from "../entities/stage.entity.js";
import { Decision } from "../value-objects/decision.value-object.js";
import { DaySchema } from "./day.schema.js";
export const PlanSchema = z.object({
    stages: z.array(z.instanceof(Stage)),
    decisions: z.array(z.instanceof(Decision)).default([]),
    openQuestions: z.array(z.string()).default([]),
    releasedOn: DaySchema.optional(),
});

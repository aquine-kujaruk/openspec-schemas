import type { GaugeRunRepositoryInterface } from "../repository-interfaces/gauge-run.repository-interface.js";
export declare class RunGaugesUseCase {
    private readonly repository;
    constructor(repository: GaugeRunRepositoryInterface);
    execute(args: readonly string[]): Promise<number>;
}

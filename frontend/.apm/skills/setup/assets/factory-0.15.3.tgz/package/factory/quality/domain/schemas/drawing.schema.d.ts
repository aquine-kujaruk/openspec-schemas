import { z } from "zod";
declare const ScenarioSchema: any;
export type Scenario = z.input<typeof ScenarioSchema>;
export declare const DrawingSchema: any;
export type DrawingProps = z.input<typeof DrawingSchema>;
export {};

import { indexStanding } from "../../domain/services/standing-records.service.js";
import { DECISIONS, PROCEDURES } from "../acl/standing-record.acl.js";
export class WorkOrderAssessmentRepositoryImplementation {
    orders;
    standing;
    processes;
    judges;
    constructor(orders, standing, processes, judges) {
        this.orders = orders;
        this.standing = standing;
        this.processes = processes;
        this.judges = judges;
    }
    findWorkOrder(root, name) { return this.orders.readChange(root, name); }
    findArchivedWorkOrder(root, name) { return this.orders.readArchivedChange(root, name); }
    listWorkOrders(root) { return this.orders.activeChanges(root); }
    isWorkOrderStarted(root, name) { return this.orders.isStarted(root, name); }
    listStanding(root) {
        return {
            decisions: indexStanding(this.standing.readDocuments(root, DECISIONS), "Decision"),
            procedures: indexStanding(this.standing.readDocuments(root, PROCEDURES), "Procedure"),
        };
    }
    listProcesses() { return this.processes.listProcesses(); }
    loadProcess(name) { return this.processes.loadProcess(name); }
    listProducts(root) { return this.processes.listProducts(root); }
    findJudge(root, product) { return this.judges.judgeOf(root, product); }
    findJudgement(root, name, model, request) {
        return this.judges.recorded(root, name, model, request);
    }
    recordJudgement(root, name, model, request, probability) {
        this.judges.record(root, name, model, request, probability);
    }
}

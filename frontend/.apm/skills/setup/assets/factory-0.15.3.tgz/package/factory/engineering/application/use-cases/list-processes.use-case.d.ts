import type { Process } from "../../domain/aggregates/process.aggregate.js";
import type { ProcessRepositoryInterface } from "../repository-interfaces/process.repository-interface.js";
export declare class ListProcessesUseCase {
    private readonly processes;
    constructor(processes: ProcessRepositoryInterface);
    execute(): Promise<Process[]>;
}

/** The operations a durable block of a plan may declare on the consolidated tree. */
export declare const OPERATIONS: readonly ["adds", "modifies", "replaces", "renames", "removes"];
export type Operation = (typeof OPERATIONS)[number];
/** A tag of a block: `@name` or `@name:value`. */
export type Tag = {
    name: string;
    value?: string;
};
/** A block of a plan: an architecture decision, a procedure or a screen, with the tags under its heading. */
export type Block = {
    slug: string;
    title: string;
    tags: Tag[];
    body: string;
};
/** A checkbox of the plan. `workstream` is what it names before the colon, when it names one. */
export type Task = {
    text: string;
    done: boolean;
    workstream?: string;
};
export type Phase = {
    title: string;
    tasks: Task[];
};
/** A line under `## Decisions`: a decision that matters only to the change, with its tags. */
export type ChangeDecision = {
    text: string;
    tags: Tag[];
};
export type Plan = {
    openQuestions: string[];
    /** The lines under `## Decisions`. */
    changeDecisions: ChangeDecision[];
    /** `approved_at` of the front matter, as written: the day the person approved the plan. */
    approvedAt?: string;
    decisions: Block[];
    procedures: Block[];
    /** The screens a web change spikes, under `## Screens`. */
    screens: Block[];
    phases: Phase[];
    /** Checkboxes that sit outside every phase. */
    strayTasks: Task[];
};
export declare const tagsOf: (line: string) => Tag[];
export declare const operationsOf: (block: Block) => Tag[];
export declare const tagOf: (block: Block, name: string) => Tag | undefined;
/**
 * Reads a plan by its headings: the items under `## Open questions`, the `### Decision:` blocks
 * under `## Architecture decisions`, the `### Procedure:` blocks under `## Procedures`, the
 * `### Screen:` blocks under `## Screens`, the
 * `### Phase` blocks under `## Phases` with their checkboxes, and every checkbox anywhere else.
 * Comments and fenced code hold no heading, tag or checkbox.
 */
export declare const parsePlan: (text: string) => Plan;
/** A requirement a delta spec adds or modifies, with the tags of the first line of its text. */
export type DeltaRequirement = {
    name: string;
    tags: Tag[];
};
/**
 * The requirements under `## ADDED Requirements` and `## MODIFIED Requirements` of a delta spec.
 * A requirement's tags are the backticked tags of the first line of its text (`` `@by:person` ``).
 */
export declare const deltaRequirementsOf: (text: string) => DeltaRequirement[];

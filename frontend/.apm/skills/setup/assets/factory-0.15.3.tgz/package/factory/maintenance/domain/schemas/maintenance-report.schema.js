import { z } from "zod";
import { MaintenanceItem } from "../value-objects/maintenance-item.value-object.js";
export const MaintenanceReportSchema = z.object({ items: z.array(z.instanceof(MaintenanceItem)) });

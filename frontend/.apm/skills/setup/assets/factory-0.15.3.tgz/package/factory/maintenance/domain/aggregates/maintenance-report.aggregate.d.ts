import { type MaintenanceReportProps } from "../schemas/maintenance-report.schema.js";
import type { MaintenanceItem } from "../value-objects/maintenance-item.value-object.js";
export declare class MaintenanceReport {
    readonly items: MaintenanceItem[];
    constructor(props: MaintenanceReportProps);
    get status(): 0 | 1;
}

import { parsePlan } from "../../domain/schemas/plan-document.schema.js";
export class ValidateWorkOrderUseCase {
    records;
    constructor(records) {
        this.records = records;
    }
    async execute(name) {
        const document = await this.records.readPlan(name);
        const findings = [...await this.records.listFindings(name)];
        if (document !== null) {
            const plan = parsePlan(document);
            if (!plan.approvedAt && !findings.some(({ rule }) => rule === "plan-approved"))
                findings.push({ rule: "plan-approved", message: "the person has not approved the plan" });
            if (plan.openQuestions.length && !findings.some(({ rule }) => rule.includes("question")))
                findings.push({ rule: "no-open-questions", message: "the plan lists open questions" });
        }
        return { ready: findings.length === 0, findings };
    }
}

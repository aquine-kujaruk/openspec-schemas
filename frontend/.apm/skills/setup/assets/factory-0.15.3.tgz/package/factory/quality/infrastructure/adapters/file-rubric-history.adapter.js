import { randomUUID } from "node:crypto";
import { closeSync, existsSync, openSync, readFileSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { setTimeout as delay } from "node:timers/promises";
import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
import { RubricHistorySchema } from "../acl/rubric-history.acl.js";
const lockExists = "EEXIST";
export class FileRubricHistoryAdapter {
    path;
    constructor(path) {
        this.path = path;
    }
    load() {
        if (!existsSync(this.path))
            return {};
        try {
            const input = JSON.parse(readFileSync(this.path, "utf8"));
            return RubricHistorySchema.parse(input);
        }
        catch (cause) {
            throw new QualityException(`Invalid rubric score history in ${this.path}`, { cause });
        }
    }
    read(id) {
        return this.load()[id] ?? [];
    }
    async append(id, observation) {
        const path = this.path;
        const lock = path + ".lock";
        const deadline = Date.now() + 10_000;
        while (true) {
            try {
                closeSync(openSync(lock, "wx"));
                break;
            }
            catch (error) {
                if (error.code !== lockExists || Date.now() >= deadline)
                    throw error;
                await delay(20);
            }
        }
        const tmp = path + "." + randomUUID();
        try {
            const all = this.load();
            const previous = all[id] ?? [];
            all[id] = [...previous, observation];
            writeFileSync(tmp, JSON.stringify(all, null, 2) + "\n");
            renameSync(tmp, path);
            return previous;
        }
        finally {
            if (existsSync(tmp))
                unlinkSync(tmp);
            unlinkSync(lock);
        }
    }
}

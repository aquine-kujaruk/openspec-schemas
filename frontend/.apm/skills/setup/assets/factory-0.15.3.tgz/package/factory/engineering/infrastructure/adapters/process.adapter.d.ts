import type { ProcessAcl, ProcessRecord } from "../acl/process.acl.js";
export declare class ProcessAdapter implements ProcessAcl {
    private readonly load;
    constructor(load: () => Promise<ProcessRecord[]>);
    listProcesses(): Promise<ProcessRecord[]>;
}

import { z } from "zod";
export declare const DecidedBySchema: any;
export type DecidedBy = z.infer<typeof DecidedBySchema>;
export declare const DecisionSchema: any;
export type DecisionProps = z.input<typeof DecisionSchema>;

import type { AndonRepositoryInterface } from "../repository-interfaces/andon.repository-interface.js";
export declare class PullAndonUseCase {
    private readonly signals;
    constructor(signals: AndonRepositoryInterface);
    reviewerRepairAction(approvedScope: boolean, determinateRule: boolean): string;
    execute(name: string, feedback: {
        source: string;
        says: string;
        phase?: number;
        questions?: string[];
    }): Promise<void>;
}

import { DomainException } from "./domain.exceptions.js";
export declare class PlantException extends DomainException {
}

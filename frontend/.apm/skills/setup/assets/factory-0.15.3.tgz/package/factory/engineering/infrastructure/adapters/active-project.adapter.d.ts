import type { ActiveProjectDefinitions, BuildWorkstreams } from "../acl/plant.acl.js";
export declare function createActiveProject<V>(PROJECT_ROOT: string, SOURCE_EXT: string, { loadHolder, currentProduct }: ActiveProjectDefinitions<V>, loadWorkstreams: BuildWorkstreams): {
    product: Awaited<ReturnType<ActiveProjectDefinitions<V>>>;
    schema: Awaited<ReturnType<ActiveProjectDefinitions<V>>>;
    WORKSTREAM_DIRS: Record<string, string>;
    RUBRICS: string[];
    EXAMPLE_FILES: string[];
    DEFAULTS: FactoryConfig;
    config: FactoryConfig;
    architecture: Architecture;
    exampleArchitecture: Architecture;
    initialize: () => Promise<void>;
};

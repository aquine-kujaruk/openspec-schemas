import type { Architecture, Layer, OxlintOverride } from "../acl/inspection.acl.js";
/** Pours the architecture into each tool. */
export declare const layersOf: (a: Architecture) => Layer[];
/** every-file-in-a-zone: every file belongs to a zone. fallow enforces it over the whole architecture, not per layer. */
export declare const COVERAGE_RULE = "every-file-in-a-zone";
export declare const oxlintOverrides: (a: Architecture) => OxlintOverride[];
/**
 * The lint configuration that holds only the architecture's rules. The linter reads `files` relative
 * to the configuration file, so a configuration written outside the project names them under `root`.
 */
export declare const oxlintConfig: (overrides: OxlintOverride[], root?: string) => {
    categories: {
        correctness: string;
    };
    overrides: any;
};
export declare const fallowConfig: (a: Architecture) => {
    ignorePatterns: any;
    boundaries: {
        zones: any;
        rules: any;
        calls: {
            forbidden: any;
        };
        coverage: {
            requireAllFiles: boolean;
            allowUnmatched: any;
        };
    };
};

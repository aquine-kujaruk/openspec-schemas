import { EngineeringException } from "../../domain/exceptions/engineering.exceptions.js";
export class PrepareLineUseCase {
    plants;
    constructor(plants) {
        this.plants = plants;
    }
    async execute(name) {
        const plant = await this.plants.getPlant();
        const line = plant.findLine(name);
        if (!line)
            throw new EngineeringException(`Unknown line ${name.value}`);
        return this.plants.prepareRoots(plant, line);
    }
}

import type { ReleasedWorkOrder } from "../../domain/schemas/write-boundary.schema.js";
export interface ReleasedWorkOrderRepositoryInterface {
    listReleasedWorkOrders(): Promise<ReleasedWorkOrder[]>;
}

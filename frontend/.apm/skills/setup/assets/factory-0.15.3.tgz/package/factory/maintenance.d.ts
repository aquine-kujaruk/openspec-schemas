import type { MaintenanceOptions } from "./maintenance/application/repository-interfaces/equipment.repository-interface.js";
export type DoctorReport = {
    items: Array<{
        requirement: string;
        agent?: string;
        report: "missing" | "drift" | "repaired";
        detail: string;
    }>;
    notes: string[];
    suspects: string[];
    status: 0 | 1;
};
export declare function maintainEquipment(args: string[]): Promise<number>;
export declare const installed: {
    PLACES: any;
    readInstalled: any;
};
export declare const doctor: {
    SECTION: any;
    schemaLinkHolds: any;
    unwiredGuards: any;
    pinnedVersion: any;
    withSection: any;
    doctor: (root: string, options?: MaintenanceOptions) => Promise<DoctorReport | undefined>;
    run: typeof maintainEquipment;
    PLACES: any;
    readInstalled: any;
};
export declare const suspects: {
    codeOf: any;
    runsOf: any;
    holdingsOf: any;
    suspectsOf: any;
};

import { DomainException } from "../../../shared/domain/exceptions/domain.exceptions.js";
export class EngineeringException extends DomainException {
}

import { DomainException } from "./domain.exceptions.js";
export class PlantException extends DomainException {
}

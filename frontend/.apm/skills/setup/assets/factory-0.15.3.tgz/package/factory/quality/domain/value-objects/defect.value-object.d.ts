import { type DefectProps } from "../schemas/defect.schema.js";
export declare class Defect {
    readonly file: string;
    readonly standard: string;
    readonly tool: string;
    constructor(props: DefectProps);
}

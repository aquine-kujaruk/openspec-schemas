export class AndonRepositoryImplementation {
    resource;
    constructor(resource) {
        this.resource = resource;
    }
    readPlan(name) {
        return this.resource.readPlan(name);
    }
    savePlan(name, text) {
        return this.resource.savePlan(name, text);
    }
    closeSignal(name, source) {
        return this.resource.closeSignal(name, source);
    }
}

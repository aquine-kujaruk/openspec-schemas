import type { DispatchRepositoryInterface } from "../../application/repository-interfaces/dispatch.repository-interface.js";
import type { DispatchAcl } from "../acl/dispatch.acl.js";
export declare class DispatchRepositoryImplementation implements DispatchRepositoryInterface {
    private readonly resource;
    constructor(resource: DispatchAcl);
    validateWorkOrder(name: string): Promise<{
        ready: boolean;
        findings: {
            rule: string;
            message: string;
        }[];
    }>;
    checkout(path?: string): string;
    getRunner(): Promise<"session" | {
        command: string;
    }>;
    runCommand(command: string): Promise<number | null>;
}

export class MakeGaugesUseCase {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    execute(args) {
        return this.repository.makeGauges(args);
    }
}

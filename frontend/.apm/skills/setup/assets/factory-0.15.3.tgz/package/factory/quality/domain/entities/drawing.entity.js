import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { DrawingSchema } from "../schemas/drawing.schema.js";
export class Drawing {
    path;
    scenarios;
    constructor(props) {
        validateSchema(this, DrawingSchema, props);
    }
}

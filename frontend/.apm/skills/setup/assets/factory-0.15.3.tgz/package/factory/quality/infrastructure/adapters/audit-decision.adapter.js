import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
import { DecisionModelUnavailable, decisionModelClient, } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
export { DECISIONS_ENDPOINT, inspect } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
/** The decision model of the audit: a failure to ask it is a quality failure. */
export const openAiClient = (o) => {
    const client = decisionModelClient(o);
    return {
        get requests() {
            return client.requests;
        },
        async ask(state, questions) {
            try {
                return await client.ask(state, questions);
            }
            catch (e) {
                if (e instanceof DecisionModelUnavailable)
                    throw new QualityException(e.message, { cause: e.cause });
                throw e;
            }
        },
    };
};

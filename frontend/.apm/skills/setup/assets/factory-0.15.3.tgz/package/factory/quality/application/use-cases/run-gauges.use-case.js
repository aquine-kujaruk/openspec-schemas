export class RunGaugesUseCase {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    execute(args) {
        return this.repository.runGauges(args);
    }
}

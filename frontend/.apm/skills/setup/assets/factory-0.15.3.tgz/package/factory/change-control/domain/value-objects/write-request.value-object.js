import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { WriteRequestSchema } from "../schemas/write-request.schema.js";
const PATCH_FILE = /^\*\*\* (?:(?:Add|Update|Delete) File|Move to): (.+)$/gm;
export class WriteRequest {
    files;
    constructor(props) {
        validateSchema(this, WriteRequestSchema, props);
    }
    static fromHook(input) {
        const tool = input?.tool_input ?? {};
        const named = [tool.file_path, tool.notebook_path, tool.path].filter((path) => typeof path === "string");
        const command = Array.isArray(tool.command) ? tool.command.join("\n") : tool.command;
        const patched = typeof command === "string"
            ? [...command.matchAll(PATCH_FILE)].map((match) => match[1].trim())
            : [];
        return new WriteRequest({ files: [...new Set([...named, ...patched])] });
    }
}

import { type StandardProps } from "../schemas/standard.schema.js";
import type { StandardId } from "../value-objects/standard-id.value-object.js";
export declare class Standard {
    readonly id: StandardId;
    readonly title: string;
    constructor(props: StandardProps);
}

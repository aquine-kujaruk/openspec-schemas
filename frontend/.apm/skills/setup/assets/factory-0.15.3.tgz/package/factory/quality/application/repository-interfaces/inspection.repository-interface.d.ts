import type { LineName } from "../../../shared/domain/value-objects/line-name.value-object.js";
import type { QualityControlRun } from "../../domain/aggregates/quality-control-run.aggregate.js";
export interface InspectionRepositoryInterface {
    inspectLine(line: LineName, scope: readonly string[]): Promise<QualityControlRun>;
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { ProcessSchema } from "../schemas/process.schema.js";
import { EngineeringException } from "../exceptions/engineering.exceptions.js";
export class Process {
    name;
    base;
    description;
    pilot;
    workCenters;
    constructor(props) {
        validateSchema(this, ProcessSchema, props);
    }
    executionOrder() {
        const ordered = new Set();
        const visiting = new Set();
        const visit = (center) => {
            if (ordered.has(center))
                return;
            if (visiting.has(center)) {
                throw new EngineeringException(`Work centers form a cycle at ${center.id.value}`);
            }
            visiting.add(center);
            for (const id of center.waitsFor)
                visit(this.workCenter(id));
            visiting.delete(center);
            ordered.add(center);
        };
        for (const center of this.workCenters)
            visit(center);
        return [...ordered];
    }
    prerequisites(id) {
        const selected = this.workCenter(id);
        const upstream = new Set();
        const collect = (center) => {
            for (const id of center.waitsFor) {
                const dependency = this.workCenter(id);
                if (upstream.has(dependency))
                    continue;
                upstream.add(dependency);
                collect(dependency);
            }
        };
        collect(selected);
        return this.executionOrder().filter((center) => upstream.has(center));
    }
    mayRunTogether(left, right) {
        const earlier = this.workCenter(left);
        const later = this.workCenter(right);
        return !this.prerequisites(left).includes(later) &&
            !this.prerequisites(right).includes(earlier);
    }
    workCenter(id) {
        const center = this.workCenters.find((current) => current.id.value === id.value);
        if (!center)
            throw new EngineeringException(`Unknown work center ${id.value}`);
        return center;
    }
}

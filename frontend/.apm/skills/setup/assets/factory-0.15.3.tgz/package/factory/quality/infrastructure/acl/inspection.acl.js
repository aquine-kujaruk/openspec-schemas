import { z } from "zod";
export const InspectionRecordSchema = z.object({
    exitStatus: z.number().int().min(0),
    defects: z.array(z.object({ file: z.string(), standard: z.string(), tool: z.string() })),
});

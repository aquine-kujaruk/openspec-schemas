import { ChangeControlException } from "../../domain/exceptions/change-control.exceptions.js";
import { WriteBoundaryRecordSchema } from "../acl/write-boundary.acl.js";
export class WriteBoundaryRepositoryImplementation {
    files;
    constructor(files) {
        this.files = files;
    }
    async getBoundary() {
        try {
            return WriteBoundaryRecordSchema.parse(await this.files.readConfiguration());
        }
        catch (cause) {
            throw new ChangeControlException("Unable to read the project's write boundaries", { cause });
        }
    }
    findProjectPath(file) {
        return this.files.projectPath(file);
    }
}

import type { ReadingArtifactRepositoryInterface } from "../../application/repository-interfaces/reading-artifact.repository-interface.js";
import type { ReadingArtifactAcl } from "../acl/reading-artifact.acl.js";
export declare class ReadingArtifactRepositoryImplementation implements ReadingArtifactRepositoryInterface {
    private readonly resource;
    constructor(resource: ReadingArtifactAcl);
    getLanguage(): Promise<{
        person?: string;
        project?: string;
    }>;
    readArtifact(path: string): Promise<{
        fingerprint: string;
    } | null>;
    readingPath(language: string, source: string): string;
    readCopy(path: string): Promise<{
        fingerprint?: string;
    } | null>;
    recordFingerprint(path: string, fingerprint: string): Promise<void>;
}

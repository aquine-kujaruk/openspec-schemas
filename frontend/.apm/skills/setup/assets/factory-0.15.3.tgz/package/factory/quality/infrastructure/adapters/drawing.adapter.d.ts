import type { DrawingAcl } from "../acl/drawing.acl.js";
export declare class DrawingAdapter implements DrawingAcl {
    private readonly run;
    constructor(run: DrawingAcl["makeGauges"]);
    makeGauges(args: readonly string[]): any;
}
import type { DrawingTools, DrawingRecord } from "../acl/drawing.acl.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createGenerate: <Loaded>({ existsSync, globSync, mkdirSync, readFileSync, rmSync, basename, dirname, join, relative, layoutOf, testOf, productTestOf, mergedSpecs, DEVELOPING, PROJECT_ROOT, runTool, rubricExamples, config, loadSchema, schemaNames, emitSchema, schemaFiles, }: DrawingTools<Loaded>) => {
    generate(args: string[], record?: (drawing: DrawingRecord) => void): Promise<number>;
};

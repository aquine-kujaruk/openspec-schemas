import { type LineNameProps } from "../schemas/line-name.schema.js";
export declare class LineName {
    readonly value: string;
    constructor(props: LineNameProps);
    equals(other: LineName): boolean;
}

import type { GaugeRunAcl } from "../acl/gauge-run.acl.js";
import type { GaugeRunRepositoryInterface } from "../../application/repository-interfaces/gauge-run.repository-interface.js";
export declare class GaugeRunRepositoryImplementation implements GaugeRunRepositoryInterface {
    private readonly tool;
    constructor(tool: GaugeRunAcl);
    runGauges(args: readonly string[]): any;
}

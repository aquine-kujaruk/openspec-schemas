import type { DrawingRepositoryInterface, GaugeBatch } from "../repository-interfaces/drawing.repository-interface.js";
export declare class MakeGaugesUseCase {
    private readonly repository;
    constructor(repository: DrawingRepositoryInterface);
    execute(args: readonly string[]): Promise<GaugeBatch>;
}

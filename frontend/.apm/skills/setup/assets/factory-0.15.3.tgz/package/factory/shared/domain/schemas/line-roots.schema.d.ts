import { z } from "zod";
export declare const LineRootsSchema: any;
export type LineRootsProps = z.infer<typeof LineRootsSchema>;

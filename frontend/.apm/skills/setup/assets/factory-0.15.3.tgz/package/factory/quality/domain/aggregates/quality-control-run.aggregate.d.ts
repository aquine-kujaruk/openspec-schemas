import { type QualityControlRunProps } from "../schemas/quality-control-run.schema.js";
import type { Defect } from "../value-objects/defect.value-object.js";
export declare class QualityControlRun {
    readonly defects: Defect[];
    readonly exitStatus: number;
    constructor(props: QualityControlRunProps);
    passed(): boolean;
}

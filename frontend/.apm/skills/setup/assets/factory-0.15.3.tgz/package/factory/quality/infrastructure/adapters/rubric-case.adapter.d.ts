import type { Case, RubricVerdict } from "./sample-file-contract.adapter.js";
export type Judgement = {
    verdict: RubricVerdict | "ambiguous";
    score: number;
    model: string;
    fingerprint: string;
};
declare const ConfidenceState: {
    readonly Target: "target";
    readonly Warning: "warning";
    readonly Failed: "failed";
};
export type ScoreResult = Judgement & {
    expected: RubricVerdict;
    confidence: number;
    state: (typeof ConfidenceState)[keyof typeof ConfidenceState];
    history: number[];
    delta?: number;
    drift: boolean;
    changed: string[];
    replayed: boolean;
};
export declare function rubricWarnings(result: ScoreResult): string[];
export declare function createRubricCases(options: {
    layer: string;
    dir: string;
    model: string;
    cases: Map<string, Map<string, Case>>;
    questions: Map<string, string>;
    ask?: (state: string, question: string) => Promise<number>;
}): {
    judge: (row: string, name: string, mode?: "test" | "record" | "record-changed") => Promise<ScoreResult>;
};
export declare function assertRubricCase(layer: string, row: string, name: string, result: ScoreResult, expected: RubricVerdict): void;
export {};

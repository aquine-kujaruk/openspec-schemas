import { z } from "zod";
export declare const PlantSchema: any;
export type PlantProps = z.infer<typeof PlantSchema>;

import { z } from "zod";
export const StageHoldSchema = z.object({
    held: z.boolean(),
    reasons: z.array(z.string()),
});
export const StageRecordSchema = z.object({
    phase: z.string().optional(),
    failures: z.number(),
    waitingFor: z.enum(["the agent", "the person"]),
    findings: z.array(z.string()),
});

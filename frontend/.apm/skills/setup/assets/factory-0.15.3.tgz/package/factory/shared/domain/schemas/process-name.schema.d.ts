import { z } from "zod";
export declare const ProcessNameSchema: any;
export type ProcessNameProps = z.infer<typeof ProcessNameSchema>;

import { type ProcessProps } from "../schemas/process.schema.js";
import type { ProcessName } from "../../../shared/domain/value-objects/process-name.value-object.js";
import type { WorkCenter } from "../entities/work-center.entity.js";
import type { WorkCenterId } from "../value-objects/work-center-id.value-object.js";
export declare class Process {
    readonly name: ProcessName;
    readonly base?: ProcessName;
    readonly description?: string;
    readonly pilot?: WorkCenterId;
    readonly workCenters: WorkCenter[];
    constructor(props: ProcessProps);
    executionOrder(): WorkCenter[];
    prerequisites(id: WorkCenterId): WorkCenter[];
    mayRunTogether(left: WorkCenterId, right: WorkCenterId): boolean;
    private workCenter;
}

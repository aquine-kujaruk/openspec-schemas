import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { AuditStateSchema, QualityCertificateSchema } from "../schemas/quality-certificate.schema.js";
export class QualityCertificate {
    workOrder;
    digest;
    scenarios;
    failing;
    review;
    procedures;
    e2e;
    constructor(props) {
        validateSchema(this, QualityCertificateSchema, props);
    }
    get change() {
        return this.workOrder;
    }
    get unproved() {
        return this.scenarios.filter((scenario) => scenario.result !== "passed");
    }
    get unexercised() {
        return this.procedures.filter((entry) => entry.treatment === "not executed" || entry.outcome === "failed");
    }
    get verdict() {
        return this.unproved.length || this.failing.length || this.unexercised.length || this.review.state === AuditStateSchema.enum.incomplete ? "not verified" : "verified";
    }
}

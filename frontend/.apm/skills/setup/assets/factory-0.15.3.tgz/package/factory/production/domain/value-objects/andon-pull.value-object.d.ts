import { type AndonPullProps } from "../schemas/andon-pull.schema.js";
export declare class AndonPull {
    readonly from: string;
    readonly names: string;
    readonly says: string;
    constructor(props: AndonPullProps);
}

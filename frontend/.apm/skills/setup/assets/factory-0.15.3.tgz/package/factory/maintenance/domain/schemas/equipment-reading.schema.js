export const RepairKind = {
    Pin: "pin",
    Link: "link",
    Default: "default",
    Roots: "roots",
    Instruction: "instruction",
};

var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
export const runtime = {
    environment: () => process.env,
    workingDirectory: () => process.cwd(),
    changeDirectory: (directory) => process.chdir(directory),
    nodeExecutable: process.execPath,
    nodeVersion: process.version,
    interactive: () => Boolean(process.stdin.isTTY),
    fetch: globalThis.fetch,
    setTimeout,
    loadModule: (specifier) => import(__rewriteRelativeImportExtension(specifier, true)),
};

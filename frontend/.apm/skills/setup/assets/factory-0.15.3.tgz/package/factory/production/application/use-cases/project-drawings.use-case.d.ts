import type { DrawingProjection, DrawingProjectionRepositoryInterface } from "../repository-interfaces/drawing-projection.repository-interface.js";
import type { AssessWorkOrderUseCase } from "./assess-work-order.use-case.js";
export declare class ProjectDrawingsUseCase {
    private readonly drawings;
    private readonly assess;
    constructor(drawings: DrawingProjectionRepositoryInterface, assess: AssessWorkOrderUseCase);
    execute(root: string): Promise<DrawingProjection | undefined>;
}

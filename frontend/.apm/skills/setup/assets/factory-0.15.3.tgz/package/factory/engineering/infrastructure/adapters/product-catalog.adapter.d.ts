import type { FactoryConfig, Product, ProductConfiguration, ProductDefinitions, ProductEntry, ProjectConfig } from "../acl/plant.acl.js";
export declare function createProductCatalog(PACKAGE_ROOT: string, { loadDefinition, loadHolder, projectSchemaName }: ProductDefinitions, environment: () => Record<string, string | undefined>, resolveConfig: ProductConfiguration, loadModule: (specifier: string) => Promise<unknown>): {
    PRODUCT_VARIABLE: string;
    HOLDER_VARIABLE: string;
    readProjectConfig: (project: string) => Promise<ProjectConfig | undefined>;
    resolveProduct: (defaults: FactoryConfig, top: ProjectConfig | undefined, name: string, entry: ProductEntry, others?: string[]) => FactoryConfig;
    projectProducts: (project: string, root?: string) => Promise<Product[]>;
    declaresProducts: (project: string) => Promise<boolean>;
    productNamed: (project: string, name: string, root?: string) => Promise<Product>;
    currentProduct: (project: string, root?: string) => Promise<Product>;
    productHolding: (products: Product[], path: string) => Product | undefined;
    projectConfig: (project: string) => Promise<FactoryConfig>;
    productOf: (project: string, named?: string) => Promise<Product>;
    productRoots: (config: FactoryConfig) => string[];
};

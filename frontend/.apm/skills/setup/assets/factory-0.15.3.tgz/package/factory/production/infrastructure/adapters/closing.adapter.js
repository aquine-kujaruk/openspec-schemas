import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { WorkOrderException } from "../../domain/exceptions/work-order.exceptions.js";
const day = () => new Date().toISOString().slice(0, 10);
const read = (file) => existsSync(file) ? readFileSync(file, "utf8") : null;
const write = (file, text) => {
    if (text === null)
        rmSync(file, { force: true });
    else {
        mkdirSync(dirname(file), { recursive: true });
        writeFileSync(file, text, "utf8");
    }
};
export class ClosingAdapter {
    root;
    directory;
    openSpec;
    projections;
    constructor(root, directory, openSpec, projections) {
        this.root = root;
        this.directory = directory;
        this.openSpec = openSpec;
        this.projections = projections;
    }
    today() { return day(); }
    listOrders() { return this.projections.listOrders(); }
    findCertificate(name) { return this.projections.findCertificate(name); }
    currentDigest(name) { return this.projections.currentDigest(name); }
    validateWorkOrder(name) { return this.projections.validateWorkOrder(name); }
    listStanding() { return this.projections.listStanding(); }
    recordFinding(name, block, message) { return this.projections.recordFinding(name, block, message); }
    makeGauges() { return this.projections.makeGauges(); }
    async readPlan(name) { return readFileSync(join(this.directory, name, "plan.md"), "utf8"); }
    async readStandingFile(path) { return read(join(this.root, path)); }
    async closeArchive(name, origin, documents) {
        let merged = false;
        try {
            for (const { path, after } of documents)
                write(join(this.root, path), after);
            const result = this.openSpec(name);
            const moved = join(this.directory, "archive", `${day()}-${name}`);
            merged = result.status === 0 && existsSync(moved);
            if (merged) {
                const target = join(this.directory, "archive", origin);
                if (target !== moved)
                    renameSync(moved, target);
                return { success: true, output: result.output };
            }
            for (const { path, before } of documents)
                write(join(this.root, path), before);
            return { success: false, output: result.output };
        }
        catch (cause) {
            if (!merged)
                for (const { path, before } of documents)
                    write(join(this.root, path), before);
            throw new WorkOrderException(`Could not archive ${name}`, { cause });
        }
    }
}

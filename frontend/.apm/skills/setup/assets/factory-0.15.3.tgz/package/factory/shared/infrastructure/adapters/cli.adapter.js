var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
export const cleanTestEnvironment = () => {
    delete process.env.VITEST;
};
export const argumentsOf = () => process.argv.slice(2);
export const exit = (status) => process.exit(status);
export const createHost = (root, project, extension, products, capture) => ({
    version: () => JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version,
    extraCommands: async () => {
        const file = join(root, `tools/commands${extension}`);
        return existsSync(file)
            ? (await import(__rewriteRelativeImportExtension(pathToFileURL(file).href, true)))
                .commands
            : {};
    },
    selectedProduct: () => process.env.FACTORY_PRODUCT,
    selectProduct: (name) => {
        process.env.FACTORY_PRODUCT = name;
    },
    products,
    runForProduct: (name, command, args) => capture(process.execPath, [join(root, `factory/main${extension}`), command, ...args], {
        cwd: project,
        env: { ...process.env, FACTORY_PRODUCT: name },
        show: true,
    }).status,
    say: console.log,
    warn: console.error,
});

import type { AndonAcl } from "../acl/andon.acl.js";
export declare class AndonAdapter implements AndonAcl {
    private readonly directory;
    private readonly gate;
    private readonly signals;
    constructor(directory: string, gate: string, signals: (name: string) => {
        source: string;
    }[]);
    readPlan(name: string): unknown;
    savePlan(name: string, text: string): any;
    closeSignal(name: string, source: string): any;
}

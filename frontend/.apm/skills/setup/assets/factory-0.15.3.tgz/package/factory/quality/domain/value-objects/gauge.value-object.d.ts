import { type GaugeProps } from "../schemas/gauge.schema.js";
export declare class Gauge {
    readonly drawing: string;
    readonly file: string;
    constructor(props: GaugeProps);
}

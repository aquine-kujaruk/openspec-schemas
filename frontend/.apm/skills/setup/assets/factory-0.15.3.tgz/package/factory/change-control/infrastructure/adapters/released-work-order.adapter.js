export class ReleasedWorkOrderAdapter {
    active;
    constructor(active) {
        this.active = active;
    }
    readStarted() {
        return this.active();
    }
}

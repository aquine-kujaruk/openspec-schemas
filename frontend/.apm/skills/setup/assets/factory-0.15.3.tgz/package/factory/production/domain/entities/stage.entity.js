import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { StageSchema } from "../schemas/stage.schema.js";
export class Stage {
    title;
    operations;
    constructor(props) {
        validateSchema(this, StageSchema, props);
    }
    get complete() {
        return this.operations.every((operation) => operation.done);
    }
}

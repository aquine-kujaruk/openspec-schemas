export class DrawingProjectionRepositoryImplementation {
    orders;
    drawings;
    constructor(orders, drawings) {
        this.orders = orders;
        this.drawings = drawings;
    }
    listWorkOrders(root) {
        return this.orders.activeChanges(root).flatMap((name) => this.orders.readChange(root, name) ?? []);
    }
    mergeDrawings(root, changes) { return this.drawings.mergeDrawings(root, changes); }
}

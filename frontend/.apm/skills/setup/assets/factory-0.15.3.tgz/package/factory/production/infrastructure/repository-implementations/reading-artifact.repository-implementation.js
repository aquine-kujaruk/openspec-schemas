export class ReadingArtifactRepositoryImplementation {
    resource;
    constructor(resource) {
        this.resource = resource;
    }
    getLanguage() {
        return this.resource.getLanguage();
    }
    readArtifact(path) {
        return this.resource.readArtifact(path);
    }
    readingPath(language, source) {
        return this.resource.readingPath(language, source);
    }
    readCopy(path) {
        return this.resource.readCopy(path);
    }
    recordFingerprint(path, fingerprint) {
        return this.resource.recordFingerprint(path, fingerprint);
    }
}

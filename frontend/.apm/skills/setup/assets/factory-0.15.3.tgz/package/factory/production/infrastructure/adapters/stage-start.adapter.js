import { writeFileSync } from "node:fs";
import { join } from "node:path";
export class StageStartAdapter {
    directory;
    gate;
    assess;
    builds;
    run;
    constructor(directory, gate, assess, builds, run) {
        this.directory = directory;
        this.gate = gate;
        this.assess = assess;
        this.builds = builds;
        this.run = run;
    }
    validateWorkOrder(name) { return this.assess(name); }
    async prepareStage(name, phase) {
        const { code, line } = await this.builds(name);
        const prep = line ? ["prepare", "--product", line] : ["prepare"];
        for (const step of code ? [prep, ["generate"]] : [["generate"]]) {
            const { status, output } = this.run(step);
            if (status !== 0)
                return { success: false, output };
        }
        writeFileSync(join(this.directory, name, this.gate), `${JSON.stringify({ phase, failures: 0, waitingFor: "the agent", findings: [] }, null, 2)}\n`);
        return { success: true, output: "" };
    }
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { AuthorizationSchema } from "../schemas/authorization.schema.js";
export class Authorization {
    blockedBy;
    refusals;
    constructor(props) {
        validateSchema(this, AuthorizationSchema, props);
    }
    get allowed() {
        return this.refusals.length === 0;
    }
}

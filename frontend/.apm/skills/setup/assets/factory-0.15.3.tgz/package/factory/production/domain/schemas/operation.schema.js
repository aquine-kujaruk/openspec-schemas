import { z } from "zod";
export const OperationSchema = z.object({
    workCenter: z.string().min(1).optional(),
    text: z.string().min(1),
    done: z.boolean(),
});

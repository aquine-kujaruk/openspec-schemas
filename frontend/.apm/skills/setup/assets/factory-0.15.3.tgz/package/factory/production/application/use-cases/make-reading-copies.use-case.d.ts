import type { ReadingArtifactRepositoryInterface } from "../repository-interfaces/reading-artifact.repository-interface.js";
type Reading = {
    source: string;
    copy: string;
    fresh: boolean;
};
export declare class MakeReadingCopiesUseCase {
    private readonly artifacts;
    constructor(artifacts: ReadingArtifactRepositoryInterface);
    readingsOf(paths: string[]): Promise<Reading[]>;
    markWritten(paths: string[]): Promise<Reading[]>;
    private readings;
    execute(args: string[]): Promise<{
        status: number;
        lines: string[];
    }>;
}
export {};

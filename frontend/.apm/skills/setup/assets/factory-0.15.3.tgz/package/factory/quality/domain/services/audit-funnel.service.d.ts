import type { AuditAnswers, AuditFile, AuditQuestion, AuditRow, AuditSpan } from "../schemas/audit-material.schema.js";
import { AuditFinding } from "../value-objects/audit-finding.value-object.js";
export type AuditFunnelOptions = {
    ask: (state: string, questions: AuditQuestion[], locations: string[]) => Promise<AuditAnswers>;
    outline: (file: AuditFile) => AuditSpan[];
    rows: AuditRow[];
    files: AuditFile[];
    threshold: number;
    spanLines: number;
    batch: {
        files: number;
        chars: number;
    };
};
/**
 * The narrowing funnel. Stage 1: the touched files of one layer folder, in batches, with one
 * question per row and file ("consider only this file"). Stage 2: each file answered yes is split
 * into its top-level units with the AST and asked again, one question per row and unit. Stage 3:
 * a unit answered yes and longer than `spanLines` is split into its parts (class header and
 * members, statements of a body) and asked again until the span fits; every span answered yes is
 * a finding with its line range. A span answered no at a deeper stage is dropped: the funnel only
 * narrows, it never widens. A file may yield several ranges for one row.
 */
export declare class AuditFunnelService {
    inspect(o: AuditFunnelOptions): Promise<AuditFinding[]>;
}

export class DispatchRepositoryImplementation {
    resource;
    constructor(resource) {
        this.resource = resource;
    }
    validateWorkOrder(name) {
        return this.resource.validateWorkOrder(name);
    }
    checkout(path) { return this.resource.checkout(path); }
    getRunner() {
        return this.resource.getRunner();
    }
    runCommand(command) {
        return this.resource.runCommand(command);
    }
}

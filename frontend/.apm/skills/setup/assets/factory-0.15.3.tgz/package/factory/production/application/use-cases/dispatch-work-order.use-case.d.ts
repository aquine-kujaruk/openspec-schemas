import type { DispatchRepositoryInterface } from "../repository-interfaces/dispatch.repository-interface.js";
export declare class DispatchWorkOrderUseCase {
    private readonly dispatch;
    constructor(dispatch: DispatchRepositoryInterface);
    execute(name: string, sessionRoot?: string): Promise<{
        status: number;
        said: string[];
    }>;
}

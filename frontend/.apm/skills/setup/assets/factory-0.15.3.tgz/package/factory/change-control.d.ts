export declare const filesOf: (input: unknown) => string[];
export declare const projectOf: any;
export declare const hookInput: any;
export declare function guard(root: string, paths: string[], cwd?: string): unknown;
export declare function authorizeWrite(args: string[]): Promise<number>;

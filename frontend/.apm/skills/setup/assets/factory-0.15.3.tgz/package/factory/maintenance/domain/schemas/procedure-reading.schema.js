export const NeedKind = { Script: "script", Binary: "binary", File: "file" };

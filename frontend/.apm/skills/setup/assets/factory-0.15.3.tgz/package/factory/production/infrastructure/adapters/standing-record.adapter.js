import { globSync, readFileSync } from "node:fs";
import { join } from "node:path";
export class StandingRecordAdapter {
    readDocuments(root, directory) {
        return globSync(`${directory}/**/*.md`, { cwd: root }).sort().map((file) => ({
            file,
            document: readFileSync(join(root, file), "utf8"),
        }));
    }
}

import { realpathSync } from "node:fs";
import { spawnSync } from "node:child_process";
export class DispatchAdapter {
    root;
    assess;
    runner;
    constructor(root, assess, runner) {
        this.root = root;
        this.assess = assess;
        this.runner = runner;
    }
    validateWorkOrder(name) { return this.assess(name); }
    checkout(path = this.root) { return realpathSync(path); }
    getRunner() { return this.runner(); }
    async runCommand(command) {
        return spawnSync("sh", ["-c", command], { cwd: this.root, stdio: "inherit" }).status;
    }
}

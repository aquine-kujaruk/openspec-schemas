import { z } from "zod";
import { Standard } from "../value-objects/standard.value-object.js";
export const PartSchema = z.object({
    name: z.string().min(1),
    standards: z.array(z.instanceof(Standard)),
});

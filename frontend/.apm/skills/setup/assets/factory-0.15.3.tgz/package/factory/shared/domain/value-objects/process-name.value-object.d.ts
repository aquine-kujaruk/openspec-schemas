import { type ProcessNameProps } from "../schemas/process-name.schema.js";
export declare class ProcessName {
    readonly value: string;
    constructor(props: ProcessNameProps);
    equals(other: ProcessName): boolean;
}

import { type DecisionClient, type DecisionModelOptions } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
export { DECISIONS_ENDPOINT, inspect, type DecisionClient, type Inspection } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
export type OpenAiClientOptions = DecisionModelOptions;
/** The decision model of the audit: a failure to ask it is a quality failure. */
export declare const openAiClient: (o: OpenAiClientOptions) => DecisionClient & {
    requests: number;
};

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { StandardSchema } from "../schemas/standard.schema.js";
export class Standard {
    id;
    title;
    constructor(props) {
        validateSchema(this, StandardSchema, props);
    }
}

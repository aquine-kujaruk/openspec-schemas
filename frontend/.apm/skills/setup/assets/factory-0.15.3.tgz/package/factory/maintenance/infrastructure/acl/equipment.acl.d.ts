import type { Installed } from "../../../shared/domain/schemas/line-types.schema.js";
import type { MaintenanceOptions } from "../../application/repository-interfaces/equipment.repository-interface.js";
import type { Equipment } from "../../domain/aggregates/equipment.aggregate.js";
import type { EquipmentNotes, EquipmentPlace, EquipmentReading, EquipmentRepair } from "../../domain/schemas/equipment-reading.schema.js";
import type { EquipmentHoldings, EquipmentProcedure } from "../../domain/schemas/procedure-reading.schema.js";
export { RepairKind } from "../../domain/schemas/equipment-reading.schema.js";
export { SECTION } from "../../domain/services/equipment-installation.service.js";
export type EquipmentInstallation = {
    installed: Installed;
    assets: string;
};
export type EquipmentAuthority = {
    readProcedures(root: string): Map<string, EquipmentProcedure>;
    listProductRoots(root: string): Promise<string[]>;
    hasWebProduct(root: string): Promise<boolean>;
    environment(): Record<string, string | undefined>;
    nodeVersion: string;
    loadEnv(root: string, env: Record<string, string | undefined>): Record<string, string | undefined>;
    run(command: string, args: string[], cwd: string): {
        status: number;
        stdout: string;
        stderr: string;
    };
    withSection(own: string | undefined, instructions: string[]): string;
    pinnedVersion(command: string, manifest: {
        devDependencies?: Record<string, string>;
    }, lock: object): string | undefined;
};
export declare const PLACES: Record<string, EquipmentPlace>;
export interface EquipmentAcl {
    readInstalled(root: string): EquipmentInstallation | undefined;
    inspectEquipment(root: string, equipment: Equipment, node?: string): Promise<EquipmentReading>;
    repairEquipment(root: string, equipment: Equipment, repair: EquipmentRepair): void;
    readNotes(root: string, equipment: Equipment, env?: MaintenanceOptions["env"]): EquipmentNotes;
    listProcedures(root: string): Map<string, EquipmentProcedure>;
    readHoldings(root: string): Promise<EquipmentHoldings>;
}

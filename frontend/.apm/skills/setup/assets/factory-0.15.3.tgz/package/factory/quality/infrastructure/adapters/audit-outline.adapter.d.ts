import type { AuditAcl } from "../acl/audit.acl.js";
export declare const outlineSource: AuditAcl["outlineSource"];

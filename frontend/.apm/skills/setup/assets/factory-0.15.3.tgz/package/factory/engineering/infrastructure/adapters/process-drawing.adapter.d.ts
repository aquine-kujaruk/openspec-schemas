import type { CatalogSchema } from "../acl/process.acl.js";
/**
 * The files of a schema as the specification tool reads it: `schema.yaml` and the templates its
 * artifacts name. The instruction of the artifact that decides ends with what only the schema
 * knows: the workstreams a task may name and its question policy.
 */
export declare const schemaFiles: (schema: CatalogSchema) => Record<string, string>;
/** Writes the schema's files under `dir`. */
export declare const emitSchema: (schema: CatalogSchema, dir: string) => string[];

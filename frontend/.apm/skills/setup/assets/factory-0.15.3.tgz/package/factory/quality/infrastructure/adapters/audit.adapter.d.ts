import type { AuditAcl } from "../acl/audit.acl.js";
export declare class AuditAdapter implements AuditAcl {
    private readonly ask;
    private readonly head;
    constructor(ask: AuditAcl["askQuestions"], head: AuditAcl["findCommit"]);
    listRubrics(_root: string, paths: string[]): any;
    listPackageNames(root: string): string[];
    listCoreFiles(root: string, modules: string, folders: string[]): any;
    readPass(root: string): {
        files: any;
        rubric?: any;
    };
    savePass(root: string, pass: ReturnType<AuditAcl["readPass"]>): void;
    findCommit(root: string): string | null;
    hashContent(content: string): string;
    askQuestions(...args: Parameters<AuditAcl["askQuestions"]>): any;
    outlineSource(source: Parameters<AuditAcl["outlineSource"]>[0]): any;
}

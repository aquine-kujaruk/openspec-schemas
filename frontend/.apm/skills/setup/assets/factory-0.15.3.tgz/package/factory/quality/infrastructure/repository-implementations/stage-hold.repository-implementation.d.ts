import type { StageHoldRepositoryInterface } from "../../application/repository-interfaces/stage-hold.repository-interface.js";
import type { BuildingStage, StageRecord } from "../../domain/schemas/stage-hold.schema.js";
import { type StageHoldAcl } from "../acl/stage-hold.acl.js";
export declare class StageHoldRepositoryImplementation implements StageHoldRepositoryInterface {
    private readonly records;
    constructor(records: StageHoldAcl);
    listBuilding(): any;
    hasCurrentVerification(name: string): Promise<boolean>;
    listHarnessFindings(): any;
    listWorkstreams(stage: BuildingStage): any;
    readRecord(name: string): unknown;
    saveRecord(name: string, record: StageRecord): any;
    resetRecord(name: string): any;
    runCheck(stage: BuildingStage, workstream: string): any;
    runTests(stage: BuildingStage, kind: "unit" | "integration" | "acceptance"): any;
}

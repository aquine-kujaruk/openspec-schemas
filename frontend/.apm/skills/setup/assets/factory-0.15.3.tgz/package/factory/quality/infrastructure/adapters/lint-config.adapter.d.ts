import type { LintRules, Platform, Vetoed } from "../acl/inspection.acl.js";
/** Packages a zone may not import, under one rule id: exact names and patterns (`express/*`). */
export type ImportVeto = {
    id: string;
    names: string[];
    patterns: string[];
    message: string;
};
/**
 * Several vetoes in one `no-restricted-imports` entry: oxlint keeps one configuration of a rule per
 * file, so two overrides on the same files would replace each other. Every message starts with
 * `[<id>]`: that prefix is how the spec counts the rule's violations.
 */
export declare const restrictedImportsOf: (vetoes: ImportVeto[]) => LintRules;
export declare const restrictedImports: (id: string, names: string[], patterns: string[], message: string) => LintRules;
export declare const restrictedGlobals: (id: string, names: string[], where?: string) => LintRules;
/** What holds for the whole core: no framework (no-framework-import), nothing from the environment (no-environment), plus any further import veto of the zone. */
export declare const coreRules: (vetoed: Vetoed, platform: Platform, message: string, more?: ImportVeto[]) => LintRules;
/**
 * schema-package-only-at-boundaries: the package the configuration names is imported only in
 * domain/schemas, infrastructure/acl and infrastructure/adapters. Each layer merges this veto into
 * its own `no-restricted-imports` entry for the folders it covers.
 */
export declare const schemaPackageVeto: (o: {
    schemaPackage: string;
}) => ImportVeto;

import { type DecisionProps } from "../schemas/decision.schema.js";
import type { DecidedBy } from "../schemas/decision.schema.js";
export declare class Decision {
    readonly text: string;
    readonly by: DecidedBy;
    constructor(props: DecisionProps);
}

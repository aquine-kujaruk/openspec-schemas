import { type InspectionAcl } from "../acl/inspection.acl.js";
import type { LineName } from "../../../shared/domain/value-objects/line-name.value-object.js";
import type { InspectionRepositoryInterface } from "../../application/repository-interfaces/inspection.repository-interface.js";
export declare class InspectionRepositoryImplementation implements InspectionRepositoryInterface {
    private readonly tool;
    constructor(tool: InspectionAcl);
    inspectLine(line: LineName, scope: readonly string[]): unknown;
}

import { createHash } from "node:crypto";
import { existsSync, globSync, readFileSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";
import { outlineSource } from "./audit-outline.adapter.js";
const RECORD_FILE = ".factory-review.json";
export class AuditAdapter {
    ask;
    head;
    constructor(ask, head) {
        this.ask = ask;
        this.head = head;
    }
    listRubrics(_root, paths) {
        return paths.map((path) => ({ path, markdown: readFileSync(path, "utf8") }));
    }
    listPackageNames(root) {
        const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
        return Object.keys({ ...pkg.dependencies, ...pkg.devDependencies });
    }
    listCoreFiles(root, modules, folders) {
        return folders.flatMap((folder) => globSync(`${modules}/${folder}/**/*.{ts,tsx}`, { cwd: root })
            .sort()
            .map((path) => ({
            path: relative(root, join(root, path)).replaceAll("\\", "/"),
            content: readFileSync(join(root, path), "utf8"),
            folder,
        }))).filter((file) => !/\.(test|spec)\.tsx?$/.test(file.path));
    }
    readPass(root) {
        const file = join(root, RECORD_FILE);
        if (!existsSync(file))
            return { files: {} };
        const pass = JSON.parse(readFileSync(file, "utf8"));
        return {
            ...(pass.rubric ? { rubric: pass.rubric } : {}),
            files: pass.files ?? {},
        };
    }
    savePass(root, pass) {
        writeFileSync(join(root, RECORD_FILE), `${JSON.stringify(pass, null, 2)}\n`);
    }
    findCommit(root) {
        return this.head(root);
    }
    hashContent(content) {
        return createHash("sha256").update(content).digest("hex").slice(0, 16);
    }
    askQuestions(...args) {
        return this.ask(...args);
    }
    outlineSource(source) {
        return outlineSource(source);
    }
}

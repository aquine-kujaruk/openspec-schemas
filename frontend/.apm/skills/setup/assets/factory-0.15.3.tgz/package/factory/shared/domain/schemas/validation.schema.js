import { ValidationException } from "../exceptions/validation.exceptions.js";
export const validateSchema = (target, schema, props) => {
    const result = schema.safeParse(props);
    if (!result.success)
        throw new ValidationException(target.constructor.name, result.error);
    Object.assign(target, result.data);
    return result.data;
};

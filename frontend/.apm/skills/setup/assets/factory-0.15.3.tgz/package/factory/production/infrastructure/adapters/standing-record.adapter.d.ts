import type { StandingRecordAcl } from "../acl/standing-record.acl.js";
export declare class StandingRecordAdapter implements StandingRecordAcl {
    readDocuments(root: string, directory: string): any;
}

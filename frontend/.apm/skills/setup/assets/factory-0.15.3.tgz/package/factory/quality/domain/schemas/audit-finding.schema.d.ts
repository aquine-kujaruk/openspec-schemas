import { z } from "zod";
export declare const AuditFindingSchema: any;
export type AuditFindingProps = z.input<typeof AuditFindingSchema>;

import { ChangeControlException } from "../../domain/exceptions/change-control.exceptions.js";
import { ReleasedWorkOrderRecordSchema } from "../acl/released-work-order.acl.js";
export class ReleasedWorkOrderRepositoryImplementation {
    orders;
    constructor(orders) {
        this.orders = orders;
    }
    async listReleasedWorkOrders() {
        try {
            return ReleasedWorkOrderRecordSchema.array().parse(await this.orders.readStarted());
        }
        catch (cause) {
            throw new ChangeControlException("Unable to read the active work orders", { cause });
        }
    }
}

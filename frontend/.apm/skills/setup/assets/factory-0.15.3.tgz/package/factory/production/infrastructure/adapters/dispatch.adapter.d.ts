import type { DispatchAcl } from "../acl/dispatch.acl.js";
export declare class DispatchAdapter implements DispatchAcl {
    private readonly root;
    private readonly assess;
    private readonly runner;
    constructor(root: string, assess: DispatchAcl["validateWorkOrder"], runner: DispatchAcl["getRunner"]);
    validateWorkOrder(name: string): any;
    checkout(path?: string): any;
    getRunner(): any;
    runCommand(command: string): unknown;
}

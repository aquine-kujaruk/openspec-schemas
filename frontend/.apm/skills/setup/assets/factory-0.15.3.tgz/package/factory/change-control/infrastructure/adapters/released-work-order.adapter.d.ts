import type { ReleasedWorkOrderAcl, ReleasedWorkOrderRecord } from "../acl/released-work-order.acl.js";
export declare class ReleasedWorkOrderAdapter implements ReleasedWorkOrderAcl {
    private readonly active;
    constructor(active: () => Promise<ReleasedWorkOrderRecord[]>);
    readStarted(): Promise<ReleasedWorkOrderRecord[]>;
}

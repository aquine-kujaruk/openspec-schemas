import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { WorkCenterIdSchema } from "../schemas/work-center-id.schema.js";
export class WorkCenterId {
    value;
    constructor(props) {
        validateSchema(this, WorkCenterIdSchema, props);
    }
}

import { z } from "zod";
export declare const StandardIdSchema: any;
export type StandardIdProps = z.infer<typeof StandardIdSchema>;

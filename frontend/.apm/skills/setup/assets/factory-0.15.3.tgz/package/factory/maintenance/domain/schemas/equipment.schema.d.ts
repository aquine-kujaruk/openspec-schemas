import { z } from "zod";
export declare const EquipmentSchema: any;
export type EquipmentProps = z.input<typeof EquipmentSchema>;

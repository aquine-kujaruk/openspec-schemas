import * as plan from "./production/domain/schemas/plan-document.schema.js";
export declare const change: {
    CHANGES: any;
    GATE: any;
    activeChanges: any;
    readChange: any;
    readArchivedChange: any;
    isStarted: any;
};
export declare const consolidated: {
    DECISIONS: any;
    PROCEDURES: any;
    readConsolidated: any;
};
export declare const feedback: {
    raised: any;
    raise: any;
};
export declare const validate: {
    NotValidatable: any;
    validateChange: any;
    changesInImplementation: any;
};
export declare const merged: {
    openspec: any;
    mergedSpecs: any;
    specsAsReadyChangesLeaveThem(project: string): unknown;
};
export { plan };
export declare const sdkValidateChange: any;
export declare function dispatchWorkOrder(args: string[]): Promise<number>;
export declare function makeReadingCopies(args: string[]): Promise<number>;
export declare function pullAndon(args: string[]): Promise<number>;
export declare function closeWorkOrders(args: string[]): Promise<number>;
export declare const listReleasedWorkOrders: () => any;
export declare function startStage(args: string[]): Promise<number>;
export declare function validateWorkOrder(args: string[]): Promise<number>;

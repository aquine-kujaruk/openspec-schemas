import { DomainException } from "../../../shared/domain/exceptions/domain.exceptions.js";
export declare class ChangeControlException extends DomainException {
}

import ts from "typescript";
const parse = (path, source) => ({
    sf: ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, path.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS),
    lines: source.split("\n").length,
});
const line = (sf, pos) => sf.getLineAndCharacterOfPosition(pos).line + 1;
const spanOf = (sf, node, label) => ({
    from: line(sf, node.getStart(sf)),
    to: line(sf, node.getEnd()),
    label,
});
const nameOf = (node) => {
    const n = node.name;
    return n &&
        (ts.isIdentifier(n) || ts.isStringLiteral(n) || ts.isPrivateIdentifier(n))
        ? n.text
        : "";
};
const kindOf = (node) => {
    if (ts.isClassDeclaration(node))
        return "class";
    if (ts.isInterfaceDeclaration(node))
        return "interface";
    if (ts.isFunctionDeclaration(node))
        return "function";
    if (ts.isTypeAliasDeclaration(node))
        return "type";
    if (ts.isEnumDeclaration(node))
        return "enum";
    if (ts.isVariableStatement(node))
        return "const";
    if (ts.isMethodDeclaration(node))
        return "method";
    if (ts.isConstructorDeclaration(node))
        return "constructor";
    if (ts.isGetAccessor(node) || ts.isSetAccessor(node))
        return "accessor";
    if (ts.isPropertyDeclaration(node))
        return "property";
    if (ts.isPropertySignature(node) || ts.isMethodSignature(node))
        return "member";
    if (ts.isImportDeclaration(node))
        return "import";
    if (ts.isExportDeclaration(node) || ts.isExportAssignment(node))
        return "export";
    return "statement";
};
const labelOf = (node, owner) => {
    const kind = kindOf(node);
    const name = ts.isVariableStatement(node)
        ? node.declarationList.declarations.map(nameOf).filter(Boolean).join(", ")
        : nameOf(node);
    const qualified = kind === "constructor"
        ? (owner ?? "")
        : owner && name
            ? `${owner}.${name}`
            : name;
    return qualified ? `${kind} ${qualified}` : kind;
};
/** Stage 2: the top-level units of a file (classes, interfaces, functions, constants, types…). */
const unitsOf = ({ sf }) => sf.statements
    .filter((s) => !ts.isImportDeclaration(s))
    .map((s) => ({ ...spanOf(sf, s, labelOf(s)), node: s }));
const bodyOf = (node) => {
    const body = node.body;
    return body && ts.isBlock(body) ? body : undefined;
};
const functionBody = (node) => {
    if (ts.isFunctionLike(node))
        return bodyOf(node);
    if (ts.isVariableStatement(node)) {
        const inits = node.declarationList.declarations.flatMap((d) => d.initializer ? [d.initializer] : []);
        const fn = inits.find((i) => ts.isArrowFunction(i) || ts.isFunctionExpression(i));
        return fn && bodyOf(fn);
    }
    return undefined;
};
/** Every statement held by the blocks directly inside a node (then/else, loop bodies, try/catch, switch cases). */
const statementsWithin = (node) => {
    const out = [];
    const visit = (n) => {
        if (ts.isBlock(n) || ts.isModuleBlock(n))
            out.push(...n.statements);
        else if (ts.isCaseBlock(n))
            n.clauses.forEach((c) => out.push(...c.statements));
        else if (ts.isSourceFile(n) || n === node)
            n.forEachChild(visit);
        else if (ts.isIfStatement(n) ||
            ts.isIterationStatement(n, false) ||
            ts.isTryStatement(n))
            out.push(n);
        else if (ts.isCatchClause(n) || ts.isCaseClause(n) || ts.isDefaultClause(n))
            n.forEachChild(visit);
        else if (ts.isStatement(n))
            out.push(n);
    };
    node.forEachChild(visit);
    return out;
};
/**
 * Stage 3: what a span splits into. A class: its header (declaration up to the first member) and
 * each member; an interface or enum: its members; a function or method: the statements of its
 * body; a compound statement: the statements of its blocks. A leaf yields nothing and is reported
 * as it is.
 */
const partsOf = ({ sf }, unit) => {
    const { node } = unit;
    const owner = nameOf(node);
    if (ts.isClassDeclaration(node) || ts.isClassExpression(node)) {
        const members = node.members.map((m) => ({
            ...spanOf(sf, m, labelOf(m, owner)),
            node: m,
        }));
        if (!members.length)
            return [];
        const header = {
            from: line(sf, node.getStart(sf)),
            to: Math.max(line(sf, node.getStart(sf)), members[0].from - 1),
            label: `header of class ${owner}`,
            node,
        };
        return [header, ...members];
    }
    if (ts.isInterfaceDeclaration(node) ||
        ts.isEnumDeclaration(node) ||
        ts.isTypeLiteralNode(node))
        return node.members.map((m) => ({
            ...spanOf(sf, m, labelOf(m, owner)),
            node: m,
        }));
    const body = functionBody(node);
    const statements = body ? [...body.statements] : statementsWithin(node);
    return statements.map((s) => ({ ...spanOf(sf, s, labelOf(s)), node: s }));
};
export const outlineSource = ({ path, content }) => {
    const source = parse(path, content);
    const outline = (span) => ({
        from: span.from,
        to: span.to,
        label: span.label,
        parts: partsOf(source, span)
            .filter((part) => part.from >= span.from && part.to <= span.to &&
            (part.from !== span.from || part.to !== span.to))
            .map(outline),
    });
    return unitsOf(source).map(outline);
};

import { z } from "zod";
export declare const QualityControlRunSchema: any;
export type QualityControlRunProps = z.input<typeof QualityControlRunSchema>;

import type { ExamplesPorts } from "./sample-inspection-contract.adapter.js";
/** Builds these use cases from their capabilities; importing them touches no resources. */
export declare const createExamples: ({ workingDirectory, changeDirectory, globSync, mkdirSync, mkdtempSync, writeFileSync, tmpdir, basename, dirname, join, clearGraphCache, COVERAGE_RULE, fallowConfig, layersOf, oxlintConfig, oxlintOverrides, withUpstream, archunitRules, idsInMessages, parseExampleFile, jsonOf, runTool, }: ExamplesPorts) => typeof import("./sample-inspection-contract.adapter.js");

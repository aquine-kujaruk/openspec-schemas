import type { EquipmentRepositoryInterface, MaintenanceOptions } from "../../application/repository-interfaces/equipment.repository-interface.js";
import { Equipment } from "../../domain/aggregates/equipment.aggregate.js";
import type { EquipmentRepair } from "../../domain/schemas/equipment-reading.schema.js";
import type { EquipmentAcl } from "../acl/equipment.acl.js";
export declare class EquipmentRepositoryImplementation implements EquipmentRepositoryInterface {
    private readonly resources;
    constructor(resources: EquipmentAcl);
    findEquipment(root: string): Equipment | null;
    inspectEquipment(root: string, equipment: Equipment, node?: string): unknown;
    repairEquipment(root: string, equipment: Equipment, repair: EquipmentRepair): void;
    readNotes(root: string, equipment: Equipment, env?: MaintenanceOptions["env"]): any;
    listProcedures(root: string): any;
    readHoldings(root: string): any;
    private read;
}

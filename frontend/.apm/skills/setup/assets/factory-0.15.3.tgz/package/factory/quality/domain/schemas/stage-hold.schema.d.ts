import { z } from "zod";
export declare const StageHoldSchema: any;
export declare const StageRecordSchema: any;
export type StageHoldProps = z.input<typeof StageHoldSchema>;
export type StageRecord = z.infer<typeof StageRecordSchema>;
export type BuildingStage = {
    name: string;
    process: string;
    line?: string;
    pendingFeedback?: boolean;
    phases: {
        title: string;
        tasks: {
            done: boolean;
            text?: string;
            workstream?: string;
        }[];
    }[];
};
export type StageWorkstream = {
    id: string;
    upstream: string[];
    tests: ("unit" | "integration" | "acceptance")[];
};

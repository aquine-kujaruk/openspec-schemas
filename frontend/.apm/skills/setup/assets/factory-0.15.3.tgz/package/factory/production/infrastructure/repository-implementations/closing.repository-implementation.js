export class ClosingRepositoryImplementation {
    resource;
    constructor(resource) {
        this.resource = resource;
    }
    listOrders() {
        return this.resource.listOrders();
    }
    findCertificate(name) {
        return this.resource.findCertificate(name);
    }
    currentDigest(name) {
        return this.resource.currentDigest(name);
    }
    validateWorkOrder(name) {
        return this.resource.validateWorkOrder(name);
    }
    readPlan(name) {
        return this.resource.readPlan(name);
    }
    listStanding() {
        return this.resource.listStanding();
    }
    readStandingFile(path) {
        return this.resource.readStandingFile(path);
    }
    recordFinding(name, block, message) {
        return this.resource.recordFinding(name, block, message);
    }
    closeArchive(name, origin, changes) {
        return this.resource.closeArchive(name, origin, changes);
    }
    makeGauges() {
        return this.resource.makeGauges();
    }
    today() {
        return this.resource.today();
    }
}

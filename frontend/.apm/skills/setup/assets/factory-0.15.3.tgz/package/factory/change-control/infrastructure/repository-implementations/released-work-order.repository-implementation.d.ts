import type { ReleasedWorkOrderRepositoryInterface } from "../../application/repository-interfaces/released-work-order.repository-interface.js";
import { type ReleasedWorkOrderAcl } from "../acl/released-work-order.acl.js";
export declare class ReleasedWorkOrderRepositoryImplementation implements ReleasedWorkOrderRepositoryInterface {
    private readonly orders;
    constructor(orders: ReleasedWorkOrderAcl);
    listReleasedWorkOrders(): unknown;
}

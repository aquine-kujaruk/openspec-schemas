import type { AndonRepositoryInterface } from "../../application/repository-interfaces/andon.repository-interface.js";
import type { AndonAcl } from "../acl/andon.acl.js";
export declare class AndonRepositoryImplementation implements AndonRepositoryInterface {
    private readonly resource;
    constructor(resource: AndonAcl);
    readPlan(name: string): Promise<string>;
    savePlan(name: string, text: string): Promise<void>;
    closeSignal(name: string, source: string): Promise<void>;
}

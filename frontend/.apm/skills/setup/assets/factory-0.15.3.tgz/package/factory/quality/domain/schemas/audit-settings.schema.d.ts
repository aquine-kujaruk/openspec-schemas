import type { Review } from "../../../shared/domain/schemas/line-types.schema.js";
export declare const DEFAULTS: Review;

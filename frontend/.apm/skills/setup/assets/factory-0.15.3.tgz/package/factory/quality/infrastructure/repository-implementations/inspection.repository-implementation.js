import { InspectionRecordSchema } from "../acl/inspection.acl.js";
import { QualityControlRun } from "../../domain/aggregates/quality-control-run.aggregate.js";
import { Defect } from "../../domain/value-objects/defect.value-object.js";
export class InspectionRepositoryImplementation {
    tool;
    constructor(tool) {
        this.tool = tool;
    }
    async inspectLine(line, scope) {
        const result = InspectionRecordSchema.parse(await this.tool.inspectLine(line.value, scope));
        return new QualityControlRun({ exitStatus: result.exitStatus, defects: result.defects.map((defect) => new Defect(defect)) });
    }
}

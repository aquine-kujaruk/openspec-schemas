import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** Application: use case | repository interface. The entry to the core; decides *what happens*. Only imports domain. Spec: `openspec/specs/architecture/application`. */
export declare const application: (o: Options) => Layer;

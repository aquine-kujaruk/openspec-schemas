import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** Infrastructure: ACL | repository implementation, plus the emergent folders the configuration declares. Implements the application interfaces against the real world through the ACLs; the adapters behind them are a layer of their own. Spec: `openspec/specs/architecture/infrastructure`. */
export declare const infrastructure: (o: Options) => Layer;

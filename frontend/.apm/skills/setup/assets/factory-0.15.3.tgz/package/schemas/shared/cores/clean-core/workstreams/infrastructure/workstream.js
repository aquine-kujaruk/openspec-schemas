import { infrastructure } from "./infrastructure.rules.js";
import { integration } from "./integration.rules.js";
/** Repository implementations and anti-corruption layers, and their integration tests over in-memory adapters typed by the ACLs. */
export default {
    layers: (o) => [infrastructure(o), integration(o)],
    tests: ["integration"],
};

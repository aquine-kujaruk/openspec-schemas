import type { Check } from "factory/sdk";
/**
 * The checks that only make sense once every workstream's work is joined: no workstream owns them.
 * `factory check` runs them after every workstream's rules, and verify runs them; a workstream's
 * own check and the completion gate do not.
 */
export declare const wholeProduct: Check[];

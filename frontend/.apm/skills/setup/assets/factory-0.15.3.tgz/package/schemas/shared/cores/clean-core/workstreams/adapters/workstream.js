import { adapters } from "./adapters.rules.js";
/** Resource adapters, built against the anti-corruption layers they implement; they fake nothing. */
export default { layers: (o) => [adapters(o)] };

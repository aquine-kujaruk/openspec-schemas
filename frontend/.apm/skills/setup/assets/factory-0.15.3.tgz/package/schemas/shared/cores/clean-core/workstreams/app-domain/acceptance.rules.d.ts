import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/**
 * Acceptance: black box against the use cases, generated from the product specs. No layers inside:
 * only the contexts and their use cases. The implementer writes the step adapter, with the
 * repository double in it. Spec: `openspec/specs/architecture/acceptance`.
 */
export declare const acceptance: (o: Options) => Layer;

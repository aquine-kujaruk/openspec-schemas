import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** Adapters: the resource adapters behind the anti-corruption layers, the only place where the environment lives. Built apart from repositories, with the ACL as their seam. Spec: `openspec/specs/architecture/adapters`. */
export declare const adapters: (o: Options) => Layer;

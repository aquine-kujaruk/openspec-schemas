/**
 * A React frontend on the clean core: the core's workstreams, then one framework workstream
 * (react) that builds the screens against stub controllers and later replaces them with the
 * real ones, the glue between what is shown and the API behind the core.
 * A project changes the defaults in its root \`factory.config.ts\`. Nothing here names a product.
 */
declare const _default: SchemaVariant;
export default _default;

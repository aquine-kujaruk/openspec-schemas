import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** Cross-module rules: isolation between modules, cycles, no tests inside the product, and what holds for the whole core. Spec: `openspec/specs/architecture/modules`. */
export declare const modules: (o: Options) => Layer;

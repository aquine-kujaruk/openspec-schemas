import { modules } from "./modules.rules.js";
/** Reduce over app-domain and infrastructure: the rules that cut across modules and the whole core. */
export default { layers: (o) => [modules(o)] };

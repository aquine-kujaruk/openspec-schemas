import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** Integration: one test per repository implementation, over an in-memory adapter typed by the real ACL. Spec: `openspec/specs/architecture/integration`. */
export declare const integration: (o: Options) => Layer;

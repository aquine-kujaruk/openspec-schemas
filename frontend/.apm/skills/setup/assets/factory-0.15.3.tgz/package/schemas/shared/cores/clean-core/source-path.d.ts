/** The same source target can be named without an extension, as .ts, or as its emitted .js. */
export declare const sourceStem: (path: string) => string;

import { acceptance } from "./acceptance.rules.js";
import { application } from "./application.rules.js";
import { unit } from "./unit.rules.js";
import { domain } from "./domain.rules.js";
/** Acceptance and unit tests, application and domain; repositories are faked. */
export default {
    layers: (o) => [acceptance(o), domain(o), application(o), unit(o)],
    tests: ["acceptance", "unit"],
};

/**
 * The clean core: Clean Architecture's domain, application, infrastructure and adapters, and the
 * reduce workstream that holds the rules across modules. Its workstreams stay decoupled: verify runs
 * the whole-product checks that prove they work together. It names no framework; a schema that
 * names it adds one.
 */
declare const _default: CoreDefinition;
export default _default;

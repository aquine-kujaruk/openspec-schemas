import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** React framework without its JSX: controllers, queries, mutations, view-models and stores. Spec: `openspec/specs/architecture/framework`. */
export declare const framework: (o: Options) => Layer;

import type { Layer } from "factory/sdk";
import type { Options } from "factory/sdk";
/** Domain: entity | aggregate | value object | schema | exception | service. Imports nothing. Spec: `openspec/specs/architecture/domain`. */
export declare const domain: (o: Options) => Layer;

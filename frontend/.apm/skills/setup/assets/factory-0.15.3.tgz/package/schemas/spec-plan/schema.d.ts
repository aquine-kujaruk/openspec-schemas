import type { ArtifactDefinition, FactoryConfig } from "factory/sdk";
/** The instruction of the plan, around the paragraph on phases a schema writes for itself. */
export declare const planInstruction: (phases?: string) => string;
/** The two artifacts of a change: its plan, written with `instruction`, and its delta specs. */
export declare const artifacts: (instruction: string, planDescription: string) => ArtifactDefinition[];
/** Where a project keeps its code, tests and specs when it says nothing else. No workstream waits for another. */
export declare const defaults: FactoryConfig;
/**
 * A plan and delta specs, with no architecture: the change says what it decides, how the system is
 * operated and what it builds, and nothing checks where the code lands. The schemas that build a
 * product extend it.
 */
declare const _default: SchemaDefinition;
export default _default;

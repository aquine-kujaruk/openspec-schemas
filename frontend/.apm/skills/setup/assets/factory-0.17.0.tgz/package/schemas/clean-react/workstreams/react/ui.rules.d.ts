import type { Layer, Options } from "factory/sdk";
/** React UI: the JSX of the framework. Pages and components, bridges and the entry. The entry is a zone of the core's `modules` layer; this layer reaches it through the configured entry. Spec: `openspec/specs/architecture/ui`. */
export declare const ui: (o: Options) => Layer;

import { type Block } from "../schemas/plan-document.schema.js";
/** A consolidated block: where it lives and the change that last wrote it. */
export type Standing = {
    file: string;
    origin?: string;
    keys?: string[];
    body: string;
};
/** The consolidated decisions and procedures, by slug. A slug is unique within its tree. */
export type Consolidated = {
    decisions: Map<string, Standing>;
    procedures: Map<string, Standing>;
};
type Kind = "Decision" | "Procedure";
export declare class StandingRecordsService {
    revise(blocks: Block[], kind: Kind, origin: string, standing: ReadonlyMap<string, {
        file: string;
    }>, read: (path: string) => Promise<string | null>, product?: string): Promise<{
        path: string;
        before: string | null;
        after: string | null;
    }[]>;
}
/** Indexes the standing blocks in order. A repeated slug resolves to its last definition. */
export declare function indexStanding(documents: {
    file: string;
    document: string;
}[], kind: Kind): Map<string, Standing>;
export {};

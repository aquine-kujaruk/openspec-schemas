import type { AuditAcl } from "../acl/audit.acl.js";
type Question = Parameters<AuditAcl["askQuestions"]>[1][number];
type Answers = Awaited<ReturnType<AuditAcl["askQuestions"]>>;
export interface DecisionClient {
    ask(state: string, questions: Question[]): Promise<Answers>;
}
export type Inspection = {
    answers: Answers;
    issues: string[];
    unreadable: boolean;
};
export declare const inspect: (questions: Question[], response: unknown) => Inspection;
export declare const DECISIONS_ENDPOINT = "https://api.openai.com/v1/decisions";
export type OpenAiClientOptions = {
    key: string;
    model: string;
    endpoint?: string;
    timeoutMs?: number;
    fetch?: typeof fetch;
    onIssue?: (issue: string) => void;
};
/**
 * The OpenAI Decisions API. Retries once on 429, 5xx or a transport failure, never on another 4xx;
 * the key is sent in the header and never written anywhere else.
 */
export declare const openAiClient: (o: OpenAiClientOptions) => DecisionClient & {
    requests: number;
};
export {};

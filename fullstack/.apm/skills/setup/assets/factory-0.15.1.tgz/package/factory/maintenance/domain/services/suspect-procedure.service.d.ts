import { type EquipmentHoldings, type EquipmentProcedure, type ProcedureRun } from "../schemas/procedure-reading.schema.js";
export declare class SuspectProcedureService {
    /** The code of a procedure's body: each line of its fenced blocks and each inline code span. */
    codeOf(body: string): string[];
    /** A token that names something only known when the command runs: a variable, a placeholder, a glob. */
    private unknown;
    private unquote;
    /** What one simple command (no `&&`, `|` or `;`) needs, when it is one doctor can judge. */
    private needOf;
    /** The commands a procedure's body runs that doctor can judge. */
    runsOf(body: string): ProcedureRun[];
    private lacks;
    /** One line per command of a consolidated procedure that runs what the project no longer has. */
    suspectsOf(procedures: Map<string, EquipmentProcedure>, has: EquipmentHoldings): string[];
}

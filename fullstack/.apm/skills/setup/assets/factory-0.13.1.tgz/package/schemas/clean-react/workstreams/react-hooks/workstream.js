import { framework } from "./framework.rules.js";
/** The framework layer without its JSX: controllers, queries, mutations, view-models and stores. */
export default { layers: (o) => [framework(o)] };

import { type WorkCenterProps } from "../schemas/work-center.schema.js";
import type { WorkCenterId } from "../value-objects/work-center-id.value-object.js";
import type { Part } from "../value-objects/part.value-object.js";
export declare class WorkCenter {
    readonly id: WorkCenterId;
    readonly parts: Part[];
    readonly waitsFor: WorkCenterId[];
    constructor(props: WorkCenterProps);
}

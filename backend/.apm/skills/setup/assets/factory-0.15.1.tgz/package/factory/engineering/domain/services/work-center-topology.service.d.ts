import type { Options, Topology, Workstream, WorkstreamDeclaration } from "../../../shared/domain/schemas/line-types.schema.js";
/** What the implementer finds on disk: each workstream folder and the `<layer>.rules.ts` files in it. */
export type Folders = Record<string, {
    layerFiles: string[];
}>;
export declare class WorkCenterTopologyService {
    /**
     * Joins what each folder declares (`workstream.ts`) with the configured topology. Fails, naming the
     * workstreams involved, when the configuration and the folders disagree, when a dependency names no
     * workstream, when the dependencies form a cycle, or when a layer has no owner or two. The result
     * keeps the order of `declarations`, so composing the tools does not depend on the topology.
     */
    static loadWorkstreams: (declarations: Record<string, WorkstreamDeclaration>, folders: Folders, topology: Topology, o: Options) => Workstream[];
    private static findCycle;
    /** Every workstream `id` waits for, directly or through others. */
    static upstream: (ws: Workstream[], id: string) => string[];
    /** The order to run them in: a workstream after every one it depends on. */
    static runOrder: (ws: Workstream[]) => string[];
    /** Two workstreams may run at the same time when neither waits for the other. */
    static mayRunTogether: (ws: Workstream[], a: string, b: string) => boolean;
    /** The workstream that owns a layer. */
    static ownerOf: (ws: Workstream[], layer: string) => Workstream | undefined;
    /** A workstream and every one upstream of it: what its check and its reference cover. */
    static withUpstream: (ws: Workstream[], id: string) => Workstream[];
}

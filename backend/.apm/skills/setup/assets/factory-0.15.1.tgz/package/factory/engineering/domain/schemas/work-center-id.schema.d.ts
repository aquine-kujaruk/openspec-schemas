import { z } from "zod";
export declare const WorkCenterIdSchema: any;
export type WorkCenterIdProps = z.infer<typeof WorkCenterIdSchema>;

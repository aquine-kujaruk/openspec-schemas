import { type WorkCenterIdProps } from "../schemas/work-center-id.schema.js";
export declare class WorkCenterId {
    readonly value: string;
    constructor(props: WorkCenterIdProps);
}

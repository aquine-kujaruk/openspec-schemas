import { z } from "zod";
import { WorkCenterIdSchema } from "../schemas/work-center-id.schema.js";
import { PartValueObject } from "../value-objects/part.value-object.js";
export const WorkCenterSchema = z.object({
    id: WorkCenterIdSchema,
    parts: z.array(z.instanceof(PartValueObject)),
    waitsFor: z.array(WorkCenterIdSchema),
});

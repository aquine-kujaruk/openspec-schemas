import { type AuthorizationProps, type Refusal } from "../schemas/authorization.schema.js";
import type { ProtectedAreaValueObject } from "./protected-area.value-object.js";
export declare class AuthorizationValueObject {
    readonly blockedBy?: ProtectedAreaValueObject;
    readonly refusals: Refusal[];
    constructor(props: AuthorizationProps);
    get allowed(): boolean;
}

import { type DrawingProps, type Scenario } from "../schemas/drawing.schema.js";
export declare class DrawingEntity {
    readonly path: string;
    readonly scenarios: Scenario[];
    constructor(props: DrawingProps);
}

import type { Architecture, Workstream, Rule } from "../acl/inspection.acl.js";
export declare const archunitRules: (a: Architecture, tsconfig?: string) => Array<{
    layer: string;
    rules: Rule[];
}>;
export declare const idsInMessages: (text: string) => string[];
export declare const ownRuleIds: (a: Architecture, workstream: string) => Set<string>;
export declare const ruleIds: (a: Architecture, workstream: string) => Set<string>;
export type RulesPorts = {
    workingDirectory: () => string;
    existsSync: (typeof import("node:fs"))["existsSync"];
    writeFileSync: (typeof import("node:fs"))["writeFileSync"];
    join: (typeof import("node:path"))["join"];
    projectFiles: (typeof import("archunit"))["projectFiles"];
    COVERAGE_RULE: (typeof import("./inspection-config.adapter.js"))["COVERAGE_RULE"];
    layersOf: (typeof import("./inspection-config.adapter.js"))["layersOf"];
    oxlintOverrides: (typeof import("./inspection-config.adapter.js"))["oxlintOverrides"];
    withUpstream: (workstreams: Workstream[], id: string) => Workstream[];
    cacheDir: (typeof import("../../../shared/infrastructure/adapters/paths-contract.adapter.js"))["cacheDir"];
    product: {
        root: string;
    };
};

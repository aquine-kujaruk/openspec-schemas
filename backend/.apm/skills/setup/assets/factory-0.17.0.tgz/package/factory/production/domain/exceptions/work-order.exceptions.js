import { DomainException } from "../../../shared/domain/exceptions/domain.exceptions.js";
export class WorkOrderException extends DomainException {
}
export class NotValidatable extends WorkOrderException {
}
export class JudgementUnanswered extends WorkOrderException {
}

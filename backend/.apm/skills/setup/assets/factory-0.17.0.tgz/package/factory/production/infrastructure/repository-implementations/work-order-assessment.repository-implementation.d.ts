import type { WorkOrderAssessmentRepositoryInterface } from "../../application/repository-interfaces/work-order-assessment.repository-interface.js";
import { type StandingRecordAcl } from "../acl/standing-record.acl.js";
import type { WorkOrderAssessmentAcl } from "../acl/work-order-assessment.acl.js";
import type { WorkOrderRecordAcl } from "../acl/work-order-record.acl.js";
import type { DecisionJudgeAcl } from "../acl/decision-judge.acl.js";
import type { JudgementRequest } from "../../domain/services/work-order-assessment.service.js";
export declare class WorkOrderAssessmentRepositoryImplementation implements WorkOrderAssessmentRepositoryInterface {
    private readonly orders;
    private readonly standing;
    private readonly processes;
    private readonly judges;
    constructor(orders: WorkOrderRecordAcl, standing: StandingRecordAcl, processes: WorkOrderAssessmentAcl, judges: DecisionJudgeAcl);
    findWorkOrder(root: string, name: string): any;
    findArchivedWorkOrder(root: string, name: string): any;
    listWorkOrders(root: string): any;
    isWorkOrderStarted(root: string, name: string): any;
    listStanding(root: string): {
        decisions: any;
        procedures: any;
    };
    listProcesses(): any;
    loadProcess(name: string): any;
    listProducts(root: string): any;
    findJudge(root: string, product?: string): any;
    findJudgement(root: string, name: string, model: string, request: JudgementRequest): any;
    recordJudgement(root: string, name: string, model: string, request: JudgementRequest, probability: number): void;
}

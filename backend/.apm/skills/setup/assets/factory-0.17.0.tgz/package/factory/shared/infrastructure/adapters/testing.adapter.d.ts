export declare const write: (root: string, path: string, text: string) => void;
export declare const ONE_SCHEMA = "export default { schema: \"clean-backend\" };\n";
export declare const scratchProject: (prefix: string) => string;
export declare const delta: (useCase?: string) => string;
export declare const block: (kind: "Decision" | "Procedure", slug: string, tags: string[], body?: string) => string;
export type PlanParts = {
    decisions?: string[];
    procedures?: string[];
    phases?: boolean[];
    feedback?: string[];
    questions?: string[];
    bare?: boolean;
    approved?: string | null;
};
export declare const planText: (name: string, parts?: PlanParts) => string;
export declare const change: (root: string, name: string, { parts, deltas, created, schema, product, }?: {
    parts?: PlanParts;
    deltas?: Record<string, string>;
    created?: string;
    schema?: string;
    product?: string;
}) => void;
export declare const readyChange: (root: string, name: string, { done, schema, product, }?: {
    done?: boolean;
    schema?: string;
    product?: string;
}) => void;
export declare const productsOf: (text: string) => Record<string, {
    root: string;
    schema: string;
}>;
export declare const declareProducts: (root: string, text: string) => void;

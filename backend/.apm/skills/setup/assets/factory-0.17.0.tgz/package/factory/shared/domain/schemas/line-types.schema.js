import { z } from "zod";
export const VetoedSchema = z.object({ packages: z.array(z.string()), patterns: z.array(z.string()) });
export const ZoneSchema = z.object({ name: z.string(), patterns: z.array(z.string()) });
export const BoundarySchema = z.object({
    id: z.string().optional(),
    from: z.string(),
    allow: z.union([z.array(z.string()), z.literal("*")]),
});
export const ForbiddenCallsSchema = z.object({
    id: z.string(),
    from: z.string(),
    what: z.enum(["all", "persistence"]),
});
export const FallowSchema = z.object({
    zones: z.array(ZoneSchema),
    boundaries: z.array(BoundarySchema),
    forbiddenCalls: z.array(ForbiddenCallsSchema),
});
export const TopologySchema = z.record(z.string(), z.object({ dependsOn: z.array(z.string()) }));
export const LanguageServerSchema = z.object({
    name: z.string(),
    command: z.string(),
    args: z.array(z.string()),
    extensionToLanguage: z.record(z.string(), z.string()),
});

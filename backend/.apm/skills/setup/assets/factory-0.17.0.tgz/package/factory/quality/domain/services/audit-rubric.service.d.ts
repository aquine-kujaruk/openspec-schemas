import type { AuditRubric, AuditRow as Row, LoadedAuditRow as LoadedRow } from "../schemas/audit-material.schema.js";
export declare class AuditRubricService {
    parseRubric(markdown: string): {
        rows: Row[];
        product: string[];
    };
    checkGeneric(question: string, vocabulary: {
        packages: string[];
        product: string[];
    }): string | undefined;
    loadRubric(markdown: string, packages: string[]): LoadedRow[];
    loadDocuments(documents: AuditRubric[], packages: string[]): LoadedRow[];
}

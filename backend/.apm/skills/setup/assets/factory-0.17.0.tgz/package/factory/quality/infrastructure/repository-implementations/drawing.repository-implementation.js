import { DrawingEntity } from "../../domain/entities/drawing.entity.js";
import { GaugeValueObject } from "../../domain/value-objects/gauge.value-object.js";
export class DrawingRepositoryImplementation {
    tool;
    constructor(tool) {
        this.tool = tool;
    }
    async makeGauges(args) {
        const { exitStatus, drawings } = await this.tool.makeGauges(args);
        return {
            exitStatus,
            drawings: drawings.map(({ path, gherkin }) => new DrawingEntity({ path, scenarios: this.scenarios(gherkin) })),
            gauges: drawings.map(({ path, file }) => new GaugeValueObject({ drawing: path, file })),
        };
    }
    scenarios(gherkin) {
        const scenarios = [];
        let requirement = "Feature";
        for (const line of gherkin.split("\n")) {
            const rule = /^\s*Rule:\s+(.+)\s*$/.exec(line);
            if (rule)
                requirement = rule[1].trim();
            const scenario = /^\s*Scenario(?: Outline)?:\s+(.+)\s*$/.exec(line);
            if (scenario)
                scenarios.push({ title: scenario[1].trim(), requirement });
        }
        return scenarios;
    }
}

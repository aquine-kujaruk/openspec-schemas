import { z } from "zod";
const PATCH_FILE = /^\*\*\* (?:(?:Add|Update|Delete) File|Move to): (.+)$/gm;
export const WriteRequestSchema = z.array(z.string());
export const writeRequestOfHook = (input) => {
    const tool = input?.tool_input ?? {};
    const named = [tool.file_path, tool.notebook_path, tool.path].filter((path) => typeof path === "string");
    const command = Array.isArray(tool.command) ? tool.command.join("\n") : tool.command;
    const patched = typeof command === "string"
        ? [...command.matchAll(PATCH_FILE)].map((match) => match[1].trim())
        : [];
    return WriteRequestSchema.parse([...new Set([...named, ...patched])]);
};

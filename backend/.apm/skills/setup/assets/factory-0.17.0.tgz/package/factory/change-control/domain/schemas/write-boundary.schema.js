import { z } from "zod";
export const WritableLineSchema = z.object({
    name: z.string(),
    folder: z.string(),
    roots: z.array(z.string()),
    acceptance: z.string(),
});
export const WriteBoundarySchema = z.object({
    lines: z.array(WritableLineSchema),
    changes: z.string(),
    decisions: z.string(),
    procedures: z.string(),
});
export const ReleasedWorkOrderSchema = z.object({
    name: z.string(),
    process: z.string(),
    builds: z.boolean(),
    line: z.string().optional(),
});

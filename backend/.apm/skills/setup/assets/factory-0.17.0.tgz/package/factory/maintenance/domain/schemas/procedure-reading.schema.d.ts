import { z } from "zod";
export declare const NeedKind: {
    readonly Script: "script";
    readonly Binary: "binary";
    readonly File: "file";
};
export declare const ProcedureNeedSchema: any;
export type ProcedureNeed = z.infer<typeof ProcedureNeedSchema>;
export declare const ProcedureRunSchema: any;
export type ProcedureRun = z.infer<typeof ProcedureRunSchema>;
export declare const EquipmentProcedureSchema: any;
export type EquipmentProcedure = z.infer<typeof EquipmentProcedureSchema>;
export type EquipmentHoldings = {
    scripts: Set<string>;
    binaries: (name: string) => boolean;
    file: (path: string) => boolean;
};

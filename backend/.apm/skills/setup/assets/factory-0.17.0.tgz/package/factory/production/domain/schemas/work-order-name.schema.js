import { z } from "zod";
export const WorkOrderNameSchema = z.string().min(1);

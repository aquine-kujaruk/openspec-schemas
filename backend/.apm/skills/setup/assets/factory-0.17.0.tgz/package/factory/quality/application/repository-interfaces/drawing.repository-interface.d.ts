import type { DrawingEntity } from "../../domain/entities/drawing.entity.js";
import type { GaugeValueObject } from "../../domain/value-objects/gauge.value-object.js";
export type GaugeBatch = {
    exitStatus: number;
    drawings: DrawingEntity[];
    gauges: GaugeValueObject[];
};
export interface DrawingRepositoryInterface {
    makeGauges(args: readonly string[]): Promise<GaugeBatch>;
}

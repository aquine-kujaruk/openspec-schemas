import type { RulesPorts } from "./standard-check-contract.adapter.js";
export declare const createRules: ({ workingDirectory, existsSync, writeFileSync, join, projectFiles, COVERAGE_RULE, layersOf, oxlintOverrides, withUpstream, cacheDir, product, }: RulesPorts) => typeof import("./standard-check-contract.adapter.js");

import { type LineProps } from "../schemas/line.schema.js";
import type { LineName } from "../schemas/line-name.schema.js";
import type { ProcessName } from "../schemas/process-name.schema.js";
import type { LineRootsValueObject } from "../value-objects/line-roots.value-object.js";
export declare class LineEntity {
    readonly name: LineName;
    readonly folder: string;
    readonly process: ProcessName;
    readonly roots: LineRootsValueObject;
    constructor(props: LineProps);
}

import { z } from "zod";
export declare const WorkCenterSchema: any;
export type WorkCenterProps = z.infer<typeof WorkCenterSchema>;

import type { Judge } from "../../application/repository-interfaces/work-order-assessment.repository-interface.js";
import type { JudgementRequest } from "../../domain/services/work-order-assessment.service.js";
export interface DecisionJudgeAcl {
    judgeOf(root: string, product?: string): Promise<Judge | null>;
    recorded(root: string, name: string, model: string, request: JudgementRequest): number | undefined;
    record(root: string, name: string, model: string, request: JudgementRequest, probability: number): void;
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { DrawingSchema } from "../schemas/drawing.schema.js";
export class DrawingEntity {
    path;
    scenarios;
    constructor(props) {
        validateSchema(this, DrawingSchema, props);
    }
}

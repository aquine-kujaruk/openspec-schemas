import { QualityException } from "../../domain/exceptions/quality.exceptions.js";
export const createExamples = ({ workingDirectory, changeDirectory, globSync, mkdirSync, mkdtempSync, writeFileSync, tmpdir, basename, dirname, join, clearGraphCache, COVERAGE_RULE, fallowConfig, layersOf, oxlintConfig, oxlintOverrides, withUpstream, archunitRules, idsInMessages, parseExampleFile, jsonOf, runTool, }) => {
    const hit = (hits, id, file) => id && (hits.get(id) ?? hits.set(id, new Set()).get(id)).add(file);
    const fileOf = (v) => {
        const file = v.fileInfo?.path ??
            v.dependency?.sourceLabel ??
            v.cycle?.[0]?.sourceLabel ??
            v.projectedNode?.label;
        if (typeof file !== "string")
            throw new QualityException(`archunit violation without a file: ${JSON.stringify(v)}`, { cause: v });
        return file;
    };
    const TOOLS = ["fallow", "oxlint", "archunit"];
    const TEMPLATE = {
        "package.json": {
            name: "architecture-example",
            private: true,
            type: "module",
        },
        "tsconfig.json": {
            compilerOptions: {
                target: "es2023",
                module: "esnext",
                moduleResolution: "bundler",
                strict: false,
                jsx: "preserve",
                noEmit: true,
                skipLibCheck: true,
            },
            include: ["src", "test"],
        },
    };
    const examples = (a, dir, layer, modules = {}) => {
        const root = mkdtempSync(join(tmpdir(), "architecture-examples-"));
        const name = `${layer}.examples.md`;
        const parse = (d) => new Map(globSync("*.examples.md", { cwd: d }).map((f) => [
            f,
            parseExampleFile(join(d, f)),
        ]));
        const parsed = parse(dir);
        const known = a.workstreams.some((w) => w.id === basename(dir));
        const dirs = known
            ? withUpstream(a.workstreams, basename(dir)).map((w) => a.folders?.[w.id] ?? join(dirname(dir), w.id))
            : [dir];
        const reference = new Map();
        const from = new Map();
        for (const d of dirs)
            for (const [f, { reference: own }] of d === dir ? parsed : parse(d))
                for (const [path, content] of own) {
                    const where = join(basename(d), f);
                    if (reference.has(path) && reference.get(path) !== content)
                        throw new QualityException(`${where}: reference file ${path} differs from its copy in ${from.get(path)}`, { cause: { path, first: from.get(path), second: where } });
                    if (!reference.has(path))
                        from.set(path, where);
                    reference.set(path, content);
                }
        const filesOf = (example, rule) => {
            if (example === "reference")
                return reference;
            if (modules[example])
                return modules[example];
            const files = rule && parsed.get(name)?.rules.get(rule)?.get(example)?.files;
            if (!files)
                throw new QualityException(`${name} has no case \`${example}\` under \`## ${rule}\``, { cause: { example, rule } });
            return files;
        };
        const fallows = layersOf(a).flatMap((l) => (l.fallow ? [l.fallow] : []));
        const byZone = (kind) => new Map(fallows.flatMap((f) => f[kind].map((r) => [r.from, r.id])));
        const boundaryIds = byZone("boundaries");
        const callIds = byZone("forbiddenCalls");
        const owners = {
            fallow: new Set([
                ...boundaryIds.values(),
                ...callIds.values(),
                COVERAGE_RULE,
            ]),
            oxlint: new Set(idsInMessages(JSON.stringify(oxlintOverrides(a)))),
            archunit: new Set(archunitRules(a).flatMap((l) => l.rules.map((r) => r.id))),
        };
        const config = fallowConfig(a);
        const json = (cwd, cmd, args) => jsonOf(runTool(cmd, args, { cwd }).stdout);
        const tools = {
            fallow: (cwd) => {
                const hits = new Map();
                const r = json(cwd, "fallow", [
                    "architecture",
                    "--format",
                    "json",
                    "--quiet",
                ]);
                for (const v of r.boundary_violations)
                    hit(hits, boundaryIds.get(v.from_zone), v.from_path);
                for (const v of r.boundary_call_violations)
                    hit(hits, callIds.get(v.zone), v.path);
                for (const v of r.boundary_coverage_violations)
                    hit(hits, COVERAGE_RULE, v.path);
                return hits;
            },
            oxlint: (cwd) => {
                const hits = new Map();
                const r = json(cwd, "oxlint", [
                    "-c",
                    ".oxlintrc.json",
                    "-f",
                    "json",
                    "src",
                    "test",
                ]);
                for (const d of r.diagnostics)
                    hit(hits, idsInMessages(`${d.message} ${d.help ?? ""}`)[0], d.filename);
                return hits;
            },
            archunit: async (cwd) => {
                const hits = new Map();
                const back = workingDirectory();
                changeDirectory(cwd);
                clearGraphCache(); // archunit caches the graph by tsconfig path, and every example has "tsconfig.json".
                try {
                    for (const { rules } of archunitRules(a))
                        for (const rule of rules)
                            for (const v of await rule.check())
                                hit(hits, rule.id, fileOf(v));
                }
                finally {
                    changeDirectory(back);
                }
                return hits;
            },
        };
        const prepared = new Map();
        const prepare = (example, rule) => {
            const key = example === "reference" || modules[example]
                ? example
                : `${rule}/${example}`;
            if (!prepared.has(key)) {
                const cwd = join(root, key.replaceAll("/", "__"));
                for (const [path, content] of filesOf(example, rule)) {
                    mkdirSync(dirname(join(cwd, path)), { recursive: true });
                    writeFileSync(join(cwd, path), content);
                }
                const { ignorePatterns: _ignored, ...boundaries } = config;
                const files = {
                    ...TEMPLATE,
                    ".fallowrc.json": boundaries,
                    ".oxlintrc.json": oxlintConfig(oxlintOverrides(a)),
                };
                for (const [name, body] of Object.entries(files))
                    writeFileSync(join(cwd, name), JSON.stringify(body, null, 2));
                prepared.set(key, { cwd, ran: new Map() });
            }
            return prepared.get(key);
        };
        const run = async (tool, example, rule) => {
            const p = prepare(example, rule);
            if (!p.ran.has(tool))
                p.ran.set(tool, await tools[tool](p.cwd));
            return p.ran.get(tool);
        };
        return {
            violations: async (example, rule) => {
                const found = new Map();
                for (const tool of TOOLS)
                    if (owners[tool].has(rule))
                        for (const f of (await run(tool, example, rule)).get(rule) ?? [])
                            (found.get(f) ?? found.set(f, new Set()).get(f)).add(tool);
                return new Map([...found].sort(([a], [b]) => a.localeCompare(b)));
            },
            all: async (example, rules) => {
                const out = {};
                for (const tool of TOOLS)
                    for (const [id, files] of await run(tool, example))
                        if (rules.has(id))
                            out[id] = [...new Set([...(out[id] ?? []), ...files])].sort();
                return out;
            },
        };
    };
    return { fileOf, examples };
};

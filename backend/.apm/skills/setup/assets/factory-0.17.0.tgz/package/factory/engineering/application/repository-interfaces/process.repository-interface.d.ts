import type { ProcessName } from "../../../shared/domain/schemas/process-name.schema.js";
import type { ProcessAggregate } from "../../domain/aggregates/process.aggregate.js";
export interface ProcessRepositoryInterface {
    findProcess(name: ProcessName): Promise<ProcessAggregate | null>;
    listProcesses(): Promise<ProcessAggregate[]>;
}

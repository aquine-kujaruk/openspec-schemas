import { type GaugeProps } from "../schemas/gauge.schema.js";
export declare class GaugeValueObject {
    readonly drawing: string;
    readonly file: string;
    constructor(props: GaugeProps);
}

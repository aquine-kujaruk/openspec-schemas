import { z } from "zod";
export const StandardIdSchema = z.string().min(1);

import type { InspectionAcl, InspectionTools, QualityCheck } from "../acl/inspection.acl.js";
export declare class InspectionAdapter implements InspectionAcl {
    private readonly run;
    constructor(run: InspectionAcl["inspectLine"]);
    inspectLine(line: string, scope: readonly string[]): any;
}
export declare const createCheck: ({ globSync, writeFileSync, join, resolve, sep, COVERAGE_RULE, fallowConfig, oxlintConfig, fileOf, generate, withUpstream, cacheDir, jsonOf, PROJECT_ROOT, runTool, architecture, config, product, archunitRules, }: InspectionTools) => {
    check: QualityCheck;
};

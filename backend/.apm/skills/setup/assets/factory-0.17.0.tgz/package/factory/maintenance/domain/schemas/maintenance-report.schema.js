import { z } from "zod";
import { MaintenanceItemValueObject } from "../value-objects/maintenance-item.value-object.js";
export const MaintenanceReportSchema = z.object({ items: z.array(z.instanceof(MaintenanceItemValueObject)) });

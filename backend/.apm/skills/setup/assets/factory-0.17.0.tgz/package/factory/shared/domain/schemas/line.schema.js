import { z } from "zod";
import { LineNameSchema } from "../schemas/line-name.schema.js";
import { ProcessNameSchema } from "../schemas/process-name.schema.js";
import { LineRootsValueObject } from "../value-objects/line-roots.value-object.js";
export const LineSchema = z.object({
    name: LineNameSchema,
    folder: z.string().min(1),
    process: ProcessNameSchema,
    roots: z.instanceof(LineRootsValueObject),
});

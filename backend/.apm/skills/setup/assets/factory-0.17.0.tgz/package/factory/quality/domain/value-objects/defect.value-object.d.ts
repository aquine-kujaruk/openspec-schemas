import { type DefectProps } from "../schemas/defect.schema.js";
export declare class DefectValueObject {
    readonly file: string;
    readonly standard: string;
    readonly tool: string;
    constructor(props: DefectProps);
}

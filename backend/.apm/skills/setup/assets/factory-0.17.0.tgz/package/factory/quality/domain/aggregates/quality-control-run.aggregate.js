import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { QualityControlRunSchema } from "../schemas/quality-control-run.schema.js";
export class QualityControlRunAggregate {
    defects;
    exitStatus;
    constructor(props) {
        validateSchema(this, QualityControlRunSchema, props);
    }
    passed() {
        return this.exitStatus === 0 && this.defects.length === 0;
    }
}

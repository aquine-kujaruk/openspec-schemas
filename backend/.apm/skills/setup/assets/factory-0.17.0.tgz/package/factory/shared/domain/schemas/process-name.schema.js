import { z } from "zod";
export const ProcessNameSchema = z.string().min(1);

import { type PartProps } from "../schemas/part.schema.js";
import type { StandardValueObject } from "../value-objects/standard.value-object.js";
export declare class PartValueObject {
    readonly name: string;
    readonly standards: StandardValueObject[];
    constructor(props: PartProps);
}

import type { WorkOrderProcess } from "../../application/repository-interfaces/work-order-assessment.repository-interface.js";
import type { WorkOrderAssessmentAcl } from "../acl/work-order-assessment.acl.js";
type ProcessCatalog = {
    schemaNames(): string[];
    loadSchema(name: string): Promise<{
        validator: WorkOrderProcess["validator"];
        definition: {
            workstreams: string[];
            spike?: {
                workstream: string;
            };
        };
    }>;
    readProjectConfig(root: string): Promise<{
        products?: Record<string, {
            schema: string;
        }>;
    } | undefined>;
};
export declare class WorkOrderAssessmentAdapter implements WorkOrderAssessmentAcl {
    private readonly catalog;
    constructor(catalog: ProcessCatalog);
    listProcesses(): string[];
    loadProcess(name: string): Promise<WorkOrderProcess>;
    listProducts(root: string): unknown;
}
export {};

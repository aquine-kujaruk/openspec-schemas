import { z } from "zod";
import { StandardIdSchema } from "../schemas/standard-id.schema.js";
export const StandardSchema = z.object({
    id: StandardIdSchema,
    title: z.string().min(1),
});

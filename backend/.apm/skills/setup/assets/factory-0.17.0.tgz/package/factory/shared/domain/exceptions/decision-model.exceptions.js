import { DomainException } from "./domain.exceptions.js";
export class DecisionModelUnavailable extends DomainException {
}

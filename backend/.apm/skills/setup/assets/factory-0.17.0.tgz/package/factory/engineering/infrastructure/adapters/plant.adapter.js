import { existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";
export class PlantAdapter {
    root;
    readProducts;
    constructor(root, readProducts) {
        this.root = root;
        this.readProducts = readProducts;
    }
    async readPlant() {
        const products = await this.readProducts(this.root);
        return {
            root: this.root,
            lines: products.map(({ name, root, schema, config }) => ({
                name,
                folder: root,
                process: schema,
                roots: config,
            })),
        };
    }
    async prepareRoots(root, inputs) {
        return prepareRoots(root, inputs);
    }
}
const DEFAULT_BASE = [
    "shared/domain",
    "shared/application",
    "shared/infrastructure",
];
export const prepareRoots = (cwd, o) => {
    const created = [];
    const make = (dir) => {
        if (existsSync(join(cwd, dir)))
            return;
        mkdirSync(join(cwd, dir), { recursive: true });
        created.push(dir);
    };
    const moduleRoot = o.modules.replace(/\/\*$/, "");
    if (!existsSync(join(cwd, moduleRoot))) {
        make(moduleRoot);
        for (const dir of o.base ?? DEFAULT_BASE)
            make(`${moduleRoot}/${dir}`);
    }
    make(o.acceptance);
    make(o.integration);
    make(o.unit);
    return created;
};

import type { PlantAcl, PlantRecord, Product, RootRecord } from "../acl/plant.acl.js";
export declare class PlantAdapter implements PlantAcl {
    private readonly root;
    private readonly readProducts;
    constructor(root: string, readProducts: (root: string) => Promise<Product[]>);
    readPlant(): Promise<PlantRecord>;
    prepareRoots(root: string, inputs: RootRecord): Promise<string[]>;
}
type Roots = Pick<RootRecord, "modules" | "acceptance" | "integration" | "unit" | "base">;
export declare const prepareRoots: (cwd: string, o: Roots) => string[];
export {};

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { AndonPullSchema } from "../schemas/andon-pull.schema.js";
export class AndonPullValueObject {
    from;
    names;
    says;
    constructor(props) {
        validateSchema(this, AndonPullSchema, props);
    }
}

import type { ExampleFilePorts } from "./sample-file-contract.adapter.js";
export declare const createExampleFile: ({ readFileSync, findingLines, parseFindingLines, }: ExampleFilePorts) => typeof import("./sample-file-contract.adapter.js");

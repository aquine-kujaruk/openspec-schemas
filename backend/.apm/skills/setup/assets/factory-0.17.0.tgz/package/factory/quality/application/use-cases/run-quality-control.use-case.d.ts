import type { LineName } from "../../../shared/domain/schemas/line-name.schema.js";
import type { QualityControlRunAggregate } from "../../domain/aggregates/quality-control-run.aggregate.js";
import type { InspectionRepositoryInterface } from "../repository-interfaces/inspection.repository-interface.js";
export declare class RunQualityControlUseCase {
    private readonly repository;
    constructor(repository: InspectionRepositoryInterface);
    execute(line: LineName, scope: readonly string[]): Promise<QualityControlRunAggregate>;
}

import { type QualityControlRunProps } from "../schemas/quality-control-run.schema.js";
import type { DefectValueObject } from "../value-objects/defect.value-object.js";
export declare class QualityControlRunAggregate {
    readonly defects: DefectValueObject[];
    readonly exitStatus: number;
    constructor(props: QualityControlRunProps);
    passed(): boolean;
}

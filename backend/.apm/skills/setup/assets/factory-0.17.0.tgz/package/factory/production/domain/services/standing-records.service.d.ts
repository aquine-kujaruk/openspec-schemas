import { type Block } from "../schemas/plan-document.schema.js";
export type Standing = {
    file: string;
    origin?: string;
    keys?: string[];
    body: string;
};
export type Consolidated = {
    decisions: Map<string, Standing>;
    procedures: Map<string, Standing>;
};
type Kind = "Decision" | "Procedure";
export declare class StandingRecordsService {
    revise(blocks: Block[], kind: Kind, origin: string, standing: ReadonlyMap<string, {
        file: string;
    }>, read: (path: string) => Promise<string | null>, product?: string): Promise<{
        path: string;
        before: string | null;
        after: string | null;
    }[]>;
}
export declare function indexStanding(documents: {
    file: string;
    document: string;
}[], kind: Kind): Map<string, Standing>;
export {};

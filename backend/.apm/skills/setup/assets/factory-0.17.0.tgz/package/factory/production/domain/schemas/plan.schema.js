import { z } from "zod";
import { StageEntity } from "../entities/stage.entity.js";
import { DecisionValueObject } from "../value-objects/decision.value-object.js";
import { DaySchema } from "./day.schema.js";
export const PlanSchema = z.object({
    stages: z.array(z.instanceof(StageEntity)),
    decisions: z.array(z.instanceof(DecisionValueObject)).default([]),
    openQuestions: z.array(z.string()).default([]),
    releasedOn: DaySchema.optional(),
});

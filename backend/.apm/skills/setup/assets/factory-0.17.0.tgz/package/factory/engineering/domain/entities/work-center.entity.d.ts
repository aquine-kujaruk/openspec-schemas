import { type WorkCenterProps } from "../schemas/work-center.schema.js";
import type { WorkCenterId } from "../schemas/work-center-id.schema.js";
import type { PartValueObject } from "../value-objects/part.value-object.js";
export declare class WorkCenterEntity {
    readonly id: WorkCenterId;
    readonly parts: PartValueObject[];
    readonly waitsFor: WorkCenterId[];
    constructor(props: WorkCenterProps);
}

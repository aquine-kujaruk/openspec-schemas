import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { CHANGES } from "./work-order-record.adapter.js";
export const SOURCES = [
    "the person",
    "the completion gate",
    "the verify phase",
    "the archive",
    "the implement phase",
];
export class AndonSignalAdapter {
    raised(root, change) {
        const path = join(root, CHANGES, change, "feedback.json");
        return existsSync(path)
            ? JSON.parse(readFileSync(path, "utf8"))
            : [];
    }
    raise(root, change, feedback) {
        const all = [
            ...this.raised(root, change).filter((r) => r.source !== feedback.source || r.names !== feedback.names),
            feedback,
        ];
        writeFileSync(join(root, CHANGES, change, "feedback.json"), `${JSON.stringify(all, null, 2)}\n`);
    }
}

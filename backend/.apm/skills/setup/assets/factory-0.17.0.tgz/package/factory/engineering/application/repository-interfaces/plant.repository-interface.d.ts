import type { LineEntity } from "../../../shared/domain/entities/line.entity.js";
import type { PlantEntity } from "../../../shared/domain/entities/plant.entity.js";
export interface PlantRepositoryInterface {
    getPlant(): Promise<PlantEntity>;
    prepareRoots(plant: PlantEntity, line: LineEntity): Promise<string[]>;
}

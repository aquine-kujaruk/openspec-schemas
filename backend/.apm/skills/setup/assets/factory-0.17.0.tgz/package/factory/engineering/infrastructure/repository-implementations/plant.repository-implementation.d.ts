import { LineEntity } from "../../../shared/domain/entities/line.entity.js";
import { PlantEntity } from "../../../shared/domain/entities/plant.entity.js";
import type { PlantRepositoryInterface } from "../../application/repository-interfaces/plant.repository-interface.js";
import { type PlantAcl } from "../acl/plant.acl.js";
export declare class PlantRepositoryImplementation implements PlantRepositoryInterface {
    private readonly records;
    constructor(records: PlantAcl);
    getPlant(): Promise<PlantEntity>;
    prepareRoots(plant: PlantEntity, line: LineEntity): Promise<string[]>;
}

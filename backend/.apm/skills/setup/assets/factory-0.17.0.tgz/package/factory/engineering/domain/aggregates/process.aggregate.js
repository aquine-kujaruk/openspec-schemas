import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { WorkCenterEntity } from "../entities/work-center.entity.js";
import { EngineeringException } from "../exceptions/engineering.exceptions.js";
import { ProcessSchema } from "../schemas/process.schema.js";
export class ProcessAggregate {
    name;
    base;
    description;
    pilot;
    workCenters;
    constructor(props) {
        validateSchema(this, ProcessSchema, props);
    }
    static ofTopology(name, topology) {
        return new ProcessAggregate({
            name,
            workCenters: Object.entries(topology).map(([id, { dependsOn }]) => new WorkCenterEntity({ id, parts: [], waitsFor: dependsOn })),
        });
    }
    static loadWorkstreams(declarations, folders, topology, o) {
        const errors = [];
        for (const id of Object.keys(folders)) {
            if (!declarations[id])
                errors.push(`workstream ${id}: its folder has no registered workstream.ts`);
            if (!topology[id])
                errors.push(`workstream ${id}: the configuration's workstreams section does not list it`);
        }
        for (const id of Object.keys(topology))
            if (!folders[id])
                errors.push(`workstream ${id}: configured, but it has no folder`);
        const unknown = Object.entries(topology).flatMap(([id, { dependsOn }]) => dependsOn.filter((d) => !topology[d]).map((d) => `workstream ${id} depends on ${d}, which is no workstream`));
        errors.push(...unknown);
        const workstreams = Object.entries(declarations).map(([id, d]) => ({
            id,
            layers: d.layers(o),
            checks: d.checks ?? [],
            dependsOn: topology[id]?.dependsOn ?? [],
        }));
        const owners = new Map();
        for (const w of workstreams)
            for (const l of w.layers)
                owners.set(l.name, [...(owners.get(l.name) ?? []), w.id]);
        for (const [layer, ids] of owners)
            if (ids.length > 1)
                errors.push(`layer ${layer}: claimed by ${ids.join(", ")}`);
        for (const [id, { layerFiles }] of Object.entries(folders))
            for (const layer of layerFiles)
                if (!owners.has(layer))
                    errors.push(`layer ${layer}: ${id}/${layer}.rules.ts is owned by no workstream`);
        const cycle = unknown.length ? undefined : ProcessAggregate.ofTopology("workstreams", topology).cycle();
        if (cycle)
            errors.push(`workstream cycle: ${cycle.join(" → ")}`);
        if (errors.length)
            throw new EngineeringException(`the implementer does not load:\n  ${errors.join("\n  ")}`);
        return workstreams;
    }
    static ofWorkstreams(ws) {
        return ProcessAggregate.ofTopology("workstreams", Object.fromEntries(ws.map((w) => [w.id, { dependsOn: w.dependsOn }])));
    }
    static upstream(ws, id) {
        return ProcessAggregate.ofWorkstreams(ws).prerequisites(id).map((center) => center.id);
    }
    static runOrder(ws) {
        return ProcessAggregate.ofWorkstreams(ws).executionOrder().map((center) => center.id);
    }
    static mayRunTogether(ws, a, b) {
        return ProcessAggregate.ofWorkstreams(ws).mayRunTogether(a, b);
    }
    static ownerOf(ws, layer) {
        return ws.find((w) => w.layers.some((l) => l.name === layer));
    }
    static withUpstream(ws, id) {
        const ids = new Set([id, ...ProcessAggregate.upstream(ws, id)]);
        return ws.filter((w) => ids.has(w.id));
    }
    cycle() {
        const done = new Set();
        const visit = (center, path) => {
            if (done.has(center.id))
                return undefined;
            const at = path.indexOf(center.id);
            if (at !== -1)
                return [...path.slice(at), center.id];
            for (const id of center.waitsFor) {
                const found = visit(this.workCenter(id), [...path, center.id]);
                if (found)
                    return found;
            }
            done.add(center.id);
            return undefined;
        };
        for (const center of this.workCenters) {
            const found = visit(center, []);
            if (found)
                return found;
        }
        return undefined;
    }
    executionOrder() {
        const cycle = this.cycle();
        if (cycle)
            throw new EngineeringException(`Work centers form a cycle at ${cycle[0]}`);
        const ordered = new Set();
        const visit = (center) => {
            if (ordered.has(center))
                return;
            for (const id of center.waitsFor)
                visit(this.workCenter(id));
            ordered.add(center);
        };
        for (const center of this.workCenters)
            visit(center);
        return [...ordered];
    }
    prerequisites(id) {
        const upstream = new Set();
        const collect = (center) => {
            for (const dependencyId of center.waitsFor) {
                const dependency = this.workCenter(dependencyId);
                if (upstream.has(dependency))
                    continue;
                upstream.add(dependency);
                collect(dependency);
            }
        };
        collect(this.workCenter(id));
        return this.executionOrder().filter((center) => upstream.has(center));
    }
    mayRunTogether(left, right) {
        const earlier = this.workCenter(left);
        const later = this.workCenter(right);
        return !this.prerequisites(left).includes(later) && !this.prerequisites(right).includes(earlier);
    }
    workCenter(id) {
        const center = this.workCenters.find((current) => current.id === id);
        if (!center)
            throw new EngineeringException(`Unknown work center ${id}`);
        return center;
    }
}

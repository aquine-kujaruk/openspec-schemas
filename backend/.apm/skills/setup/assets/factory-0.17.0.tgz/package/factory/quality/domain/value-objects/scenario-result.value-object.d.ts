import { type ScenarioResultProps } from "../schemas/scenario-result.schema.js";
export declare class ScenarioResultValueObject {
    readonly spec: string;
    readonly requirement: string;
    readonly scenario: string;
    readonly result: ScenarioResultProps["result"];
    readonly by?: ScenarioResultProps["by"];
    constructor(props: ScenarioResultProps);
}

import { z } from "zod";
export declare const WorkCenterIdSchema: any;
export type WorkCenterId = z.infer<typeof WorkCenterIdSchema>;

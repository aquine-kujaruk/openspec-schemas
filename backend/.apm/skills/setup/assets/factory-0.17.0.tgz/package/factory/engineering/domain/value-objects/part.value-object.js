import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { PartSchema } from "../schemas/part.schema.js";
export class PartValueObject {
    name;
    standards;
    constructor(props) {
        validateSchema(this, PartSchema, props);
    }
}

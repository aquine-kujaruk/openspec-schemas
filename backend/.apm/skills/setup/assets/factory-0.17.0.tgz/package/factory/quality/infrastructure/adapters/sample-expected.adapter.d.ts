export declare const createExpectFile: () => typeof import("./sample-expected-contract.adapter.js");

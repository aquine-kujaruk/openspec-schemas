import { z } from "zod";
import type { MaintenanceItemProps } from "./maintenance-item.schema.js";
export declare const RepairKind: {
    readonly Pin: "pin";
    readonly Link: "link";
    readonly Default: "default";
    readonly Roots: "roots";
    readonly Instruction: "instruction";
};
export declare const EquipmentRepairSchema: any;
export type EquipmentRepair = z.infer<typeof EquipmentRepairSchema>;
export type EquipmentFinding = MaintenanceItemProps & {
    repair?: EquipmentRepair;
};
export declare const AgentReadingSchema: any;
export type AgentReading = z.infer<typeof AgentReadingSchema>;
export declare const EquipmentReadingSchema: any;
export type EquipmentReading = z.infer<typeof EquipmentReadingSchema>;
export declare const EquipmentNotesSchema: any;
export type EquipmentNotes = z.infer<typeof EquipmentNotesSchema>;
export declare const EquipmentPlaceSchema: any;
export type EquipmentPlace = z.infer<typeof EquipmentPlaceSchema>;

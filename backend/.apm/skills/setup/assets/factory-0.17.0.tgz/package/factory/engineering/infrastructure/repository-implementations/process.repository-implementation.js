import { ProcessAggregate } from "../../domain/aggregates/process.aggregate.js";
import { WorkCenterEntity } from "../../domain/entities/work-center.entity.js";
import { EngineeringException } from "../../domain/exceptions/engineering.exceptions.js";
import { PartValueObject } from "../../domain/value-objects/part.value-object.js";
import { StandardValueObject } from "../../domain/value-objects/standard.value-object.js";
import { ProcessRecordSchema } from "../acl/process.acl.js";
export class ProcessRepositoryImplementation {
    records;
    constructor(records) {
        this.records = records;
    }
    async listProcesses() {
        try {
            const records = ProcessRecordSchema.array().parse(await this.records.listProcesses());
            return records.map((record) => new ProcessAggregate({
                name: record.name,
                base: record.base ? record.base : undefined,
                description: record.description,
                pilot: record.pilot ? record.pilot : undefined,
                workCenters: record.workCenters.map((center) => new WorkCenterEntity({
                    id: center.id,
                    waitsFor: center.waitsFor,
                    parts: center.parts.map((part) => new PartValueObject({
                        name: part.name,
                        standards: part.standards.map((standard) => new StandardValueObject({
                            id: standard.id,
                            title: standard.title,
                        })),
                    })),
                })),
            }));
        }
        catch (cause) {
            throw new EngineeringException("The process definitions could not be loaded", { cause });
        }
    }
    async findProcess(name) {
        return (await this.listProcesses()).find((process) => process.name === name) ?? null;
    }
}

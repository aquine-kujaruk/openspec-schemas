import { AuthorizationValueObject } from "../../domain/value-objects/authorization.value-object.js";
import type { WriteRequest } from "../../domain/schemas/write-request.schema.js";
import type { ReleasedWorkOrderRepositoryInterface } from "../repository-interfaces/released-work-order.repository-interface.js";
import type { WriteBoundaryRepositoryInterface } from "../repository-interfaces/write-boundary.repository-interface.js";
export declare class AuthorizeWriteUseCase {
    private readonly boundary;
    private readonly orders;
    constructor(boundary: WriteBoundaryRepositoryInterface, orders: ReleasedWorkOrderRepositoryInterface);
    execute(request: WriteRequest): Promise<AuthorizationValueObject>;
}

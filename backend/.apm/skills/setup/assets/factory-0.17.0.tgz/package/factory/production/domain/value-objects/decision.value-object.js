import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { DecisionSchema } from "../schemas/decision.schema.js";
export class DecisionValueObject {
    text;
    by;
    constructor(props) {
        validateSchema(this, DecisionSchema, props);
    }
}

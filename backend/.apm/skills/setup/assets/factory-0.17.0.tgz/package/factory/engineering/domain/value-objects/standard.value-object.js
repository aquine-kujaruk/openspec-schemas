import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { StandardSchema } from "../schemas/standard.schema.js";
export class StandardValueObject {
    id;
    title;
    constructor(props) {
        validateSchema(this, StandardSchema, props);
    }
}

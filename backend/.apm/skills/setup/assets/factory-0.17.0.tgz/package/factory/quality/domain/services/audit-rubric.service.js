import { QualityException } from "../exceptions/quality.exceptions.js";
const CROSS_FILE = "across files";
const VOCABULARY = /^Product vocabulary[^:]*:\s*(.*)$/m;
const RUBRIC_HEADING = /^### Reviewer rubric/m;
const cells = (line) => /^\|(.*)\|\s*$/
    .exec(line)?.[1]
    .split(" | ")
    .map((c) => c.trim());
const firstSentence = (text) => {
    const plain = text.replace(/[*_]/g, "");
    const end = plain.search(/[.;](\s|$)/);
    return end === -1 ? plain : plain.slice(0, end);
};
const terms = (words) => [
    ...new Set(words
        .flatMap((w) => [w, w.replace(/^@[^/]+\//, "")])
        .map((w) => w.toLowerCase())),
];
const mentions = (question, term) => new RegExp(`(^|[^\\p{L}\\p{N}@/])${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "iu").test(question);
export class AuditRubricService {
    parseRubric(markdown) {
        const start = markdown.search(RUBRIC_HEADING);
        const section = start === -1 ? "" : markdown.slice(start);
        const product = [
            ...(VOCABULARY.exec(section)?.[1] ?? "").matchAll(/`([^`]+)`/g),
        ].map((m) => m[1].toLowerCase());
        const rows = [];
        for (const line of section.split("\n")) {
            const c = cells(line);
            if (!c || !/^S\d{2}$/.test(c[0]))
                continue;
            if (c.length < 4)
                throw new QualityException(`rubric row ${c[0]}: expected ID, rule, question and layers (${c.length} cells)`);
            const [id, rule, question, layers] = c;
            const crossFile = layers === CROSS_FILE;
            rows.push({
                id,
                title: firstSentence(rule),
                question,
                folders: crossFile
                    ? []
                    : layers
                        .split(",")
                        .map((f) => f.trim())
                        .filter(Boolean),
                crossFile,
            });
        }
        return { rows, product };
    }
    checkGeneric(question, vocabulary) {
        const named = [
            ...terms(vocabulary.packages).filter((t) => mentions(question, t)),
            ...terms(vocabulary.product).filter((t) => mentions(question, t)),
        ];
        return named.length
            ? `names ${named.map((n) => `\`${n}\``).join(", ")}`
            : undefined;
    }
    loadRubric(markdown, packages) {
        const { rows, product } = this.parseRubric(markdown);
        return rows.map((row) => {
            const reason = row.question
                ? this.checkGeneric(row.question, { packages, product })
                : "has no question";
            return reason
                ? { ...row, verdict: "rejected", reason }
                : { ...row, verdict: "accepted" };
        });
    }
    loadDocuments(documents, packages) {
        const from = new Map();
        const rows = [];
        for (const { path, markdown } of documents)
            for (const row of this.loadRubric(markdown, packages)) {
                if (from.has(row.id))
                    throw new QualityException(`rubric row ${row.id} is in ${from.get(row.id)} and in ${path}: a row id belongs to one rubric`);
                from.set(row.id, path);
                rows.push(row);
            }
        return rows;
    }
}

import { change, consolidated, validate } from "./production.js";
import { products } from "./engineering.js";
import { AuthorizeWriteUseCase } from "./change-control/application/use-cases/authorize-write.use-case.js";
import { writeRequestOfHook } from "./change-control/domain/schemas/write-request.schema.js";
import { ReleasedWorkOrderAdapter } from "./change-control/infrastructure/adapters/released-work-order.adapter.js";
import { WriteBoundaryAdapter } from "./change-control/infrastructure/adapters/write-boundary.adapter.js";
import { ReleasedWorkOrderRepositoryImplementation } from "./change-control/infrastructure/repository-implementations/released-work-order.repository-implementation.js";
import { WriteBoundaryRepositoryImplementation } from "./change-control/infrastructure/repository-implementations/write-boundary.repository-implementation.js";
import { runtime } from "./shared/infrastructure/adapters/runtime.adapter.js";
export const filesOf = (input) => writeRequestOfHook(input);
export const projectOf = WriteBoundaryAdapter.projectOf;
export const hookInput = WriteBoundaryAdapter.hookInput;
export async function guard(root, paths, cwd = root) {
    const boundary = new WriteBoundaryRepositoryImplementation(new WriteBoundaryAdapter(root, cwd, async () => ({
        lines: (await products.projectProducts(root)).map((line) => ({
            name: line.name,
            folder: line.root,
            roots: products.productRoots(line.config),
            acceptance: line.config.acceptance,
        })),
        changes: change.CHANGES,
        decisions: consolidated.DECISIONS,
        procedures: consolidated.PROCEDURES,
    })));
    const orders = new ReleasedWorkOrderRepositoryImplementation(new ReleasedWorkOrderAdapter(async () => (await validate.changesInImplementation(root)).map(({ name, schema, product, builds }) => ({
        name, process: schema, line: product, builds,
    }))));
    const check = await new AuthorizeWriteUseCase(boundary, orders).execute(paths);
    return check.refusals;
}
export async function authorizeWrite(args) {
    const input = args.length ? {} : hookInput();
    const cwd = input.cwd ?? runtime.workingDirectory();
    const root = projectOf(runtime.environment().CLAUDE_PROJECT_DIR || cwd);
    const refusals = await guard(root, args.length ? args : filesOf(input), cwd);
    for (const refusal of refusals)
        console.error(refusal.reason);
    return refusals.length ? 2 : 0;
}

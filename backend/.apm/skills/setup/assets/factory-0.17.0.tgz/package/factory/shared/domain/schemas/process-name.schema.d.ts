import { z } from "zod";
export declare const ProcessNameSchema: any;
export type ProcessName = z.infer<typeof ProcessNameSchema>;

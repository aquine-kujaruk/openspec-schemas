import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { DrawingRevisionSchema } from "../schemas/drawing-revision.schema.js";
export class DrawingRevisionValueObject {
    drawing;
    requirements;
    constructor(props) {
        validateSchema(this, DrawingRevisionSchema, props);
    }
}

import { z } from "zod";
import { LineNameSchema } from "../../../shared/domain/schemas/line-name.schema.js";
import { ProcessNameSchema } from "../../../shared/domain/schemas/process-name.schema.js";
import { PlanEntity } from "../entities/plan.entity.js";
import { AndonPullValueObject } from "../value-objects/andon-pull.value-object.js";
import { DrawingRevisionValueObject } from "../value-objects/drawing-revision.value-object.js";
import { WorkOrderNameSchema } from "../schemas/work-order-name.schema.js";
export const WorkOrderSchema = z.object({
    name: WorkOrderNameSchema,
    process: ProcessNameSchema,
    line: LineNameSchema.optional(),
    plan: z.instanceof(PlanEntity),
    revisions: z.array(z.instanceof(DrawingRevisionValueObject)).default([]),
    andonPulls: z.array(z.instanceof(AndonPullValueObject)).default([]),
}).transform(({ plan, ...order }) => ({ ...order, currentPlan: plan }));

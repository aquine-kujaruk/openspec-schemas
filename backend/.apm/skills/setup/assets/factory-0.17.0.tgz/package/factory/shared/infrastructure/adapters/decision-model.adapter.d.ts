import { DecisionModelUnavailable } from "../../domain/exceptions/decision-model.exceptions.js";
export { DecisionModelUnavailable };
export type DecisionQuestion = {
    name: string;
    instructions: string;
    excerpt?: string;
};
export type DecisionAnswers = Map<string, number>;
type Question = DecisionQuestion;
type Answers = DecisionAnswers;
export interface DecisionClient {
    ask(state: string, questions: Question[]): Promise<Answers>;
}
export type Inspection = {
    answers: Answers;
    issues: string[];
    unreadable: boolean;
};
export declare const inspect: (questions: Question[], response: unknown) => Inspection;
/** The OpenAI Decisions API; `FACTORY_DECISIONS_ENDPOINT` points another provider with the same contract. */
export declare const DECISIONS_ENDPOINT = "https://api.openai.com/v1/decisions";
export type DecisionModelOptions = {
    key: string;
    model: string;
    endpoint?: string;
    timeoutMs?: number;
    fetch?: typeof fetch;
    onIssue?: (issue: string) => void;
};
export declare const decisionModelClient: (o: DecisionModelOptions) => DecisionClient & {
    requests: number;
};

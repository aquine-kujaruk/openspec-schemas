import { DomainException } from "./domain.exceptions.js";
export declare class ValidationException extends DomainException {
    readonly source: string;
    constructor(source: string, cause: unknown);
}

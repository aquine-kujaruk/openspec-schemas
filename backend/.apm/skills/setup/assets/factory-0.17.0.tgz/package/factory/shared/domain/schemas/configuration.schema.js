import { z } from "zod";
import { PlantException } from "../exceptions/plant.exceptions.js";
import { PLATFORMS } from "./platform.schema.js";
export const RunnerSchema = z.union([z.literal("session"), z.object({ command: z.string() })]);
export const defineFactory = (c) => c;
const isSection = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
const merge = (base, over) => {
    if (over === undefined)
        return base;
    if (!isSection(base) || !isSection(over))
        return over;
    const out = { ...base };
    for (const [k, v] of Object.entries(over))
        out[k] = merge(base[k], v);
    return out;
};
export const resolveConfig = (defaults, project) => {
    const { schema: _schema, products: _products, implement: _implement, language: _language, platform, ...over } = project ?? {};
    if (over.review && "modules" in over.review) {
        const { modules: _legacyRoot, ...review } = over.review;
        over.review = review;
    }
    const resolved = merge(defaults, project ? over : undefined);
    return platform === undefined
        ? resolved
        : { ...resolved, platform: platformNamed(platform) };
};
const platformNamed = (platform) => {
    if (typeof platform !== "string")
        return platform;
    const found = PLATFORMS[platform];
    if (!found)
        throw new PlantException(`no platform is called ${platform}; platforms: ${Object.keys(PLATFORMS).join(", ")}`);
    return found;
};

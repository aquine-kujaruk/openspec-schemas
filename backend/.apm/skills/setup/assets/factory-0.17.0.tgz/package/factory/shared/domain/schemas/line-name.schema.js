import { z } from "zod";
export const LineNameSchema = z.string();

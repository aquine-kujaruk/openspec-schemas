import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { GaugeSchema } from "../schemas/gauge.schema.js";
export class GaugeValueObject {
    drawing;
    file;
    constructor(props) {
        validateSchema(this, GaugeSchema, props);
    }
}

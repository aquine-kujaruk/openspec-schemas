import { DomainException } from "./domain.exceptions.js";
export declare class DecisionModelUnavailable extends DomainException {
}

import type { WorkOrderRepositoryInterface } from "../repository-interfaces/work-order.repository-interface.js";
import type { StageStartRepositoryInterface } from "../repository-interfaces/stage-start.repository-interface.js";
type Started = {
    state: "started";
    phase: string;
    tasks: string[];
} | {
    state: "not ready" | "cannot start";
    findings: string[];
} | {
    state: "cannot validate";
    message: string;
} | {
    state: "nothing to build";
};
export declare class StartStageUseCase {
    private readonly orders;
    private readonly setup;
    constructor(orders: WorkOrderRepositoryInterface, setup: StageStartRepositoryInterface);
    execute(name: string): Promise<Started>;
}
export {};

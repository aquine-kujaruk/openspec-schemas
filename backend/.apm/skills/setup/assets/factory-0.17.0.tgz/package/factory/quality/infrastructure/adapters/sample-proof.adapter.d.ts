import type { ExpectationsPorts } from "./sample-proof-contract.adapter.js";
export declare const createExpectations: ({ parseExampleFile, findingLines, }: ExpectationsPorts) => typeof import("./sample-proof-contract.adapter.js");

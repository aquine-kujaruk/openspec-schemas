import type { FinalInspectionRepositoryInterface } from "../../application/repository-interfaces/final-inspection.repository-interface.js";
import type { QualityCertificateAggregate } from "../../domain/aggregates/quality-certificate.aggregate.js";
import type { Finding, GaugeReport } from "../../domain/schemas/inspect-work-order.schema.js";
import { type FinalInspectionAcl } from "../acl/final-inspection.acl.js";
export declare class FinalInspectionRepositoryImplementation implements FinalInspectionRepositoryInterface {
    private readonly records;
    constructor(records: FinalInspectionAcl);
    loadInspection(name: string): unknown;
    runGauges(files: string[]): Promise<GaugeReport>;
    runCheck(workstream: string): any;
    runTests(kind: "unit" | "integration"): any;
    checkFreshness(): any;
    runWholeCheck(): any;
    runEndToEnd(): any;
    findWorkstream(file: string): any;
    runAudit(): any;
    readDigest(name: string): any;
    saveCertificate(certificate: QualityCertificateAggregate): any;
    pullAndon(name: string, finding: Finding): any;
}

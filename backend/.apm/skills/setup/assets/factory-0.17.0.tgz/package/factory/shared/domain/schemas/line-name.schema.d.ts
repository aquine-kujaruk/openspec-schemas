import { z } from "zod";
export declare const LineNameSchema: any;
export type LineName = z.infer<typeof LineNameSchema>;

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { DefectSchema } from "../schemas/defect.schema.js";
export class DefectValueObject {
    file;
    standard;
    tool;
    constructor(props) {
        validateSchema(this, DefectSchema, props);
    }
}

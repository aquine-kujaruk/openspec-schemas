import { type StandardProps } from "../schemas/standard.schema.js";
import type { StandardId } from "../schemas/standard-id.schema.js";
export declare class StandardValueObject {
    readonly id: StandardId;
    readonly title: string;
    constructor(props: StandardProps);
}

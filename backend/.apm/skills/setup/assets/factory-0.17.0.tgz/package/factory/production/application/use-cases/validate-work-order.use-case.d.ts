import type { WorkOrderValidationRepositoryInterface } from "../repository-interfaces/work-order-validation.repository-interface.js";
export declare class ValidateWorkOrderUseCase {
    private readonly records;
    constructor(records: WorkOrderValidationRepositoryInterface);
    execute(name: string): Promise<{
        ready: boolean;
        findings: {
            rule: string;
            message: string;
        }[];
    }>;
}

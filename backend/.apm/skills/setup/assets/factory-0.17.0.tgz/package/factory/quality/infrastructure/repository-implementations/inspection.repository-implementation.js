import { InspectionRecordSchema } from "../acl/inspection.acl.js";
import { QualityControlRunAggregate } from "../../domain/aggregates/quality-control-run.aggregate.js";
import { DefectValueObject } from "../../domain/value-objects/defect.value-object.js";
export class InspectionRepositoryImplementation {
    tool;
    constructor(tool) {
        this.tool = tool;
    }
    async inspectLine(line, scope) {
        const result = InspectionRecordSchema.parse(await this.tool.inspectLine(line, scope));
        return new QualityControlRunAggregate({ exitStatus: result.exitStatus, defects: result.defects.map((defect) => new DefectValueObject(defect)) });
    }
}

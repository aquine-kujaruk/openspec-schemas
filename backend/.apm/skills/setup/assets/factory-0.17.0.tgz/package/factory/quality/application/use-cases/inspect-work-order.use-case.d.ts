import { QualityCertificateAggregate } from "../../domain/aggregates/quality-certificate.aggregate.js";
import type { FinalInspectionRepositoryInterface } from "../repository-interfaces/final-inspection.repository-interface.js";
export type InspectionOptions = {
    proved?: string[];
    procedures?: Record<string, "passed" | "failed">;
};
export declare class InspectWorkOrderUseCase {
    private readonly records;
    constructor(records: FinalInspectionRepositoryInterface);
    execute(name: string, options?: InspectionOptions): Promise<QualityCertificateAggregate>;
    private inspectScenarios;
    private inspectWorkstreams;
    private inspectWholeWorkOrder;
    private audit;
    private inspectProcedures;
    private reportFindings;
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { AuditFindingSchema } from "../schemas/audit-finding.schema.js";
export class AuditFindingValueObject {
    file;
    row;
    verdict;
    p;
    from;
    to;
    title;
    constructor(props) {
        validateSchema(this, AuditFindingSchema, props);
    }
    format() {
        return `${this.row} p=${this.p.toFixed(2)} ${this.file}:${this.from}-${this.to} — ${this.title}`;
    }
}

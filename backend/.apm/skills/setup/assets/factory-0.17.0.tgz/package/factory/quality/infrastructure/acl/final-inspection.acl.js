import { z } from "zod";
import { FinalInspectionSchema } from "../../domain/schemas/inspect-work-order.schema.js";
export const FinalInspectionRecordSchema = FinalInspectionSchema;
const FileGaugeRecordSchema = z.object({
    name: z.string(),
    status: z.string().optional(),
    assertionResults: z.array(z.object({ ancestorTitles: z.array(z.string()), title: z.string(), status: z.string() })),
});
export const FileGaugeReportSchema = z.object({ testResults: z.array(FileGaugeRecordSchema) });
export const InspectionAuditState = { Run: "run", Skipped: "skipped", Incomplete: "incomplete" };

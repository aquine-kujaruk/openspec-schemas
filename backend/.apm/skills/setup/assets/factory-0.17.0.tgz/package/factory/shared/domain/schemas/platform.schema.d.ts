import { z } from "zod";
export declare const PlatformSchema: any;
export type Platform = z.infer<typeof PlatformSchema>;
export declare const node: Platform;
export declare const web: Platform;
export declare const PLATFORMS: Record<string, Platform>;

import { z } from "zod";
export declare const ReviewSchema: any;
export type Review = z.infer<typeof ReviewSchema>;
export declare const DEFAULTS: Review;

import type { AuditAnswers, AuditFile, AuditQuestion, AuditRow, AuditSpan } from "../schemas/audit-material.schema.js";
import { AuditFindingValueObject } from "../value-objects/audit-finding.value-object.js";
export type AuditFunnelOptions = {
    ask: (state: string, questions: AuditQuestion[], locations: string[]) => Promise<AuditAnswers>;
    outline: (file: AuditFile) => AuditSpan[];
    rows: AuditRow[];
    files: AuditFile[];
    threshold: number;
    spanLines: number;
    batch: {
        files: number;
        chars: number;
    };
};
export declare class AuditFunnelService {
    inspect(o: AuditFunnelOptions): Promise<AuditFindingValueObject[]>;
}

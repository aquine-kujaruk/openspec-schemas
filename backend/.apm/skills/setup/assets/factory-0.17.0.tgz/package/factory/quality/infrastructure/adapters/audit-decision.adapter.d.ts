import { type DecisionClient, type DecisionModelOptions } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
export { DECISIONS_ENDPOINT, inspect, type DecisionClient, type Inspection } from "../../../shared/infrastructure/adapters/decision-model.adapter.js";
export type OpenAiClientOptions = DecisionModelOptions;
export declare const openAiClient: (o: OpenAiClientOptions) => DecisionClient & {
    requests: number;
};

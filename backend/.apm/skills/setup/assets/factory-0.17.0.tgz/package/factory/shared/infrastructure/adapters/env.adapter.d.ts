export declare const loadEnv: (root: string, env: NodeJS.ProcessEnv) => Record<string, string | undefined>;

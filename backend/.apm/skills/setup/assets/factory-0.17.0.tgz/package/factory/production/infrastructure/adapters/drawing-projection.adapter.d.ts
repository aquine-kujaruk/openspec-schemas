import type { DrawingProjectionAcl } from "../acl/drawing-projection.acl.js";
export declare class DrawingProjectionAdapter implements DrawingProjectionAcl {
    openspec(root: string, args: string[]): {
        status: any;
        output: any;
    };
    mergeDrawings(root: string, changes: string[]): {
        root: any;
        changes: string[];
        dispose: () => any;
    };
}

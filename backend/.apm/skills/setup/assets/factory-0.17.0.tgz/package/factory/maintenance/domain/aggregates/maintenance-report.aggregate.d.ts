import { type MaintenanceReportProps } from "../schemas/maintenance-report.schema.js";
import type { MaintenanceItemValueObject } from "../value-objects/maintenance-item.value-object.js";
export declare class MaintenanceReportAggregate {
    readonly items: MaintenanceItemValueObject[];
    constructor(props: MaintenanceReportProps);
    get status(): 0 | 1;
}

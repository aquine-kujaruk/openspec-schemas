import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { WorkCenterSchema } from "../schemas/work-center.schema.js";
export class WorkCenterEntity {
    id;
    parts;
    waitsFor;
    constructor(props) {
        validateSchema(this, WorkCenterSchema, props);
    }
}

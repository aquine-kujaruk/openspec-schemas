import type { LintRules, Platform, Vetoed } from "../acl/inspection.acl.js";
export type ImportVeto = {
    id: string;
    names: string[];
    patterns: string[];
    message: string;
};
export declare const restrictedImportsOf: (vetoes: ImportVeto[]) => LintRules;
export declare const restrictedImports: (id: string, names: string[], patterns: string[], message: string) => LintRules;
export declare const restrictedGlobals: (id: string, names: string[], where?: string) => LintRules;
export declare const coreRules: (vetoed: Vetoed, platform: Platform, message: string, more?: ImportVeto[]) => LintRules;
export declare const schemaPackageVeto: (o: {
    schemaPackage: string;
}) => ImportVeto;

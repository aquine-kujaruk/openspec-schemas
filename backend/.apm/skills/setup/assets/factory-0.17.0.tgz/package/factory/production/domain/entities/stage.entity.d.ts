import { type StageProps } from "../schemas/stage.schema.js";
import type { OperationValueObject } from "../value-objects/operation.value-object.js";
export declare class StageEntity {
    readonly title: string;
    readonly operations: OperationValueObject[];
    constructor(props: StageProps);
    get complete(): boolean;
}

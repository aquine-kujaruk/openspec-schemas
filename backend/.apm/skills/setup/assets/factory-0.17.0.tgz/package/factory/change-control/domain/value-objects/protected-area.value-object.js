import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { ProtectedAreaSchema } from "../schemas/protected-area.schema.js";
export class ProtectedAreaValueObject {
    name;
    patterns;
    guidance;
    suffix;
    regularExpression;
    constructor(props) {
        validateSchema(this, ProtectedAreaSchema, props);
    }
    covers(path) {
        if (this.suffix && !path.endsWith(this.suffix))
            return false;
        return this.patterns.some((pattern) => this.regularExpression
            ? new RegExp(pattern).test(path)
            : path === pattern || path.startsWith(`${pattern}/`));
    }
}

import { z } from "zod";
import { ProcessNameSchema } from "../../../shared/domain/schemas/process-name.schema.js";
import { WorkCenterIdSchema } from "../schemas/work-center-id.schema.js";
import { WorkCenterEntity } from "../entities/work-center.entity.js";
export const ProcessSchema = z.object({
    name: ProcessNameSchema,
    base: ProcessNameSchema.optional(),
    description: z.string().optional(),
    pilot: WorkCenterIdSchema.optional(),
    workCenters: z.array(z.instanceof(WorkCenterEntity)),
});

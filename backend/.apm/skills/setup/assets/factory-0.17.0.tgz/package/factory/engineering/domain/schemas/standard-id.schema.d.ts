import { z } from "zod";
export declare const StandardIdSchema: any;
export type StandardId = z.infer<typeof StandardIdSchema>;

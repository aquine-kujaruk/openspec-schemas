import type { AndonSignalAcl, Raised } from "../acl/andon-signal.acl.js";
export declare const SOURCES: readonly ["the person", "the completion gate", "the verify phase", "the archive", "the implement phase"];
export declare class AndonSignalAdapter implements AndonSignalAcl {
    raised(root: string, change: string): Raised[];
    raise(root: string, change: string, feedback: Raised): void;
}

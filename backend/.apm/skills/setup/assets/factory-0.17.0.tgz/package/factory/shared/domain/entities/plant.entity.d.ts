import { type PlantProps } from "../schemas/plant.schema.js";
import type { LineEntity } from "../entities/line.entity.js";
import type { LineName } from "../schemas/line-name.schema.js";
export declare class PlantEntity {
    readonly root: string;
    readonly lines: LineEntity[];
    constructor(props: PlantProps);
    findLine(name: LineName): LineEntity | undefined;
}

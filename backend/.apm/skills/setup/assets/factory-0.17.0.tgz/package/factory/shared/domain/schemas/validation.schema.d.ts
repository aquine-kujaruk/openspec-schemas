import type { z } from "zod";
export declare const validateSchema: <S extends z.ZodType>(target: object, schema: S, props: unknown) => z.output<S>;

import { z } from "zod";
export const AuditRowSchema = z.object({
    id: z.string(),
    title: z.string(),
    question: z.string(),
    folders: z.array(z.string()),
    crossFile: z.boolean(),
});
export const LoadedAuditRowSchema = AuditRowSchema.extend({
    verdict: z.enum(["accepted", "rejected"]),
    reason: z.string().optional(),
});
export const AuditSourceSchema = z.object({ path: z.string(), content: z.string() });
export const AuditFileSchema = AuditSourceSchema.extend({ folder: z.string() });
export const AuditQuestionSchema = z.object({
    name: z.string(),
    instructions: z.string(),
    excerpt: z.string(),
});
export const AuditRubricSchema = z.object({ path: z.string(), markdown: z.string() });
export const AuditPassSchema = z.object({
    rubric: z.string().optional(),
    files: z.record(z.string(), z.object({ hash: z.string(), commit: z.string().nullable() })),
});

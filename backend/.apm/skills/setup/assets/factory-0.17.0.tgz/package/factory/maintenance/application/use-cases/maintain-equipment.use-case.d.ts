import { MaintenanceReportAggregate } from "../../domain/aggregates/maintenance-report.aggregate.js";
import type { EquipmentRepositoryInterface, MaintenanceOptions } from "../repository-interfaces/equipment.repository-interface.js";
export declare class MaintainEquipmentUseCase {
    private readonly equipment;
    private readonly inspection;
    private readonly suspectProcedures;
    constructor(equipment: EquipmentRepositoryInterface);
    execute(root: string, { fix, env, node }?: MaintenanceOptions): Promise<MaintenanceReportAggregate | null>;
}

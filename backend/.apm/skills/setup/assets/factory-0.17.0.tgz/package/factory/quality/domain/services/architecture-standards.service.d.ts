type FileInfo = {
    path: string;
    name: string;
    content: string;
};
import type { Rule, RuleContext } from "../../../shared/domain/schemas/line-types.schema.js";
export declare const has: (re: RegExp) => (file: FileInfo) => any;
export declare const not: (re: RegExp) => (file: FileInfo) => boolean;
export declare const pascal: (kebab: string) => string;
export type Param = {
    name: string;
    type?: string;
};
export declare const constructorParams: (content: string) => Param[][];
export declare const constructorBody: (content: string) => string | undefined;
export declare const throws: (content: string) => Array<{
    name: string;
    args: string;
}>;
export type Import = {
    names: string[];
    specifier: string;
    resolved: string;
};
export declare const importsOf: (file: Pick<FileInfo, "path" | "content">) => Import[];
export declare const codeOnly: (content: string) => string;
export type ClassDecl = {
    name: string;
    exported: boolean;
    abstract: boolean;
    extends?: string;
    implements: string[];
};
export declare const classesOf: (content: string) => ClassDecl[];
export declare class ArchitectureStandardsService {
    readonly vocabularyRules: (id: string, layer: string, modules: string, vocabulary: Record<string, string>) => (ctx: RuleContext) => Rule[];
    readonly namesTheRoleRule: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule;
    readonly throwsDomainExceptionsRule: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule;
}
declare const vocabulary: (id: string, layer: string, modules: string, vocabulary: Record<string, string>) => (ctx: RuleContext) => Rule[], role: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule, exceptions: (folder: string, modules: string, skip?: string) => (ctx: RuleContext) => Rule;
export { vocabulary as vocabularyRules, role as namesTheRoleRule, exceptions as throwsDomainExceptionsRule };
export declare const glued: (content: string, path?: string) => number[];

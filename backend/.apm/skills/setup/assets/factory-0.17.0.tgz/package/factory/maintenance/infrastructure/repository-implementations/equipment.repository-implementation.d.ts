import type { EquipmentRepositoryInterface, MaintenanceOptions } from "../../application/repository-interfaces/equipment.repository-interface.js";
import { EquipmentEntity } from "../../domain/entities/equipment.entity.js";
import type { EquipmentRepair } from "../../domain/schemas/equipment-reading.schema.js";
import type { EquipmentAcl } from "../acl/equipment.acl.js";
export declare class EquipmentRepositoryImplementation implements EquipmentRepositoryInterface {
    private readonly resources;
    constructor(resources: EquipmentAcl);
    findEquipment(root: string): EquipmentEntity | null;
    inspectEquipment(root: string, equipment: EquipmentEntity, node?: string): unknown;
    repairEquipment(root: string, equipment: EquipmentEntity, repair: EquipmentRepair): void;
    readNotes(root: string, equipment: EquipmentEntity, env?: MaintenanceOptions["env"]): any;
    listProcedures(root: string): any;
    readHoldings(root: string): any;
    private read;
}

import type { EquipmentEntity } from "../entities/equipment.entity.js";
import { type EquipmentFinding, type EquipmentNotes, type EquipmentReading } from "../schemas/equipment-reading.schema.js";
export declare class EquipmentInspectionService {
    findings(equipment: EquipmentEntity, reading: EquipmentReading): EquipmentFinding[];
    notes(equipment: EquipmentEntity, reading: EquipmentNotes): string[];
}

import { z } from "zod";
import type { FactoryConfig, Platform } from "./line-types.schema.js";
export type DeepPartial<T> = T extends readonly unknown[] ? T : T extends object ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : T;
export type Overrides = Omit<DeepPartial<FactoryConfig>, "platform"> & {
    platform?: string | Platform;
};
export type ProductEntry = Overrides & {
    root: string;
    schema: string;
};
export type ProjectConfig = Overrides & {
    schema?: string;
    products?: Record<string, ProductEntry>;
    implement?: {
        runner?: Runner;
    };
    /** The language the agent shows the artifacts of `openspec/` in; `FACTORY_LANGUAGE` overrides it. */
    language?: string;
};
export declare const RunnerSchema: any;
export type Runner = z.infer<typeof RunnerSchema>;
export declare const defineFactory: (c: ProjectConfig) => ProjectConfig;
export declare const resolveConfig: (defaults: FactoryConfig, project?: ProjectConfig) => FactoryConfig;

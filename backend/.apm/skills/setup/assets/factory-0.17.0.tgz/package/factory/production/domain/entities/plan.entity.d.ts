import { type PlanProps } from "../schemas/plan.schema.js";
import type { Day } from "../schemas/day.schema.js";
import type { DecisionValueObject } from "../value-objects/decision.value-object.js";
import type { StageEntity } from "./stage.entity.js";
export declare class PlanEntity {
    readonly stages: StageEntity[];
    readonly decisions: DecisionValueObject[];
    readonly openQuestions: string[];
    readonly releasedOn?: Day;
    constructor(props: PlanProps);
}

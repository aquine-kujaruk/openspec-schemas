import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { StageHoldSchema } from "../schemas/stage-hold.schema.js";
export class StageHoldValueObject {
    held;
    reasons;
    constructor(props) {
        validateSchema(this, StageHoldSchema, props);
    }
    get allowed() {
        return !this.held;
    }
}

import { z } from "zod";
import { LineEntity } from "../entities/line.entity.js";
export const PlantSchema = z.object({
    root: z.string().min(1),
    lines: z.array(z.instanceof(LineEntity)),
});

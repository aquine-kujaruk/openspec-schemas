import { type EquipmentHoldings, type EquipmentProcedure, type ProcedureRun } from "../schemas/procedure-reading.schema.js";
export declare class SuspectProcedureService {
    codeOf(body: string): string[];
    private unknown;
    private unquote;
    private needOf;
    runsOf(body: string): ProcedureRun[];
    private lacks;
    suspectsOf(procedures: Map<string, EquipmentProcedure>, has: EquipmentHoldings): string[];
}

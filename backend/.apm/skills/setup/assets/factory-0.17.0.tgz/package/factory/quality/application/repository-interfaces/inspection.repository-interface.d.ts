import type { LineName } from "../../../shared/domain/schemas/line-name.schema.js";
import type { QualityControlRunAggregate } from "../../domain/aggregates/quality-control-run.aggregate.js";
export interface InspectionRepositoryInterface {
    inspectLine(line: LineName, scope: readonly string[]): Promise<QualityControlRunAggregate>;
}

import { type OperationProps } from "../schemas/operation.schema.js";
import type { WorkCenterId } from "../schemas/operation.schema.js";
export declare class OperationValueObject {
    readonly workCenter?: WorkCenterId;
    readonly text: string;
    readonly done: boolean;
    constructor(props: OperationProps);
}

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { OperationSchema } from "../schemas/operation.schema.js";
export class OperationValueObject {
    workCenter;
    text;
    done;
    constructor(props) {
        validateSchema(this, OperationSchema, props);
    }
}

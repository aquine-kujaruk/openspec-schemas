import type { GaugeRunAcl } from "../acl/gauge-run.acl.js";
export declare class GaugeRunAdapter implements GaugeRunAcl {
    private readonly run;
    constructor(run: GaugeRunAcl["runGauges"]);
    runGauges(args: readonly string[]): any;
}
import type { GaugeRunnerTools } from "../acl/gauge-run.acl.js";
export declare const createTest: ({ environment, nodeExecutable, spawnSync, existsSync, readFileSync, rmSync, writeFileSync, basename, join, cacheDir, PROJECT_ROOT, config, product, }: GaugeRunnerTools) => Pick<typeof import("../acl/gauge-run.acl.js"), "E2E_TOOLS" | "testsOf" | "runE2e" | "test">;

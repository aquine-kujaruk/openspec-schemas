import type { ProcessName } from "../../../shared/domain/schemas/process-name.schema.js";
import type { ProcessRepositoryInterface } from "../../application/repository-interfaces/process.repository-interface.js";
import { ProcessAggregate } from "../../domain/aggregates/process.aggregate.js";
import { type ProcessAcl } from "../acl/process.acl.js";
export declare class ProcessRepositoryImplementation implements ProcessRepositoryInterface {
    private readonly records;
    constructor(records: ProcessAcl);
    listProcesses(): Promise<ProcessAggregate[]>;
    findProcess(name: ProcessName): Promise<ProcessAggregate | null>;
}

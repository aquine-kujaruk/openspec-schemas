import type { CatalogSchema } from "../acl/process.acl.js";
export declare const schemaFiles: (schema: CatalogSchema) => Record<string, string>;
export declare const emitSchema: (schema: CatalogSchema, dir: string) => string[];

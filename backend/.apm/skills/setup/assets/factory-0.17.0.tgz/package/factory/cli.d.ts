import type { Commands, CliHost } from "./shared/infrastructure/adapters/cli-contract.adapter.js";
export declare const runCli: (given: string[], own: Commands, host: CliHost) => Promise<number>;

import type { Options, Topology, Workstream, WorkstreamDeclaration } from "../../../shared/domain/schemas/line-types.schema.js";
import type { ProcessName } from "../../../shared/domain/schemas/process-name.schema.js";
import { WorkCenterEntity } from "../entities/work-center.entity.js";
import { type ProcessProps } from "../schemas/process.schema.js";
import type { WorkCenterId } from "../schemas/work-center-id.schema.js";
export type Folders = Record<string, {
    layerFiles: string[];
}>;
export declare class ProcessAggregate {
    readonly name: ProcessName;
    readonly base?: ProcessName;
    readonly description?: string;
    readonly pilot?: WorkCenterId;
    readonly workCenters: WorkCenterEntity[];
    constructor(props: ProcessProps);
    static ofTopology(name: ProcessName, topology: Topology): ProcessAggregate;
    static loadWorkstreams(declarations: Record<string, WorkstreamDeclaration>, folders: Folders, topology: Topology, o: Options): Workstream[];
    private static ofWorkstreams;
    static upstream(ws: Workstream[], id: string): string[];
    static runOrder(ws: Workstream[]): string[];
    static mayRunTogether(ws: Workstream[], a: string, b: string): boolean;
    static ownerOf(ws: Workstream[], layer: string): Workstream | undefined;
    static withUpstream(ws: Workstream[], id: string): Workstream[];
    cycle(): string[] | undefined;
    executionOrder(): WorkCenterEntity[];
    prerequisites(id: WorkCenterId): WorkCenterEntity[];
    mayRunTogether(left: WorkCenterId, right: WorkCenterId): boolean;
    private workCenter;
}

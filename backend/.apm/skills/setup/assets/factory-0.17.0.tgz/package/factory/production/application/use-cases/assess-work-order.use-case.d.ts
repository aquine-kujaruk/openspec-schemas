import { type Building, type Verdict } from "../../domain/services/work-order-assessment.service.js";
import type { WorkOrderAssessmentRepositoryInterface } from "../repository-interfaces/work-order-assessment.repository-interface.js";
export declare class AssessWorkOrderUseCase {
    private readonly policy;
    private readonly records;
    constructor(records: WorkOrderAssessmentRepositoryInterface);
    execute(root: string, name: string): Promise<Verdict>;
    private judgeAndValidate;
    private judge;
    changesInImplementation(root: string): Promise<Building[]>;
}

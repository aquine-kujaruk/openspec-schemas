import { z } from "zod";
export const NeedKind = { Script: "script", Binary: "binary", File: "file" };
export const ProcedureNeedSchema = z.discriminatedUnion("kind", [
    z.object({ kind: z.literal(NeedKind.Script), name: z.string() }),
    z.object({ kind: z.literal(NeedKind.Binary), name: z.string() }),
    z.object({ kind: z.literal(NeedKind.File), path: z.string() }),
]);
export const ProcedureRunSchema = z.object({ command: z.string(), need: ProcedureNeedSchema });
export const EquipmentProcedureSchema = z.object({
    file: z.string(),
    body: z.string(),
    keys: z.array(z.string()).optional(),
});

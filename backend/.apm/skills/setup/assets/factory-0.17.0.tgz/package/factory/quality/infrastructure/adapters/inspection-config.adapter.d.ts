import type { Architecture, Layer, OxlintOverride } from "../acl/inspection.acl.js";
export declare const layersOf: (a: Architecture) => Layer[];
export declare const COVERAGE_RULE = "every-file-in-a-zone";
export declare const oxlintOverrides: (a: Architecture) => OxlintOverride[];
export declare const oxlintConfig: (overrides: OxlintOverride[], root?: string) => {
    categories: {
        correctness: string;
    };
    overrides: any;
};
export declare const fallowConfig: (a: Architecture) => {
    ignorePatterns: any;
    boundaries: {
        zones: any;
        rules: any;
        calls: {
            forbidden: any;
        };
        coverage: {
            requireAllFiles: boolean;
            allowUnmatched: any;
        };
    };
};

import { validateSchema } from "../../../shared/domain/schemas/validation.schema.js";
import { ScenarioResultSchema } from "../schemas/scenario-result.schema.js";
export class ScenarioResultValueObject {
    spec;
    requirement;
    scenario;
    result;
    by;
    constructor(props) {
        validateSchema(this, ScenarioResultSchema, props);
    }
}

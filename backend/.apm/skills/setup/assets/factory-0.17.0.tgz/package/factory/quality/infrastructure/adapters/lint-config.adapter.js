export const restrictedImportsOf = (vetoes) => ({
    "no-restricted-imports": [
        "error",
        {
            paths: vetoes.flatMap((v) => v.names.map((name) => ({ name, message: `[${v.id}] ${v.message}` }))),
            patterns: vetoes.flatMap((v) => v.patterns.length
                ? [{ group: v.patterns, message: `[${v.id}] ${v.message}` }]
                : []),
        },
    ],
});
export const restrictedImports = (id, names, patterns, message) => restrictedImportsOf([{ id, names, patterns, message }]);
export const restrictedGlobals = (id, names, where = "in infrastructure/adapters") => ({
    "no-restricted-globals": [
        "error",
        ...names.map((name) => ({
            name,
            message: `[${id}] ${name} only ${where}`,
        })),
    ],
});
export const coreRules = (vetoed, platform, message, more = []) => ({
    ...restrictedImportsOf([
        {
            id: "no-framework-import",
            names: vetoed.packages,
            patterns: vetoed.patterns,
            message,
        },
        ...more,
    ]),
    ...restrictedGlobals("no-environment", platform.all),
});
export const schemaPackageVeto = (o) => ({
    id: "schema-package-only-at-boundaries",
    names: [o.schemaPackage],
    patterns: [`${o.schemaPackage}/*`],
    message: `${o.schemaPackage} is imported only in domain/schemas, infrastructure/acl and infrastructure/adapters`,
});

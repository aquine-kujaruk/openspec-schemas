import { MaintenanceReportAggregate } from "../../domain/aggregates/maintenance-report.aggregate.js";
import { MaintenanceKind } from "../../domain/schemas/maintenance-item.schema.js";
import { EquipmentInspectionService } from "../../domain/services/equipment-inspection.service.js";
import { MaintenanceItemValueObject } from "../../domain/value-objects/maintenance-item.value-object.js";
import { FindSuspectProceduresUseCase } from "./find-suspect-procedures.use-case.js";
const id = (lack) => `${lack.requirement}|${lack.agent ?? ""}|${lack.detail}`;
export class MaintainEquipmentUseCase {
    equipment;
    inspection = new EquipmentInspectionService();
    suspectProcedures;
    constructor(equipment) {
        this.equipment = equipment;
        this.suspectProcedures = new FindSuspectProceduresUseCase(equipment);
    }
    async execute(root, { fix, env, node } = {}) {
        const installed = this.equipment.findEquipment(root);
        if (!installed)
            return null;
        const findings = async () => this.inspection.findings(installed, await this.equipment.inspectEquipment(root, installed, node));
        const tried = new Map();
        const failures = new Map();
        for (; fix;) {
            const next = (await findings()).find((lack) => lack.repair && !tried.has(id(lack)));
            if (!next?.repair)
                break;
            tried.set(id(next), next);
            try {
                this.equipment.repairEquipment(root, installed, next.repair);
            }
            catch (cause) {
                failures.set(id(next), cause instanceof Error ? cause.message : String(cause));
            }
        }
        const remaining = await findings();
        const still = new Set(remaining.map(id));
        const notes = this.inspection.notes(installed, this.equipment.readNotes(root, installed, env));
        const suspects = await this.suspectProcedures.execute(root);
        return new MaintenanceReportAggregate({ items: [
                ...[...tried].filter(([key]) => !still.has(key))
                    .map(([, item]) => new MaintenanceItemValueObject({ ...item, repaired: true })),
                ...remaining.map((item) => new MaintenanceItemValueObject({ ...item, detail: failures.get(id(item)) ?? item.detail })),
                ...notes.map((detail) => new MaintenanceItemValueObject({ kind: MaintenanceKind.Note, requirement: "maintenance", detail })),
                ...suspects.map((detail) => new MaintenanceItemValueObject({ kind: MaintenanceKind.Suspect, requirement: "a suspect runbook", detail })),
            ] });
    }
}

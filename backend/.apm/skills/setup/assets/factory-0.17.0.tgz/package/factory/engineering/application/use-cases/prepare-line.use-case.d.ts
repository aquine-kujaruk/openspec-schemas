import type { LineName } from "../../../shared/domain/schemas/line-name.schema.js";
import type { PlantRepositoryInterface } from "../repository-interfaces/plant.repository-interface.js";
export declare class PrepareLineUseCase {
    private readonly plants;
    constructor(plants: PlantRepositoryInterface);
    execute(name: LineName): Promise<string[]>;
}

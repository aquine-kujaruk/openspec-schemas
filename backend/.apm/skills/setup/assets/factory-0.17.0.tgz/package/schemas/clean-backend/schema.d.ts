/**
 * Clean Architecture for a backend: the clean core with no delivery layer. A project changes the
 * defaults in its root \`factory.config.ts\`: a value it sets replaces the default, a section merges
 * key by key. Nothing here names a product.
 */
declare const _default: SchemaVariant;
export default _default;

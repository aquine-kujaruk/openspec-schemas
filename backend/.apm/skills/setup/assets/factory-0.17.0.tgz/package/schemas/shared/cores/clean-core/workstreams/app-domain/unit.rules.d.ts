import type { Layer, Options } from "factory/sdk";
/** Unit tests mirror the domain or application file they prove. Spec: `openspec/specs/architecture/unit`. */
export declare const unit: (o: Options) => Layer;

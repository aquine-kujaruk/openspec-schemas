/** Spec: `flow/plan-validation`. A change is ready when no rule finds anything. */
declare const _default: Validator;
export default _default;

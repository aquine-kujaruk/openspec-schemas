import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { activeChanges, CHANGES, GATE, readChange } from "./change.js";
import { PROJECT_ROOT, self } from "../core/paths.js";
import { parsePlan } from "./plan.js";
import { loadSchema } from "../repository/schema.js";
import { NotValidatable, validateChange } from "./validate.js";
/**
 * Starts the implementation of the change `name`: only when validation reports it ready, on the
 * first phase of its plan that has an unchecked task. The roots are prepared and the tests
 * generated from its delta specs; from then on the change is in implementation.
 */
export const start = async (root, name) => {
    const verdict = await validateChange(root, name);
    if (!verdict.ready)
        return { state: "not ready", findings: verdict.findings.map((f) => `[${f.rule}] ${f.message}`) };
    const change = readChange(root, name);
    const phase = parsePlan(change.plan).phases.find((p) => p.tasks.some((t) => !t.done));
    if (!phase)
        return { state: "nothing to build" };
    // The product's roots are laid only for a schema that builds product code, and with products only
    // those of the change's own product. The tests are generated for every product, so the harness
    // the gate checks stays whole.
    const builds = (await loadSchema(verdict.schema)).definition.workstreams.length > 0;
    const over = change.product ? ["--product", change.product] : [];
    const steps = builds ? [["prepare", ...over], ["generate"]] : [["generate"]];
    for (const step of steps) {
        const r = self(root, step);
        if (r.status !== 0)
            return { state: "cannot start", findings: [r.output] };
    }
    writeFileSync(join(root, CHANGES, name, GATE), `${JSON.stringify({ phase: phase.title, failures: 0, waitingFor: "the agent", findings: [] }, null, 2)}\n`);
    return {
        state: "started",
        phase: phase.title,
        tasks: phase.tasks.filter((t) => !t.done).map((t) => t.text),
    };
};
/**
 * `factory implement <change>`: starts building the next phase of a ready change. Exit status 0
 * when it is started or has nothing left to build, 1 when it cannot be started, 2 when the change
 * cannot be judged.
 */
export const run = async (args) => {
    const [name] = args;
    const known = activeChanges(PROJECT_ROOT);
    if (!name || !known.includes(name)) {
        console.error(`Name the change to implement. Changes: ${known.join(", ") || "none"}`);
        return 2;
    }
    try {
        const started = await start(PROJECT_ROOT, name);
        if (started.state === "started") {
            const product = readChange(PROJECT_ROOT, name)?.product;
            console.log(`in implementation: ${name}${product ? ` (product ${product})` : ""} — ${started.phase}`);
            for (const task of started.tasks)
                console.log(`- [ ] ${task}`);
            return 0;
        }
        if (started.state === "nothing to build") {
            console.log(`every task of ${name} is done: the verify phase is next`);
            return 0;
        }
        console.log(`${started.state}: ${name}`);
        for (const finding of started.findings)
            console.log(`- ${finding}`);
        return 1;
    }
    catch (e) {
        if (!(e instanceof NotValidatable))
            throw e;
        console.error(e.message);
        return 2;
    }
};

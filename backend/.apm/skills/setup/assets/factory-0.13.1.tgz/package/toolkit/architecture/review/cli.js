import { capture, PROJECT_ROOT } from "../../core/paths.js";
import { architecture, RUBRICS } from "../project.js";
import { openAiClient } from "./client.js";
import { loadEnv } from "./env.js";
import { readRecord, writeRecord } from "./record.js";
import { DEFAULTS, review } from "./review.js";
import { readRubric } from "./rubric.js";
const headCommit = (root) => {
    const r = capture("git", ["rev-parse", "HEAD"], { cwd: root });
    return r.status === 0 ? r.stdout.trim() : null;
};
export const main = async (o) => {
    const config = architecture.review ?? DEFAULTS;
    const key = o.env[config.keyVariable];
    if (!key) {
        o.stderr(`${config.keyVariable} is not set: factory review needs the decision model's key in the environment or in .env`);
        return 2;
    }
    const rubric = o.rubric ?? RUBRICS;
    if (![rubric].flat().length) {
        o.stderr("the schema this project is checked with has no rubric: there is nothing to review");
        return 2;
    }
    const rows = readRubric(o.root, rubric);
    const client = o.client?.(key) ??
        openAiClient({ key, model: config.model, onIssue: (i) => o.stderr(`model: ${i}`) });
    try {
        const result = await review({
            root: o.root,
            rows,
            client,
            config,
            record: readRecord(o.root),
            commit: headCommit(o.root),
        });
        writeRecord(o.root, result.record);
        for (const line of result.lines)
            o.stdout(line);
        return 0;
    }
    catch (e) {
        o.stderr(e instanceof Error ? e.message : String(e));
        return 3;
    }
};
export const run = () => main({
    root: PROJECT_ROOT,
    env: loadEnv(PROJECT_ROOT, process.env),
    stdout: console.log,
    stderr: console.error,
});
export { loadEnv };

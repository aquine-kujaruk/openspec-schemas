import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
export const RECORD_FILE = ".factory-review.json";
export const hashOf = (content) => createHash("sha256").update(content).digest("hex").slice(0, 16);
/** What the model is asked: id, question and folders of every row; the rule text is prose for people. */
export const rubricHash = (rows) => hashOf(JSON.stringify(rows
    .map((r) => [r.id, r.question, r.folders, r.crossFile])
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))));
export const emptyRecord = () => ({ files: {} });
export const readRecord = (root) => {
    const file = join(root, RECORD_FILE);
    if (!existsSync(file))
        return emptyRecord();
    const parsed = JSON.parse(readFileSync(file, "utf8"));
    return { ...(parsed.rubric ? { rubric: parsed.rubric } : {}), files: parsed.files ?? {} };
};
export const writeRecord = (root, record) => writeFileSync(join(root, RECORD_FILE), `${JSON.stringify(record, null, 2)}\n`);
/**
 * The files changed since the pass that last judged them; with an empty record, or one written
 * under another rubric, every file.
 */
export const touched = (files, record, rubric) => rubric !== undefined && record.rubric !== rubric
    ? files
    : files.filter((f) => record.files[f.path]?.hash !== hashOf(f.content));
/** The record after a pass that judged `judged` under `rubric`: those files are marked, the rest kept. */
export const recordPass = (record, judged, commit, rubric) => {
    const files = { ...record.files };
    for (const f of judged)
        files[f.path] = { hash: hashOf(f.content), commit };
    const kept = rubric ?? record.rubric;
    return {
        ...(kept ? { rubric: kept } : {}),
        files: Object.fromEntries(Object.entries(files).sort(([a], [b]) => a.localeCompare(b))),
    };
};

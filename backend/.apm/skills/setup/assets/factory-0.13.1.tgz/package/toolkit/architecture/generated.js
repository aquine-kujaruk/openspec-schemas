import { globSync } from "node:fs";
import { basename, dirname, join, relative } from "node:path";
import { ARCHITECTURE_SPECS, PACKAGE_ROOT, SOURCE_EXT } from "../core/paths.js";
import { productOf } from "../repository/products.js";
import { holderNames, loadHolder } from "../repository/schema.js";
/**
 * The test generation writes for `spec` (`<area>/<name>`), from the root: under the acceptance
 * root in a project, next to the spec's step adapter in the repository, and none there for a spec
 * that has no step adapter.
 */
export const testOf = (spec, layout) => {
    const file = `${basename(spec)}.feature.test.ts`;
    const own = layout.product ? spec.replace(new RegExp(`^${layout.product}/`), "") : spec;
    if (!layout.repository)
        return join(layout.acceptance, dirname(own), file);
    const folder = layout.adapterFolder(spec);
    return folder === undefined ? undefined : join(folder, file);
};
/** The layout of the project at `root`, for the product `named` when the project declares products. */
export const layoutOf = async (root, named) => {
    const { config, name } = await productOf(root, named);
    const { acceptance } = config;
    if (root !== PACKAGE_ROOT)
        return { repository: false, acceptance, product: name || undefined, adapterFolder: () => undefined };
    // A layer's spec is proved in the folder of the workstream that owns the layer, whoever holds it.
    const owners = new Map();
    for (const holder of await holderNames(root))
        for (const dir of Object.values((await loadHolder(holder, root)).workstreamDirs))
            for (const rules of globSync(`*.rules${SOURCE_EXT}`, { cwd: dir }))
                owners.set(basename(rules, `.rules${SOURCE_EXT}`), relative(root, dir));
    const adapters = new Map(globSync("**/*.feature.steps.ts", {
        cwd: root,
        exclude: (f) => ["node_modules", "dist", "workstreams"].includes(f),
    }).map((f) => [basename(f, ".feature.steps.ts"), dirname(f)]));
    const layers = relative(join(root, "openspec/specs"), join(root, ARCHITECTURE_SPECS));
    return {
        repository: true,
        acceptance,
        adapterFolder: (spec) => (dirname(spec) === layers ? owners.get(basename(spec)) : undefined) ?? adapters.get(basename(spec)),
    };
};

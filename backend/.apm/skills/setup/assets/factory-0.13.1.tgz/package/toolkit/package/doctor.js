import { existsSync, lstatSync, mkdirSync, readFileSync, realpathSync, rmSync, symlinkSync, writeFileSync, } from "node:fs";
import { dirname, join, relative } from "node:path";
import { parse, parseDocument } from "yaml";
import { DECISIONS, PROCEDURES, readConsolidated } from "../flow/consolidated.js";
import { loadEnv } from "../architecture/review/env.js";
import { capture, COMMAND, INSTALLED, PROJECT_ROOT, SETUP_ASSETS } from "../core/paths.js";
import { projectProducts, readProjectConfig } from "../repository/products.js";
import { holdingsOf, suspectsOf } from "./suspects.js";
export const PLACES = {
    claude: {
        skills: ".claude/skills",
        instruction: { rules: ".claude/rules" },
        hooks: ".claude/settings.json",
    },
    codex: { skills: ".agents/skills", instruction: { file: "AGENTS.md" }, hooks: ".codex/hooks.json" },
};
/** The markers of the section the agent package manager manages in an instruction file. */
export const SECTION = { start: "<!-- apm:start -->", end: "<!-- apm:end -->" };
const SPECS = "openspec/specs";
const SCHEMAS = "openspec/schemas";
const CONFIG = "openspec/config.yaml";
const GUARDS = [`${COMMAND} guard`, `${COMMAND} gate`];
const text = (path) => existsSync(path) ? readFileSync(path, "utf8") : undefined;
/** What the installed package says about itself, read from the first agent that has its setup skill. */
export const readInstalled = (root) => {
    for (const place of Object.values(PLACES)) {
        const assets = join(place.skills, SETUP_ASSETS);
        const record = text(join(root, assets, INSTALLED));
        if (record)
            return { installed: JSON.parse(record), assets };
    }
    return undefined;
};
/** The version of the command the project depends on, as its lockfile records it. */
export const pinnedVersion = (root) => {
    const manifest = JSON.parse(text(join(root, "package.json")) ?? "{}");
    const lock = text(join(root, "pnpm-lock.yaml"));
    if (!manifest.devDependencies?.[COMMAND] || !lock)
        return undefined;
    const { importers, packages } = parse(lock);
    const resolved = importers?.["."]?.devDependencies?.[COMMAND]?.version;
    return resolved ? (packages?.[`${COMMAND}@${resolved}`]?.version ?? resolved) : undefined;
};
/** The instruction file with the package's instructions as its one managed section, the project's own lines kept. */
export const withSection = (own, instructions) => {
    const section = `${SECTION.start}\n${instructions.join("\n\n")}\n${SECTION.end}`;
    const before = own ?? "";
    const start = before.indexOf(SECTION.start);
    const end = before.indexOf(SECTION.end);
    if (start !== -1 && end > start)
        return before.slice(0, start) + section + before.slice(end + SECTION.end.length);
    return `${before.trim() ? `${before.trimEnd()}\n\n` : ""}${section}\n`;
};
/** The link of `schema` under the project's schemas leads to that schema inside the installed command. */
export const schemaLinkHolds = (root, schema) => {
    const link = join(root, SCHEMAS, schema);
    const inside = join(root, "node_modules", COMMAND, SCHEMAS, schema);
    return (existsSync(join(link, "schema.yaml")) &&
        existsSync(inside) &&
        realpathSync(link) === realpathSync(inside));
};
/** The guard commands the hook file of `agent` does not call. */
export const unwiredGuards = (root, agent) => {
    const wiring = text(join(root, PLACES[agent]?.hooks ?? "")) ?? "";
    return GUARDS.filter((guard) => !wiring.includes(guard));
};
/** Whether `version` is at least `least`, both `major.minor.patch`. */
const atLeast = (version, least) => {
    const [a, b] = [version, least].map((v) => v.replace(/^v/, "").split(".").map(Number));
    for (let i = 0; i < 3; i++)
        if ((a[i] ?? 0) !== (b[i] ?? 0))
            return (a[i] ?? 0) > (b[i] ?? 0);
    return true;
};
/** The end-to-end packages and the Node a web product lacks, when the package pins them. */
const e2eLacks = (installed, depends, node) => {
    const e2e = installed.project.e2e;
    if (!e2e)
        return [];
    const exact = (v) => v?.replace(/^[\^~=]/, "");
    const off = Object.entries(e2e.packages).filter(([name, version]) => exact(depends(name)) !== version);
    return [
        ...(off.length
            ? [
                {
                    requirement: "the end-to-end tool",
                    detail: `a web product runs its end-to-end tests with ${off.map(([n, v]) => `${n}@${v}`).join(", ")}: add ${off.length > 1 ? "them" : "it"} at that version to the project's development dependencies`,
                },
            ]
            : []),
        // e2e runs on Node 22 from 22.22.3, or on 24.8 and later.
        ...(atLeast(node, e2e.node) && (node.replace(/^v/, "").startsWith("22.") || atLeast(node, "24.8.0"))
            ? []
            : [{ requirement: "the end-to-end tool", detail: `Node ${node} is older than the end-to-end tool needs: use Node ${e2e.node} or 24.8 and later` }]),
    ];
};
const lacks = (root, installed, assets, web = false, node = process.version) => {
    const found = [];
    const at = (path) => join(root, path);
    const run = (args) => {
        const r = capture("pnpm", args, { cwd: root });
        if (r.status !== 0)
            throw new Error(`pnpm ${args.join(" ")} failed:\n${r.stdout}\n${r.stderr}`);
    };
    const pinned = pinnedVersion(root);
    if (pinned !== installed.version)
        found.push({
            requirement: "the pinned command",
            detail: pinned
                ? `the skills name ${COMMAND} ${installed.version} and the project depends on ${pinned}`
                : `the project does not depend on ${COMMAND} ${installed.version}`,
            ...(pinned ? { drift: true } : {}),
            // A drifted pin names a tarball the package update removed, and `pnpm add` re-resolves it and
            // fails: the specifier is rewritten and installed instead.
            repair: () => {
                const tarball = `./${join(assets, installed.command)}`;
                if (!pinned)
                    return run(["add", "-D", tarball]);
                run(["pkg", "set", `devDependencies.${COMMAND}=file:${tarball}`]);
                // Under CI, pnpm freezes the lockfile by default; the repair exists to rewrite it.
                run(["install", "--no-frozen-lockfile"]);
            },
        });
    for (const schema of installed.schemas) {
        const link = at(join(SCHEMAS, schema));
        const inside = at(join("node_modules", COMMAND, SCHEMAS, schema));
        if (schemaLinkHolds(root, schema))
            continue;
        const ownFolder = existsSync(link) && !lstatSync(link).isSymbolicLink();
        found.push({
            requirement: "a schema link",
            detail: ownFolder
                ? `${join(SCHEMAS, schema)} is a folder of the project: remove it so the schema of the installed command takes its place`
                : `${join(SCHEMAS, schema)} does not lead to the schema inside the installed command`,
            ...(ownFolder
                ? {}
                : {
                    repair: () => {
                        rmSync(link, { force: true });
                        mkdirSync(dirname(link), { recursive: true });
                        symlinkSync(relative(dirname(link), inside), link);
                    },
                }),
        });
    }
    const config = text(at(CONFIG));
    if (typeof parse(config ?? "")?.schema !== "string")
        found.push({
            requirement: "the default schema",
            detail: `${CONFIG} names no schema`,
            repair: () => {
                const document = parseDocument(config ?? "");
                document.set("schema", installed.schemas[0]);
                mkdirSync(dirname(at(CONFIG)), { recursive: true });
                writeFileSync(at(CONFIG), String(document));
            },
        });
    const roots = [SPECS, DECISIONS, PROCEDURES].filter((dir) => !existsSync(at(dir)));
    if (roots.length)
        found.push({
            requirement: "the consolidated roots",
            detail: `${roots.join(", ")} ${roots.length > 1 ? "do" : "does"} not exist`,
            repair: () => {
                for (const dir of roots) {
                    mkdirSync(at(dir), { recursive: true });
                    writeFileSync(at(join(dir, ".gitkeep")), "");
                }
            },
        });
    const own = JSON.parse(text(at("package.json")) ?? "{}");
    const declared = { ...own.dependencies, ...own.devDependencies };
    const depends = (name) => name in declared;
    if (web)
        found.push(...e2eLacks(installed, (name) => declared[name], node));
    const { testRunner, typeChecker } = installed.project;
    if (!depends(testRunner))
        found.push({
            requirement: "a test runner",
            detail: `add ${testRunner} to the project's development dependencies`,
        });
    if (!depends(typeChecker.name))
        found.push({
            requirement: "a type checker",
            detail: `add ${typeChecker.name} ${typeChecker.version} to the project's development dependencies`,
        });
    const instructions = Object.entries(installed.instructions);
    for (const agent of installed.agents) {
        const place = PLACES[agent];
        if (!place) {
            found.push({
                requirement: "the phase skills",
                agent,
                detail: `the command does not know where ${agent} reads its skills`,
            });
            continue;
        }
        const again = "install the package again with the agent package manager";
        const skills = installed.phases.filter((phase) => !existsSync(at(join(place.skills, phase, "SKILL.md"))));
        if (skills.length)
            found.push({
                requirement: "the phase skills",
                agent,
                detail: `${skills.join(", ")} not under ${place.skills}: ${again}`,
            });
        if ("rules" in place.instruction) {
            const rules = place.instruction.rules;
            const absent = instructions.filter(([name]) => !existsSync(at(join(rules, `${name}.md`))));
            if (absent.length)
                found.push({
                    requirement: "the flow instruction",
                    agent,
                    detail: `${absent.map(([name]) => `${name}.md`).join(", ")} not under ${rules}: ${again}`,
                });
        }
        else {
            const file = place.instruction.file;
            const written = text(at(file));
            if (instructions.some(([, body]) => !written?.includes(body)))
                found.push({
                    requirement: "the flow instruction",
                    agent,
                    detail: `${file} does not hold it`,
                    repair: () => {
                        writeFileSync(at(file), withSection(written, instructions.map(([, body]) => body)));
                        const manifest = text(at("apm.yml"));
                        if (!manifest)
                            return;
                        const document = parseDocument(manifest);
                        document.setIn(["compilation", "agents_md"], {
                            mode: "managed_section",
                            start_marker: SECTION.start,
                            end_marker: SECTION.end,
                        });
                        writeFileSync(at("apm.yml"), String(document));
                    },
                });
        }
        if (installed.guards.length) {
            const unwired = unwiredGuards(root, agent);
            if (unwired.length)
                found.push({
                    requirement: "the guards",
                    agent,
                    detail: `${place.hooks} does not call ${unwired.join(" or ")}: ${again}`,
                });
        }
    }
    return found;
};
/** The keys the consolidated procedures name in `@keys` that neither the environment nor `.env` holds. */
const absentKeys = (root, env) => {
    const held = loadEnv(root, env);
    return [...readConsolidated(root).procedures].flatMap(([slug, { file, keys = [] }]) => keys
        .filter((key) => !held[key])
        .map((key) => `the key ${key} that the procedure ${slug} (${file}) needs is in neither the environment nor .env: only the person can add it`));
};
/** The consolidated procedures that run a script, a binary or a file the project no longer has. */
const suspects = async (root) => {
    const products = (await readProjectConfig(root))?.products ?? {};
    const roots = Object.values(products).map((p) => p.root);
    return suspectsOf(readConsolidated(root).procedures, holdingsOf(root, roots));
};
/** What a person should know and no repair can settle. */
const notes = (root, installed, env) => {
    const found = absentKeys(root, env);
    const { name, version } = installed.packageManager;
    const lock = parse(text(join(root, `${name}.lock.yaml`)) ?? "");
    if (lock?.apm_version && lock.apm_version !== version)
        found.push(`the package was installed with ${name} ${lock.apm_version} and built against ${version}`);
    const pending = capture(name, ["approve", "--pending"], { cwd: root });
    if (pending.status === 0 && /unapproved/.test(pending.stdout))
        found.push(`${name} lists approvals as pending; review them with \`${name} approve --pending\``);
    const { typeChecker } = installed.project;
    const have = text(join(root, "node_modules", typeChecker.name, "package.json"));
    const major = (v) => Number(v.split(".")[0]);
    if (have && major(JSON.parse(have).version) < major(typeChecker.version))
        found.push(`${typeChecker.name} ${JSON.parse(have).version} is older than ${typeChecker.version}: the language server the package declares will not start`);
    if (installed.guards.length && installed.agents.includes("codex"))
        found.push("codex runs the guards only in a project it trusts and after each hook is reviewed with /hooks; review them again after every update that changes them");
    return found;
};
/**
 * What the flow needs and the project lacks. With `fix`, what the package owns is repaired first
 * and only what is still lacking counts against the project.
 */
export const doctor = async (root, { fix = false, env = process.env, node = process.version } = {}) => {
    const read = readInstalled(root);
    if (!read)
        return undefined;
    const { installed, assets } = read;
    // Only a package that pins end-to-end tools asks which products are web ones.
    const web = installed.project.e2e
        ? (await projectProducts(root)).some((p) => p.config.platform.name === "web")
        : false;
    const id = (lack) => `${lack.requirement}|${lack.agent ?? ""}|${lack.detail}`;
    const tried = new Map();
    const failures = new Map();
    // A repair changes what the next one stands on (the links lead into the pinned command), so each is diagnosed afresh.
    for (; fix;) {
        const next = lacks(root, installed, assets, web, node).find((lack) => lack.repair && !tried.has(id(lack)));
        if (!next)
            break;
        tried.set(id(next), next);
        try {
            next.repair();
        }
        catch (e) {
            failures.set(id(next), e instanceof Error ? e.message : String(e));
        }
    }
    const remaining = lacks(root, installed, assets, web, node);
    const still = new Set(remaining.map(id));
    const item = ({ repair: _repair, drift: _drift, ...rest }, report) => ({
        ...rest,
        report,
    });
    const items = [
        ...[...tried].filter(([key]) => !still.has(key)).map(([, lack]) => item(lack, "repaired")),
        ...remaining.map((lack) => ({
            ...item(lack, lack.drift ? "drift" : "missing"),
            detail: failures.get(id(lack)) ?? lack.detail,
        })),
    ];
    return {
        items,
        notes: notes(root, installed, env),
        suspects: await suspects(root),
        status: items.some((i) => i.report !== "repaired") ? 1 : 0,
    };
};
/**
 * `factory doctor [--fix]`: lists what the flow needs and the project lacks; `--fix` repairs what
 * the package owns. Exit status 0 when nothing is lacking, 1 when something is, 2 when no package
 * is installed.
 */
export const run = async (args) => {
    const report = await doctor(PROJECT_ROOT, { fix: args.includes("--fix") });
    if (!report) {
        console.error(`no installed package found: install one with the agent package manager, so that an agent's skills hold ${join(SETUP_ASSETS, INSTALLED)}`);
        return 2;
    }
    for (const item of report.items)
        console.log(`${item.report}: ${item.requirement}${item.agent ? ` for ${item.agent}` : ""} — ${item.detail}`);
    if (!report.items.length)
        console.log("nothing is lacking");
    for (const note of report.notes)
        console.log(`note: ${note}`);
    for (const suspect of report.suspects)
        console.log(`suspect: ${suspect}`);
    return report.status;
};

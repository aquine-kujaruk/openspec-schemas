import { PLATFORMS } from "./platform.js";
/** Types a project configuration without changing it: `export default defineFactory({ ... })`. */
export const defineFactory = (c) => c;
const isSection = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
const merge = (base, over) => {
    if (over === undefined)
        return base;
    if (!isSection(base) || !isSection(over))
        return over;
    const out = { ...base };
    for (const [k, v] of Object.entries(over))
        out[k] = merge(base[k], v);
    return out;
};
/**
 * The project configuration over the defaults: a value it sets replaces the default (arrays
 * included), a section it sets is merged key by key, and whatever it leaves out keeps its default.
 * Without a project configuration, the defaults as they are.
 */
export const resolveConfig = (defaults, project) => {
    const { schema: _schema, products: _products, implement: _implement, language: _language, platform, ...over } = project ?? {};
    const resolved = merge(defaults, project ? over : undefined);
    return platform === undefined ? resolved : { ...resolved, platform: platformNamed(platform) };
};
/** The platform a configuration names, or gives whole. */
const platformNamed = (platform) => {
    if (typeof platform !== "string")
        return platform;
    const found = PLATFORMS[platform];
    if (!found)
        throw new Error(`no platform is called ${platform}; platforms: ${Object.keys(PLATFORMS).join(", ")}`);
    return found;
};

import { createHash } from "node:crypto";
import { existsSync, globSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { parse, stringify } from "yaml";
import { CHANGES, readChange } from "./change.js";
import { productRoots } from "../package/guard.js";
import { productOf } from "../repository/products.js";
export const EVIDENCE = "evidence.md";
/** A digest of the change's plan and delta specs and of every file under the roots of its product. */
export const digestOf = async (root, change) => {
    const product = await productOf(root, readChange(root, change)?.product);
    // A declared product is its whole folder; the product of a project that declares none, its roots.
    const roots = product.name ? [product.root] : productRoots(product.config);
    const files = [
        join(CHANGES, change, "plan.md"),
        ...globSync("specs/**/*.md", { cwd: join(root, CHANGES, change) }).map((f) => join(CHANGES, change, f)),
        ...roots.flatMap((dir) => existsSync(join(root, dir))
            ? globSync("**/*", { cwd: join(root, dir), withFileTypes: true })
                .filter((f) => f.isFile())
                .map((f) => join(f.parentPath, f.name).slice(root.length + 1))
            : []),
    ].sort();
    const hash = createHash("sha256");
    for (const file of files) {
        // Ticking a task is not a change to what was verified.
        const content = readFileSync(join(root, file), "utf8");
        hash.update(`${file}\n${file.endsWith("plan.md") ? content.replace(/\[[xX ]\]/g, "[]") : content}\n`);
    }
    return hash.digest("hex");
};
const table = (head, rows) => rows.length
    ? [head, head.map(() => "---"), ...rows].map((r) => `| ${r.join(" | ")} |`).join("\n")
    : "None.";
export const writeEvidence = (root, evidence) => {
    const { change, verdict, digest, scenarios, failing, review, procedures, e2e = [] } = evidence;
    const body = [
        `# Evidence of ${change}`,
        `## Scenarios\n\n${table(["Use case", "Requirement", "Scenario", "Result"], scenarios.map((s) => [
            s.spec,
            s.requirement,
            s.scenario.replaceAll("|", "\\|"),
            s.by ? `${s.result}, by the person's word` : s.result,
        ]))}`,
        ...(e2e.length
            ? [`## End-to-end tests\n\n${table(["Test", "Result"], e2e.map((t) => [t.test.replaceAll("|", "\\|"), t.result]))}`]
            : []),
        `## Checks\n\n${failing.length
            ? failing.map((f) => `### ${f.workstream} fails\n\n\`\`\`\n${f.output}\n\`\`\``).join("\n\n")
            : "Every check passes."}`,
        `## Review\n\n${review.state === "run"
            ? `Run: ${review.warnings.length} warning(s).${review.warnings.map((w) => `\n- ${w}`).join("")}`
            : `Skipped: ${review.note ?? "the project configures no key"}.`}`,
        `## Procedures\n\n${table(["Procedure", "Environment", "Treatment", "Outcome"], procedures.map((p) => [p.slug, p.env, p.treatment, p.outcome ?? ""]))}`,
    ].join("\n\n");
    writeFileSync(join(root, CHANGES, change, EVIDENCE), `---\n${stringify({ change, verdict, digest })}---\n\n${body}\n`);
};
/** What the evidence of `change` says, when it has one. */
export const readEvidence = (root, change) => {
    const path = join(root, CHANGES, change, EVIDENCE);
    if (!existsSync(path))
        return undefined;
    const front = /^---\n([\s\S]*?)\n---/.exec(readFileSync(path, "utf8"))?.[1];
    return front ? parse(front) : undefined;
};
